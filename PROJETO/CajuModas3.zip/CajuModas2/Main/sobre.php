<?php 
    session_start();
    header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Caju Modas - Onde o estilo encontra você.</title>
</head>
<body>

<header>
    <h1 class="logo">
        <a>
            <img src="img/CM.png" alt="Logo CM">
        </a>
    </h1>

    <button class="botao_hamburguer" onclick="toggleMenu()">
        <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
    </button>
    <div class="admin-info">
        <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
    </div>
</header>

<div id="menuLateral" class="menu-lateral">
    <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
    <a href="principal.php">Início</a>
    <a href="produtos.php">Produtos</a>
    <a href="lista_desejos.php">Lista de desejos</a>  
    <a href="carrinho.php">Carrinho</a>  
    <a href="sobre.php">Sobre Nós</a>
    <a href="logout.php">Sair</a>
</div>

<script>
    function toggleMenu() {
        const menuLateral = document.getElementById("menuLateral");
        menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
    }
</script>

<div class="sobre-container">
    <div class="sobre-box">
        <h2>Sobre a Caju Modas</h2>
        <p>A Caju Modas nasceu do desejo de trazer estilo, conforto e autenticidade para o dia a dia das pessoas. Mais do que uma loja de roupas, somos apaixonados por moda acessível, de qualidade e com personalidade.</p>
        <p>Desde o início, nosso compromisso é oferecer peças que valorizem todos os corpos, com coleções pensadas para acompanhar as tendências sem perder a essência de quem veste. Aqui, cada detalhe importa desde a escolha dos tecidos até o atendimento que você recebe.</p>
        <p>Trabalhamos com carinho para proporcionar uma experiência única a cada cliente, seja nas lojas físicas ou online. Acreditamos que moda é expressão, e queremos que você se sinta livre para ser quem é.</p>
        <p class="destaque">Caju Modas - Aqui, o estilo que encontra você.</p>
    </div>
</div>

<footer>
    <div class="footer-container">
        <div class="footer-info">
            <h2>Contato</h2>
            <p>Telefone: (41) 9999-9999</p>
            <p>E-mail: <a href="">CAJUMODAS@gmail.com</a></p>
        </div>
        
        <div class="footer-img">
            <img src="img/CM.png" alt="Logo Caju Modas">
        </div>
        
        <div class="footer-social">
            <h2>Siga-nos:</h2>
            <a href="#" class="social-link">    
                <img src="img/tiktok.png" alt="Tiktok" class="footer-icon"> Tiktok
            </a>
            <a href="#" class="social-link">
                <img src="img/instagram.png" alt="Instagram" class="footer-icon"> Instagram 
            </a>
            <a href="#" class="social-link">
                <img src="img/x.png" alt="Twitter" class="footer-icon"> Twitter 
            </a>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
    </div>
</footer>

    <style>
    :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
        }

    header {
        background-color: var(--marrom);
        padding: 8px;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }



    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }


    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }
     
    .login {
        position: absolute;
        Right: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }

    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }


    footer {
        background-color: var(--marrom);
        color: var(--bege1);
        padding: 1px 0; 
        margin-top: 10px; 
    }

    .footer-container {
        display: flex;
        justify-content: space-around;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
        flex-wrap: wrap; 
        padding: 10px 0;
        border-bottom: 3px solid #333;
    }

    .footer-info, .footer-img, .footer-social {
        flex: 1;
        padding: 5px; 
        text-align: center; 
    }

    .footer-img img {
        width: 105;
        height: 100px;
        border-radius: 8px;
    }

    .footer-social {
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: flex-end; 
        gap: 8px; 
        padding-right: 20px; 
    }

    .footer-social a {
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--bege1);
        text-decoration: none;
        flex-direction: row-reverse; 
        font-size: 22px;
    }

    .footer-icon {
        width: 37px; 
        height: 37px;
        margin-left: 12px; 
        transition: transform 0.3s;
    }

    .footer-social a:hover .footer-icon {
        transform: scale(1.2);
    }

    .footer-bottom {
        margin-top: 10px;
        font-size: 14px;
        text-align: center;
    }


    .texto-botao {
        color: white;
    }

    .logo {
        margin: 0;
        padding: 0;
    }
    
    .logo img {
        height: 140px; /* ou o tamanho ideal pra sua logo */
        vertical-align: middle;
    }
    .sobre-container {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 40px 20px;
    margin: 50px 0;
}

.sobre-box {
    background-color: var(--bege2);
    border: 2px solid var(--marrom-escuro);
    border-radius: 15px;
    padding: 30px;
    max-width: 800px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    color: var(--preto);
}

.sobre-box h2 {
    color: var(--marrom-escuro);
    text-align: center;
    margin-bottom: 25px;
    font-size: 28px;
    border-bottom: 2px solid var(--marrom);
    padding-bottom: 10px;
}

.sobre-box p {
    margin-bottom: 15px;
    line-height: 1.6;
    font-size: 18px;
}

.sobre-box .destaque {
    font-weight: bold;
    color: var(--marrom-escuro);
    text-align: center;
    font-style: italic;
    margin-top: 20px;
    font-size: 20px;
}
    .admin-info {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        color: var(--preto);
        gap: 5px;
    }

        .logo {
        flex: 1;
        text-align: center;
    }

    .logo img {
        height: 140px;
    }
</style>