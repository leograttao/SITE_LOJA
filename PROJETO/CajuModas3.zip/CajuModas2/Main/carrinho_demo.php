<?php
// Inicia a sessão
session_start();
    header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
// Conexão com o banco de dados
$host = 'localhost';
$usuario = 'root'; // substitua pelo seu usuário do MySQL
$senha = ''; // substitua pela sua senha do MySQL
$banco = 'cajumodas';

$conexao = new mysqli($host, $usuario, $senha, $banco);

if ($conexao->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Verifica se o usuário está logado (supondo que o ID do cliente está na sessão)
if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php'); // Redireciona se não estiver logado
    exit();
}

$id_cliente = $_SESSION['id_cliente'];
$itens_carrinho = array();
$total = 0;
$compra_finalizada = false;

// Verifica se existe um carrinho para o cliente
$sql_carrinho = "SELECT id_carrinho FROM carrinho WHERE id_cliente = ?";
$stmt = $conexao->prepare($sql_carrinho);
$stmt->bind_param('i', $id_cliente);
$stmt->execute();
$result_carrinho = $stmt->get_result();

if ($result_carrinho->num_rows > 0) {
    $row_carrinho = $result_carrinho->fetch_assoc();
    $id_carrinho = $row_carrinho['id_carrinho'];

    // Processa ações do carrinho (remover/atualizar)
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['remover'])) {
            $id_produto = $_POST['id_produto'];
            $sql_remover = "DELETE FROM carrinho_produto WHERE id_carrinho = ? AND id_produto = ?";
            $stmt = $conexao->prepare($sql_remover);
            $stmt->bind_param('ii', $id_carrinho, $id_produto);
            $stmt->execute();
        } elseif (isset($_POST['atualizar'])) {
            $id_produto = $_POST['id_produto'];
            $quantidade = $_POST['quantidade'];
            
            if ($quantidade > 0) {
                $sql_atualizar = "UPDATE carrinho_produto SET quantidade = ? WHERE id_carrinho = ? AND id_produto = ?";
                $stmt = $conexao->prepare($sql_atualizar);
                $stmt->bind_param('iii', $quantidade, $id_carrinho, $id_produto);
                $stmt->execute();
            }
        } elseif (isset($_POST['finalizar'])) {
            // Processa a finalização da compra
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            $endereco = $_POST['endereco'];
            
            // Insere o pagamento
            $sql_pagamento = "INSERT INTO pagamento (id_cliente, id_carrinho, valor_final, forma_pagamento, status) 
                             VALUES (?, ?, ?, 'Cartão', 'Aprovado')";
            $stmt = $conexao->prepare($sql_pagamento);
            $stmt->bind_param('iid', $id_cliente, $id_carrinho, $total);
            $stmt->execute();
            
            // Cria um novo carrinho vazio para o cliente
            $sql_novo_carrinho = "INSERT INTO carrinho (id_cliente) VALUES (?)";
            $stmt = $conexao->prepare($sql_novo_carrinho);
            $stmt->bind_param('i', $id_cliente);
            $stmt->execute();
            
            $compra_finalizada = true;
        }
    }

    // Obtém os itens do carrinho
    $sql_itens = "SELECT p.id_produto, p.nome, p.preco, p.caminho_imagem, cp.quantidade 
                  FROM carrinho_produto cp
                  JOIN produto p ON cp.id_produto = p.id_produto
                  WHERE cp.id_carrinho = ?";
    $stmt = $conexao->prepare($sql_itens);
    $stmt->bind_param('i', $id_carrinho);
    $stmt->execute();
    $result_itens = $stmt->get_result();

    while ($row = $result_itens->fetch_assoc()) {
        $subtotal = $row['preco'] * $row['quantidade'];
        $total += $subtotal;
        
        $itens_carrinho[] = array(
            'id_produto' => $row['id_produto'],
            'nome' => $row['nome'],
            'preco' => $row['preco'],
            'quantidade' => $row['quantidade'],
            'subtotal' => $subtotal,
            'caminho_imagem' => $row['caminho_imagem']
        );
    }
} else {
    // Se não existir carrinho, cria um novo
    $sql_novo_carrinho = "INSERT INTO carrinho (id_cliente) VALUES (?)";
    $stmt = $conexao->prepare($sql_novo_carrinho);
    $stmt->bind_param('i', $id_cliente);
    $stmt->execute();
    $id_carrinho = $conexao->insert_id;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Caju Modas - Carrinho de Compras</title>
</head>
<body>

    <header>
        <h1 class="logo">
            <a>
              <img src="img/CM.png" alt="Logo CM">
            </a>
          </h1>

          <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="lista_desejos.php">Lista de desejos</a>  
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
        <a href="logout.php">Sair</a>
    </div>

    <div class="carrinho-container">
        <h1 class="carrinho-titulo">Seu Carrinho de Compras</h1>
        
        <?php if (isset($compra_finalizada)): ?>
            <div class="mensagem-sucesso">
                <h3>Compra finalizada com sucesso!</h3>
                <p>Obrigado por comprar conosco. Seu pedido foi processado.</p>
                <a href="produtos.php" class="btn-continuar">Continuar Comprando</a>
            </div>
        <?php elseif (!empty($itens_carrinho)): ?>
            <?php foreach ($itens_carrinho as $item): ?>
                <div class="carrinho-item">
                    <img src="<?php echo htmlspecialchars($item['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($item['nome']); ?>" class="carrinho-item-img">
                    <div class="carrinho-item-detalhes">
                        <h3 class="carrinho-item-nome"><?php echo htmlspecialchars($item['nome']); ?></h3>
                        <p class="carrinho-item-preco">R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?> cada</p>
                        <p class="carrinho-item-subtotal">Subtotal: R$ <?php echo number_format($item['subtotal'], 2, ',', '.'); ?></p>
                        
                        <form method="post" class="carrinho-item-quantidade">
                            <input type="hidden" name="id_produto" value="<?php echo $item['id_produto']; ?>">
                            <label for="quantidade">Quantidade:</label>
                            <input type="number" name="quantidade" min="1" value="<?php echo $item['quantidade']; ?>" class="quantidade-input">
                            <button type="submit" name="atualizar" class="btn-atualizar">Atualizar</button>
                            <button type="submit" name="remover" class="btn-remover">Remover</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <div class="carrinho-resumo">
                <h3 class="resumo-titulo">Resumo do Pedido</h3>
                <p class="resumo-total">Total: R$ <?php echo number_format($total, 2, ',', '.'); ?></p>
            </div>
            
            <form method="post" class="form-checkout">
                <h3>Informações para Entrega</h3>
                <div class="form-group">
                    <label for="nome">Nome Completo:</label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                <div class="form-group">
                    <label for="email">E-mail:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="endereco">Endereço de Entrega:</label>
                    <input type="text" id="endereco" name="endereco" required>
                </div>
                <button type="submit" name="finalizar" class="btn-finalizar">Finalizar Compra</button>
            </form>
        <?php else: ?>
            <div class="carrinho-vazio">
                <h3>Seu carrinho está vazio</h3>
                <p>Navegue pelos nossos produtos e adicione itens ao carrinho</p>
                <a href="produtos.php" class="btn-continuar">Continuar Comprando</a>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <div class="footer-container">
            <div class="footer-info">
                <h2>Contato</h2>
                <p>Telefone: (41) 9999-9999</p>
                <p>E-mail: <a href="">CAJUMODAS@gmail.com</a></p>
            </div>
            
            <div class="footer-img">
                <img src="img/CM.png" alt="Logo Caju Modas">
            </div>
            
            <div class="footer-social">
                <h2>Siga-nos:</h2>
                <a href="" class="social-link">    
                    <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                    Tiktok
                </a>
                <a href="" class="social-link">
                    <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                    Instagram 
                </a>
                <a href="" class="social-link">
                    <img src="img/x.png" alt="Twitter" class="footer-icon">
                    Twitter 
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
        </div>
    </footer>

    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }
    </script>
    
</body>
</html>
<style>
    :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
    }

    header {
        background-color: var(--marrom);
        padding: 8px;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }

    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }

    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }
     
    .login {
        position: absolute;
        Right: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }

    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }

    /* Estilos específicos para o carrinho */
    .carrinho-container {
        max-width: 1200px;
        margin: 30px auto;
        padding: 20px;
        background-color: var(--bege2);
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .carrinho-titulo {
        text-align: center;
        color: var(--preto);
        font-size: 2.2rem;
        margin-bottom: 30px;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--marrom);
    }

    .mensagem-sucesso {
        background-color: #d4edda;
        color: #155724;
        padding: 20px;
        border-radius: 5px;
        margin-bottom: 30px;
        text-align: center;
    }

    .carrinho-item {
        display: flex;
        align-items: center;
        padding: 20px;
        margin-bottom: 20px;
        background-color: var(--bege1);
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .carrinho-item-img {
        width: 150px;
        height: 150px;
        object-fit: cover;
        border-radius: 5px;
        margin-right: 20px;
    }

    .carrinho-item-detalhes {
        flex: 1;
    }

    .carrinho-item-nome {
        margin: 0 0 10px 0;
        color: var(--preto);
        font-size: 1.4rem;
    }

    .carrinho-item-preco, .carrinho-item-subtotal {
        margin: 5px 0;
        color: var(--marrom-escuro);
        font-size: 1.1rem;
    }

    .carrinho-item-quantidade {
        margin-top: 15px;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
    }

    .quantidade-input {
        width: 60px;
        padding: 8px;
        border: 1px solid var(--marrom);
        border-radius: 4px;
        text-align: center;
    }

    .btn-atualizar, .btn-remover, .btn-finalizar, .btn-continuar {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1rem;
        transition: all 0.3s;
    }

    .btn-atualizar {
        background-color: var(--marrom);
        color: white;
    }

    .btn-atualizar:hover {
        background-color: var(--marrom-escuro);
    }

    .btn-remover {
        background-color: #dc3545;
        color: white;
    }

    .btn-remover:hover {
        background-color: #c82333;
    }

    .carrinho-resumo {
        background-color: var(--bege1);
        padding: 20px;
        border-radius: 8px;
        margin: 30px 0;
        text-align: right;
    }

    .resumo-titulo {
        margin: 0 0 15px 0;
        color: var(--preto);
    }

    .resumo-total {
        font-size: 1.5rem;
        color: var(--marrom-escuro);
        font-weight: bold;
        margin: 0;
    }

    .form-checkout {
        background-color: var(--bege1);
        padding: 25px;
        border-radius: 8px;
        margin-top: 30px;
    }

    .form-checkout h3 {
        margin-top: 0;
        color: var(--preto);
        font-size: 1.5rem;
        padding-bottom: 10px;
        border-bottom: 1px solid var(--marrom);
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        color: var(--preto);
        font-weight: bold;
    }

    .form-group input {
        width: 100%;
        padding: 10px;
        border: 1px solid var(--marrom);
        border-radius: 5px;
        font-size: 1rem;
    }

    .btn-finalizar {
        background-color: var(--marrom-escuro);
        color: white;
        width: 100%;
        padding: 15px;
        font-size: 1.2rem;
        margin-top: 10px;
    }

    .btn-finalizar:hover {
        background-color: var(--preto);
    }

    .btn-continuar {
        display: inline-block;
        background-color: var(--marrom);
        color: white;
        text-decoration: none;
        margin-top: 20px;
    }

    .btn-continuar:hover {
        background-color: var(--marrom-escuro);
    }

    .carrinho-vazio {
        text-align: center;
        padding: 40px 20px;
    }

    .carrinho-vazio h3 {
        color: var(--preto);
        font-size: 1.8rem;
        margin-bottom: 15px;
    }

    .carrinho-vazio p {
        color: var(--marrom-escuro);
        font-size: 1.2rem;
        margin-bottom: 25px;
    }

    /* Footer styles */
    footer {
        background-color: var(--marrom);
        color: var(--bege1);
        padding: 1px 0; 
        margin-top: 50px; 
    }

    .footer-container {
        display: flex;
        justify-content: space-around;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
        flex-wrap: wrap; 
        padding: 10px 0;
        border-bottom: 3px solid #333;
    }

    .footer-info, .footer-img, .footer-social {
        flex: 1;
        padding: 5px; 
        text-align: center; 
    }

    .footer-img img {
        width: 105;
        height: 100px;
        border-radius: 8px;
    }

    .footer-social {
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: flex-end; 
        gap: 8px; 
        padding-right: 20px; 
    }

    .footer-social a {
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--bege1);
        text-decoration: none;
        flex-direction: row-reverse; 
        font-size: 22px;
    }

    .footer-icon {
        width: 37px; 
        height: 37px;
        margin-left: 12px; 
        transition: transform 0.3s;
    }

    .footer-social a:hover .footer-icon {
        transform: scale(1.2);
    }

    .footer-bottom {
        margin-top: 10px;
        font-size: 14px;
        text-align: center;
    }

    .logo {
        flex: 1;
        text-align: center;
    }

    .logo img {
        height: 134px;
    }

    @media (max-width: 768px) {
        .carrinho-item {
            flex-direction: column;
            text-align: center;
        }
        
        .carrinho-item-img {
            margin-right: 0;
            margin-bottom: 15px;
        }
        
        .carrinho-item-quantidade {
            justify-content: center;
        }
        
        .footer-container {
            flex-direction: column;
        }
        
        .footer-info, .footer-img, .footer-social {
            margin-bottom: 15px;
        }
        
        .footer-social {
            align-items: center;
            padding-right: 0;
        }
    }
    </style>