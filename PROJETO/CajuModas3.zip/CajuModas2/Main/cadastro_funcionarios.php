<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "cajumodas";

// Conexão
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Cadastro
$mensagem = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $matricula = $_POST['matricula'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $cargo = $_POST['cargo'];

    // Verifica se a matrícula tem exatamente 11 dígitos
    if (!preg_match('/^\d{11}$/', $matricula)) {
        $mensagem = "A matrícula deve conter exatamente 11 dígitos numéricos.";
    } else {
        $sql = "INSERT INTO funcionario (matricula, nome, email, senha, cargo) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("sssss", $matricula, $nome, $email, $senha, $cargo);
            if ($stmt->execute()) {
                $mensagem = "Funcionário cadastrado com sucesso!";
            } else {
                $mensagem = "Erro ao cadastrar: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $mensagem = "Erro na preparação da query.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Funcionário - Caju Modas</title>
</head>
<body>
    <header>
        <h1 class="logo">
            <a>
            <img src="img/CM.png" alt="Logo CM">
            </a>
        </h1>
        <button class="login" onclick="window.location.href='login_funcionario.php'">Login</button>
    </header>

    <div class="quadrado_login">
        <div class="login_texto">Cadastro de Funcionário</div>
        <form method="POST" action="">
            <label class="texto_usuario">Matrícula (11 dígitos):</label>
            <input type="text" name="matricula" class="matricula" required 
                   maxlength="11" minlength="11" pattern="\d{11}" 
                   placeholder="Digite a matrícula (apenas números)"
                   title="A matrícula deve conter exatamente 11 dígitos numéricos">

            <label class="texto_usuario">Nome:</label>
            <input type="text" name="nome" class="nome" required placeholder="Digite o nome completo">

            <label class="texto_usuario">Email:</label>
            <input type="email" name="email" class="email" required placeholder="Digite o email (utilize @)">

            <label class="texto_usuario">Senha:</label>
            <input type="password" name="senha" class="senha" required placeholder="Digite a senha">

            <label class="texto_usuario">Cargo:</label>
            <input type="text" name="cargo" class="cargo" required placeholder="Digite o cargo">

            <button type="submit" class="login_botao">Cadastrar Funcionário</button>
        </form>
        <div class="mensagem"><?php echo $mensagem; ?></div>
    </div>
</body>
</html>
<style>
    :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
        color: var(--preto);
        background-color: var(--bege2);
    }

    nav {
        text-align: center;
    }
    .home {
        text-decoration: none;
        color: var(--preto);
        font-size: 18px;
        font-weight: bold;
    }

    header {
        background-color: var(--marrom);
        padding: 8px;
        text-align: center;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
    }

    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }
    .login {
        position: absolute;
        Right: 100px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }

    .quadrado_login {
        background: var(--bege2);
        width: 300px;
        padding: 20px;
        margin: 10px auto;
        margin-top: 100px;
        margin-bottom: 400px;
        border-radius: 12px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .login_texto {
        font-size: 24px;
        margin-bottom: 25px;
        display: block;
    }

    .texto_usuario {
        font-size: 14px;
    }
    .senha {
        width: 94%;
        padding: 8px;
        border: 2px solid maroon;
        border-radius: 20px;
        font-size: 14px;
        margin-bottom: 10px;
    }

    input {
        width: 94%;
        padding: 8px;
        border: 2px solid maroon;
        border-radius: 20px;
        font-size: 14px;
    }

    .login_botao {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            border: none;
            padding: 10px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            margin-top: 5px;
            margin-bottom: 20px;
        }

    .login_botao:hover {
        background-color: var(--preto);
    }

    .mensagem {
        text-align: center;
        font-size: 16px;
        margin-top: 15px;
    }

    .logo {
        margin: 0;
        padding: 0;
    }

    .logo img {
        height: 140px;
        vertical-align: middle;
    }
</style>