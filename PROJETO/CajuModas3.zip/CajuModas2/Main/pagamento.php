<?php
// Inicia a sessão
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Configuração do tempo de inatividade (20 minutos)
    $inactive = 1200; // 20 minutos em segundos
    
    // Verifica se existe o timestamp da última atividade
    if (isset($_SESSION['last_activity'])) {
        // Calcula o tempo desde a última atividade
        $session_life = time() - $_SESSION['last_activity'];
        if ($session_life > $inactive) {
            // Tempo excedido - destrói a sessão e redireciona
            session_unset();
            session_destroy();
            header("Location: login.php");
            exit();
        }
    }
    
    // Atualiza o timestamp da última atividade
    $_SESSION['last_activity'] = time();
    
    // Verifica se é uma requisição AJAX para manter a sessão ativa
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' && isset($_GET['keepalive'])) {
        exit(); // Apenas atualiza a sessão e encerra
    }
    
    if(!isset($_SESSION['usuario']) || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }
    if(!isset($_SESSION['usuario'])  || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Verifica se o usuário está logado
if (!isset($_SESSION['id_cliente'])) {
    $_SESSION['mensagem'] = "Você precisa estar logado para acessar o pagamento!";
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php");
    exit();
}

$id_cliente = $_SESSION['id_cliente'];
$id_pagamento = isset($_SESSION['id_pagamento']) ? $_SESSION['id_pagamento'] : null;

// Se não houver pagamento em andamento, redireciona para o carrinho
if (!$id_pagamento) {
    header("Location: carrinho.php");
    exit();
}

// Obter informações do pagamento
$pagamento = obterPagamento($conn, $id_pagamento, $id_cliente);
if (!$pagamento) {
    // Se não encontrar o pagamento, cria um novo automaticamente
    $pagamento = criarPagamentoAutomatico($conn, $id_cliente);
    if ($pagamento) {
        $_SESSION['id_pagamento'] = $pagamento['id_pagamento'];
        $id_pagamento = $pagamento['id_pagamento'];
    } else {
        $_SESSION['mensagem'] = "Erro ao processar pagamento. Tente novamente.";
        header("Location: carrinho.php");
        exit();
    }
}

$valor_final = $pagamento['valor_final'];
$forma_pagamento = $pagamento['forma_pagamento'] ?? 'Cartão de Crédito'; // Valor padrão
$status = $pagamento['status'];

// Processar seleção de método de pagamento
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['selecionar_pagamento'])) {
    $nova_forma_pagamento = $_POST['forma_pagamento'];
    
    if (atualizarFormaPagamento($conn, $id_pagamento, $nova_forma_pagamento)) {
        $_SESSION['mensagem'] = "Método de pagamento atualizado com sucesso!";
        $forma_pagamento = $nova_forma_pagamento;
    } else {
        $_SESSION['mensagem'] = "Erro ao atualizar método de pagamento.";
    }
    
    header("Location: pagamento.php");
    exit();
}

// Processar confirmação de pagamento - MODIFICAÇÃO PRINCIPAL AQUI
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirmar_pagamento'])) {
    // Se não tiver forma de pagamento selecionada, define como Cartão de Crédito
    if (empty($forma_pagamento)) {
        $forma_pagamento = 'Cartão de Crédito';
        atualizarFormaPagamento($conn, $id_pagamento, $forma_pagamento);
    }
    
    // Atualiza o status para "Aprovado" diretamente
    if (confirmarPagamento($conn, $id_pagamento)) {
        // Registrar itens vendidos
        registrarItensVendidos($conn, $id_pagamento, $id_cliente);
        
        $_SESSION['mensagem'] = "Pagamento aprovado com sucesso! Seu pedido está sendo processado.";
        unset($_SESSION['id_pagamento']);
        
        // Redirecionar para página de confirmação com o ID do pagamento
        header("Location: confirmacao_pagamento.php?id=" . $id_pagamento);
        exit();
    } else {
        $_SESSION['mensagem'] = "Erro ao confirmar pagamento.";
        header("Location: pagamento.php");
        exit();
    }
}

// Funções de acesso ao banco de dados
function obterPagamento($conn, $id_pagamento, $id_cliente) {
    $stmt = $conn->prepare("SELECT id_pagamento, valor_final, forma_pagamento, status FROM pagamento WHERE id_pagamento = ? AND id_cliente = ?");
    $stmt->bind_param("ii", $id_pagamento, $id_cliente);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows === 0 ? false : $result->fetch_assoc();
}

function criarPagamentoAutomatico($conn, $id_cliente) {
    // Obter carrinho do cliente
    $stmt = $conn->prepare("SELECT id_carrinho FROM carrinho WHERE id_cliente = ?");
    $stmt->bind_param("i", $id_cliente);
    $stmt->execute();
    $result = $stmt->get_result();
    $carrinho = $result->fetch_assoc();
    
    if (!$carrinho) return false;
    
    $id_carrinho = $carrinho['id_carrinho'];
    
    // Calcular valor total do carrinho
    $stmt = $conn->prepare("SELECT SUM(p.preco * cp.quantidade) as total 
                           FROM carrinho_produto cp 
                           JOIN produto p ON cp.id_produto = p.id_produto 
                           WHERE cp.id_carrinho = ?");
    $stmt->bind_param("i", $id_carrinho);
    $stmt->execute();
    $result = $stmt->get_result();
    $total = $result->fetch_assoc()['total'];
    
    // Criar pagamento
    $stmt = $conn->prepare("INSERT INTO pagamento (id_cliente, id_carrinho, valor_final, forma_pagamento, status) 
                           VALUES (?, ?, ?, 'Cartão de Crédito', 'Pendente')");
    $stmt->bind_param("iid", $id_cliente, $id_carrinho, $total);
    if ($stmt->execute()) {
        $id_pagamento = $conn->insert_id;
        return [
            'id_pagamento' => $id_pagamento,
            'valor_final' => $total,
            'forma_pagamento' => 'Cartão de Crédito',
            'status' => 'Pendente'
        ];
    }
    return false;
}

function atualizarFormaPagamento($conn, $id_pagamento, $forma_pagamento) {
    $stmt = $conn->prepare("UPDATE pagamento SET forma_pagamento = ? WHERE id_pagamento = ?");
    $stmt->bind_param("si", $forma_pagamento, $id_pagamento);
    return $stmt->execute();
}

// MODIFICAÇÃO PRINCIPAL AQUI - SEMPRE APROVA O PAGAMENTO
function confirmarPagamento($conn, $id_pagamento) {
    // Atualiza para status "Aprovado" e define a data atual
    $stmt = $conn->prepare("UPDATE pagamento SET status = 'Aprovado', data_pagamento = NOW() WHERE id_pagamento = ?");
    $stmt->bind_param("i", $id_pagamento);
    return $stmt->execute();
}

// Nova função para registrar itens vendidos
function registrarItensVendidos($conn, $id_pagamento, $id_cliente) {
    // Obter itens do carrinho
    $stmt = $conn->prepare("SELECT c.id_carrinho FROM carrinho c WHERE c.id_cliente = ?");
    $stmt->bind_param("i", $id_cliente);
    $stmt->execute();
    $result = $stmt->get_result();
    $carrinho = $result->fetch_assoc();
    $id_carrinho = $carrinho['id_carrinho'];
    
    // Obter produtos do carrinho
    $stmt = $conn->prepare("SELECT cp.id_produto, cp.quantidade, p.preco 
                           FROM carrinho_produto cp 
                           JOIN produto p ON cp.id_produto = p.id_produto 
                           WHERE cp.id_carrinho = ?");
    $stmt->bind_param("i", $id_carrinho);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Inserir cada item na tabela de itens vendidos
    while ($item = $result->fetch_assoc()) {
        $stmt_insert = $conn->prepare("INSERT INTO itens_vendidos 
                                     (id_pagamento, id_produto, quantidade, preco_unitario) 
                                     VALUES (?, ?, ?, ?)");
        $stmt_insert->bind_param("iiid", $id_pagamento, $item['id_produto'], 
                                $item['quantidade'], $item['preco']);
        $stmt_insert->execute();
        
        // Atualizar estoque (opcional)
        $stmt_update = $conn->prepare("UPDATE produto SET estoque = estoque - ? WHERE id_produto = ?");
        $stmt_update->bind_param("ii", $item['quantidade'], $item['id_produto']);
        $stmt_update->execute();
    }
    
    // Limpar carrinho após venda
    $stmt_clear = $conn->prepare("DELETE FROM carrinho_produto WHERE id_carrinho = ?");
    $stmt_clear->bind_param("i", $id_carrinho);
    $stmt_clear->execute();
    
    return true;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Caju Modas - Pagamento</title>
    <style>
        :root {
            --amarelo: #f4d06f;
            --marrom: #b39977;
            --bege1: #EDE6D9;
            --bege2: #ddcfb6;
            --bege3: #e3d6be;
            --preto: #342519;
            --marrom-escuro: #684F36;
        }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
        }

    header {
        background-color: var(--marrom);
        padding: 8px;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }



    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }


    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }
     
    .login {
        position: absolute;
        Right: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }

    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }

        .admin-info {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            color: var(--preto);
            gap: 5px;
        }

        .logo {
            flex: 1;
            text-align: center;
        }

        .logo img {
            height: 140px;
            vertical-align: middle;
        }

        /* Estilos específicos da página de pagamento */
        .pagamento-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            margin-top: 160px;
            margin-bottom: 160px;
        }

        .metodos-pagamento {
            flex: 2;
            background-color: var(--bege2);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .resumo-pagamento {
            flex: 1;
            background-color: var(--bege2);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            align-self: flex-start;
            position: sticky;
            top: 20px;
        }

        .titulo-secao {
            font-size: 1.5rem;
            margin-bottom: 20px;
            color: var(--marrom-escuro);
            border-bottom: 2px solid var(--marrom);
            padding-bottom: 10px;
        }

        .metodo-pagamento {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            background-color: var(--bege1);
            cursor: pointer;
            transition: all 0.3s;
        }

        .metodo-pagamento:hover {
            background-color: var(--bege3);
            transform: translateX(5px);
        }

        .metodo-pagamento.selecionado {
            background-color: var(--marrom);
            color: white;
        }

        .metodo-pagamento input[type="radio"] {
            transform: scale(1.3);
        }

        .metodo-icone {
            font-size: 1.5rem;
            width: 30px;
            text-align: center;
        }

        .metodo-info {
            flex: 1;
        }

        .metodo-nome {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .metodo-descricao {
            font-size: 0.9rem;
            color: var(--preto);
        }

        .btn-selecionar {
            background-color: var(--marrom-escuro);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-selecionar:hover {
            background-color: var(--preto);
        }

        .resumo-linha {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding: 8px 0;
            border-bottom: 1px solid var(--marrom);
        }

        .resumo-total {
            font-weight: bold;
            font-size: 1.5rem;
            margin-top: 20px;
            color: var(--preto);
        }

        .btn-confirmar {
            width: 100%;
            padding: 15px;
            background-color: var(--marrom-escuro);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1.2rem;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-confirmar:hover {
            background-color: var(--preto);
        }

        .btn-confirmar:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        /* Detalhes específicos de cada método de pagamento */
        .detalhes-pagamento {
            margin-top: 20px;
            padding: 15px;
            background-color: var(--bege1);
            border-radius: 5px;
            display: none;
        }

        .detalhes-pagamento.visivel {
            display: block;
        }

        .campo-formulario {
            margin-bottom: 15px;
        }

        .campo-formulario label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .campo-formulario input {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--marrom);
            border-radius: 4px;
            font-size: 1rem;
        }

        .grupo-cartao {
            display: flex;
            gap: 15px;
        }

        .grupo-cartao .campo-formulario {
            flex: 1;
        }

        .qrcode-pix {
            text-align: center;
            padding: 20px;
            background-color: white;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .qrcode-pix img {
            max-width: 200px;
            margin-bottom: 10px;
        }

        .codigo-boleto {
            font-family: monospace;
            font-size: 1.2rem;
            letter-spacing: 2px;
            text-align: center;
            padding: 15px;
            background-color: white;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        /* Estilos compartilhados com a página de produtos */
        footer {
            background-color: var(--marrom);
            color: var(--bege1);
            padding: 1px 0; 
            margin-top: 10px; 
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            flex-wrap: wrap; 
            padding: 10px 0;
            border-bottom: 3px solid #333;
        }

        .footer-info, .footer-img, .footer-social {
            flex: 1;
            padding: 5px; 
            text-align: center; 
        }

        .footer-img img {
            width: 105;
            height: 100px;
            border-radius: 8px;
        }

        .footer-social {
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: flex-end; 
            gap: 8px; 
            padding-right: 20px; 
        }

        .footer-social a {
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--bege1);
            text-decoration: none;
            flex-direction: row-reverse; 
            font-size: 22px;
        }

        .footer-icon {
            width: 37px; 
            height: 37px;
            margin-left: 12px; 
            transition: transform 0.3s;
        }

        .footer-social a:hover .footer-icon {
            transform: scale(1.2);
        }

        .footer-bottom {
            margin-top: 10px;
            font-size: 14px;
            text-align: center;
        }

        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px;
            background-color: var(--marrom-escuro);
            color: white;
            border-radius: 5px;
            z-index: 1000;
            animation: fadeInOut 3s ease-in-out;
            opacity: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        @keyframes fadeInOut {
            0% { opacity: 0; transform: translateY(-20px); }
            20% { opacity: 1; transform: translateY(0); }
            80% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(-20px); }
        }
    </style>
</head>
<body>
    <header>
        <h1 class="logo">
            <a href="principal.php">
                <img src="img/CM.png" alt="Logo CM">
            </a>
        </h1>

        <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
        
        <div class="admin-info">
            <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
        </div>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="lista_desejos.php">Lista de desejos</a>  
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
        <a href="logout.php">Sair</a>
    </div>

    <?php if (isset($_SESSION['mensagem'])): ?>
        <div class="alert">
            <i class="fas fa-check-circle"></i>
            <?php echo $_SESSION['mensagem']; unset($_SESSION['mensagem']); ?>
        </div>
    <?php endif; ?>

    <section class="pagamento-container">
        <div class="metodos-pagamento">
            <h2 class="titulo-secao">Métodos de Pagamento</h2>
            
            <form method="post" id="formPagamento">
                <div class="metodo-pagamento <?php echo $forma_pagamento === 'Cartão de Crédito' ? 'selecionado' : ''; ?>">
                    <input type="radio" name="forma_pagamento" value="Cartão de Crédito" id="credito" 
                           <?php echo $forma_pagamento === 'Cartão de Crédito' ? 'checked' : ''; ?>>
                    <div class="metodo-icone">
                        <i class="far fa-credit-card"></i>
                    </div>
                    <div class="metodo-info">
                        <div class="metodo-nome">Cartão de Crédito</div>
                        <div class="metodo-descricao">Pague com seu cartão de crédito em até 12x</div>
                    </div>
                </div>
                
                <div class="detalhes-pagamento <?php echo $forma_pagamento === 'Cartão de Crédito' ? 'visivel' : ''; ?>" id="detalhes-credito">
                    <div class="campo-formulario">
                        <label for="numero-cartao">Número do Cartão</label>
                        <input type="text" id="numero-cartao" placeholder="1234 5678 9012 3456" maxlength="19">
                    </div>
                    
                    <div class="campo-formulario">
                        <label for="nome-cartao">Nome no Cartão</label>
                        <input type="text" id="nome-cartao" placeholder="Como consta no cartão">
                    </div>
                    
                    <div class="grupo-cartao">
                        <div class="campo-formulario">
                            <label for="validade-cartao">Validade</label>
                            <input type="text" id="validade-cartao" placeholder="MM/AA" maxlength="5">
                        </div>
                        
                        <div class="campo-formulario">
                            <label for="cvv-cartao">CVV</label>
                            <input type="text" id="cvv-cartao" placeholder="123" maxlength="3">
                        </div>
                        
                        <div class="campo-formulario">
                            <label for="parcelas">Parcelas</label>
                            <select id="parcelas" style="width: 100%; padding: 10px; border: 1px solid var(--marrom); border-radius: 4px;">
                                <option value="1">1x de R$ <?php echo number_format($valor_final, 2, ',', '.'); ?></option>
                                <option value="2">2x de R$ <?php echo number_format($valor_final / 2, 2, ',', '.'); ?></option>
                                <option value="3">3x de R$ <?php echo number_format($valor_final / 3, 2, ',', '.'); ?></option>
                                <option value="4">4x de R$ <?php echo number_format($valor_final / 4, 2, ',', '.'); ?></option>
                                <option value="5">5x de R$ <?php echo number_format($valor_final / 5, 2, ',', '.'); ?></option>
                                <option value="6">6x de R$ <?php echo number_format($valor_final / 6, 2, ',', '.'); ?></option>
                                <option value="7">7x de R$ <?php echo number_format($valor_final / 7, 2, ',', '.'); ?></option>
                                <option value="8">8x de R$ <?php echo number_format($valor_final / 8, 2, ',', '.'); ?></option>
                                <option value="9">9x de R$ <?php echo number_format($valor_final / 9, 2, ',', '.'); ?></option>
                                <option value="10">10x de R$ <?php echo number_format($valor_final / 10, 2, ',', '.'); ?></option>
                                <option value="11">11x de R$ <?php echo number_format($valor_final / 11, 2, ',', '.'); ?></option>
                                <option value="12">12x de R$ <?php echo number_format($valor_final / 12, 2, ',', '.'); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="metodo-pagamento <?php echo $forma_pagamento === 'PIX' ? 'selecionado' : ''; ?>">
                    <input type="radio" name="forma_pagamento" value="PIX" id="pix" 
                           <?php echo $forma_pagamento === 'PIX' ? 'checked' : ''; ?>>
                    <div class="metodo-icone">
                        <i class="fas fa-qrcode"></i>
                    </div>
                    <div class="metodo-info">
                        <div class="metodo-nome">PIX</div>
                        <div class="metodo-descricao">Pagamento instantâneo com desconto de 5%</div>
                    </div>
                </div>
                
                <div class="detalhes-pagamento <?php echo $forma_pagamento === 'PIX' ? 'visivel' : ''; ?>" id="detalhes-pix">
                    <div class="qrcode-pix">
                        <i class="fas fa-qrcode fa-5x"></i>
                        <p>Escaneie o QR Code com seu app de pagamento</p>
                    </div>
                    <div class="campo-formulario">
                        <label for="chave-pix">Chave PIX (CPF)</label>
                        <input type="text" id="chave-pix" value="123.456.789-09" readonly>
                    </div>
                    <p style="text-align: center; font-weight: bold; color: var(--marrom-escuro);">
                        Valor com 5% de desconto: R$ <?php echo number_format($valor_final * 0.95, 2, ',', '.'); ?>
                    </p>
                </div>
                
                <div class="metodo-pagamento <?php echo $forma_pagamento === 'Boleto Bancário' ? 'selecionado' : ''; ?>">
                    <input type="radio" name="forma_pagamento" value="Boleto Bancário" id="boleto" 
                           <?php echo $forma_pagamento === 'Boleto Bancário' ? 'checked' : ''; ?>>
                    <div class="metodo-icone">
                        <i class="fas fa-barcode"></i>
                    </div>
                    <div class="metodo-info">
                        <div class="metodo-nome">Boleto Bancário</div>
                        <div class="metodo-descricao">Pague em qualquer agência bancária ou internet banking</div>
                    </div>
                </div>
                
                <div class="detalhes-pagamento <?php echo $forma_pagamento === 'Boleto Bancário' ? 'visivel' : ''; ?>" id="detalhes-boleto">
                    <div class="codigo-boleto">
                        34191.79001 01043.510047 91020.150008 7 87650000019999
                    </div>
                    <div class="campo-formulario">
                        <label for="vencimento-boleto">Data de Vencimento</label>
                        <input type="text" id="vencimento-boleto" value="<?php echo date('d/m/Y', strtotime('+3 days')); ?>" readonly>
                    </div>
                    <p style="text-align: center;">
                        O boleto será gerado após a confirmação do pedido.
                    </p>
                </div>
                
                <button type="submit" name="selecionar_pagamento" class="btn-selecionar">
                    <i class="fas fa-check"></i> Selecionar Método
                </button>
            </form>
        </div>
        
        <div class="resumo-pagamento">
            <h3 class="titulo-secao">Resumo do Pedido</h3>
            
            <div class="resumo-linha">
                <span>Subtotal</span>
                <span>R$ <?php echo number_format($valor_final, 2, ',', '.'); ?></span>
            </div>
            
            <div class="resumo-linha">
                <span>Frete</span>
                <span>Grátis</span>
            </div>
            
            <?php if ($forma_pagamento === 'PIX'): ?>
                <div class="resumo-linha">
                    <span>Desconto PIX (5%)</span>
                    <span>- R$ <?php echo number_format($valor_final * 0.05, 2, ',', '.'); ?></span>
                </div>
            <?php endif; ?>
            
            <div class="resumo-linha resumo-total">
                <span>Total</span>
                <span>R$ <?php echo number_format($forma_pagamento === 'PIX' ? $valor_final * 0.95 : $valor_final, 2, ',', '.'); ?></span>
            </div>
            
            <form method="post">
                <button type="submit" name="confirmar_pagamento" class="btn-confirmar" <?php echo empty($forma_pagamento) ? 'disabled' : ''; ?>>
                    <i class="fas fa-lock"></i> Confirmar Pagamento
                </button>
            </form>
            
            <p style="text-align: center; margin-top: 15px; font-size: 0.9rem;">
                <i class="fas fa-lock"></i> Compra segura - Seus dados estão protegidos
            </p>
        </div>
    </section>

    <footer>
        <div class="footer-container">
            <div class="footer-info">
                <h2>Contato</h2>
                <p>Telefone: (41) 9999-9999</p>
                <p>E-mail: <a href="mailto:CAJUMODAS@gmail.com">CAJUMODAS@gmail.com</a></p>
            </div>
            
            <div class="footer-img">
                <img src="img/CM.png" alt="Logo Caju Modas">
            </div>
            
            <div class="footer-social">
                <h2>Siga-nos:</h2>
                <a href="#" class="social-link">    
                    <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                    Tiktok
                </a>
                <a href="#" class="social-link">
                    <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                    Instagram 
                </a>
                <a href="#" class="social-link">
                    <img src="img/x.png" alt="Twitter" class="footer-icon">
                    Twitter 
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
        </div>
    </footer>

    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }

        // Mostrar/ocultar detalhes do método de pagamento selecionado
        document.querySelectorAll('input[name="forma_pagamento"]').forEach(radio => {
            radio.addEventListener('change', function() {
                // Oculta todos os detalhes
                document.querySelectorAll('.detalhes-pagamento').forEach(detalhes => {
                    detalhes.classList.remove('visivel');
                });
                
                // Mostra os detalhes do método selecionado
                const detalhesId = 'detalhes-' + this.id;
                document.getElementById(detalhesId).classList.add('visivel');
                
                // Atualiza o botão de confirmação
                document.querySelector('.btn-confirmar').disabled = false;
            });
        });

        // Formatação do número do cartão
        document.getElementById('numero-cartao').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s+/g, '');
            if (value.length > 0) {
                value = value.match(new RegExp('.{1,4}', 'g')).join(' ');
            }
            e.target.value = value;
        });

        // Formatação da validade do cartão
        document.getElementById('validade-cartao').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            e.target.value = value;
        });

        // Esconder mensagem após 3 segundos
        document.addEventListener('DOMContentLoaded', function() {
            const alert = document.querySelector('.alert');
            if (alert) {
                setTimeout(() => {
                    alert.style.display = 'none';
                }, 3000);
            }
        });

        // Monitora atividade do usuário para manter a sessão ativa
    const activityEvents = ['mousemove', 'keypress', 'scroll', 'click', 'touchstart'];
    activityEvents.forEach(event => {
        document.addEventListener(event, resetTimer, {passive: true});
    });

    let timeout;
    const inactiveTime = 1200000; // 20 minutos em milissegundos

    function resetTimer() {
        clearTimeout(timeout);
        timeout = setTimeout(logout, inactiveTime);
        
        // Atualiza a sessão no servidor sem recarregar a página
        updateSession();
    }

    function logout() {
        window.location.href = 'login.php?timeout=1';
    }

    function updateSession() {
        // Usa fetch para fazer uma requisição silenciosa ao mesmo arquivo
        fetch(window.location.href + '?keepalive=1', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            cache: 'no-store'
        }).catch(error => console.error('Erro ao manter sessão:', error));
    }

    // Inicia o timer quando a página carrega
    resetTimer();
    </script>
</body>
</html>
<?php
$conn->close();
?>