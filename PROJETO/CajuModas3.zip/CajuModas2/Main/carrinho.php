<?php
session_start();

// Redirecionar se não estiver logado
if (!isset($_SESSION['id_cliente'])) {
    $_SESSION['redirect_url'] = 'carrinho.php';
    header('Location: login.php');
    exit();
}

$cliente_id = $_SESSION['id_cliente'];
$mensagem = '';
$erro = '';

// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Verificar se o cliente existe
$stmt = $conn->prepare("SELECT id_cliente FROM cliente WHERE id_cliente = ?");
$stmt->bind_param("i", $cliente_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    session_destroy();
    header('Location: login.php');
    exit();
}
$stmt->close();

// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['atualizar'])) {
        $produto_id = $_POST['produto_id'];
        $quantidade = $_POST['quantidade'];
        
        // Verificar estoque
        $stmt = $conn->prepare("SELECT estoque FROM produto WHERE id_produto = ?");
        $stmt->bind_param("i", $produto_id);
        $stmt->execute();
        $estoque = $stmt->get_result()->fetch_assoc()['estoque'];
        
        if ($quantidade <= $estoque) {
            $update = $conn->prepare("UPDATE Carrinho_Produto SET quantidade = ? 
                                    WHERE id_carrinho = ? AND id_produto = ?");
            $update->bind_param("iii", $quantidade, $carrinho_id, $produto_id);
            if ($update->execute()) {
                $mensagem = "Quantidade atualizada com sucesso!";
            } else {
                $erro = "Erro ao atualizar quantidade: " . $conn->error;
            }
            $update->close();
        } else {
            $erro = "Quantidade solicitada excede o estoque disponível.";
        }
    }
    
    if (isset($_POST['remover'])) {
        $produto_id = $_POST['produto_id'];
        $delete = $conn->prepare("DELETE FROM Carrinho_Produto 
                                WHERE id_carrinho = ? AND id_produto = ?");
        $delete->bind_param("ii", $carrinho_id, $produto_id);
        if ($delete->execute()) {
            $mensagem = "Produto removido do carrinho!";
        } else {
            $erro = "Erro ao remover produto: " . $conn->error;
        }
        $delete->close();
    }
    
    if (isset($_POST['finalizar'])) {
        // Calcular total
        $stmt = $conn->prepare("SELECT SUM(p.produto_promocional > 0 AND p.produto_promocional < p.preco 
                               ? p.produto_promocional * cp.quantidade 
                               : p.preco * cp.quantidade) as total
                               FROM Carrinho_Produto cp
                               JOIN Produto p ON cp.id_produto = p.id_produto
                               WHERE cp.id_carrinho = ?");
        $stmt->bind_param("ii", $carrinho_id, $carrinho_id);
        $stmt->execute();
        $total = $stmt->get_result()->fetch_assoc()['total'];
        
        if ($total > 0) {
            $insert = $conn->prepare("INSERT INTO Pagamento (id_cliente, id_carrinho, valor_final, forma_pagamento, status)
                                     VALUES (?, ?, ?, ?, 'Pendente')");
            $insert->bind_param("iids", $cliente_id, $carrinho_id, $total, $_POST['forma_pagamento']);
            if ($insert->execute()) {
                $mensagem = "Pagamento processado com sucesso!";
                // Criar novo carrinho
                $conn->query("INSERT INTO carrinho (id_cliente) VALUES ($cliente_id)");
            } else {
                $erro = "Erro ao processar pagamento: " . $conn->error;
            }
        } else {
            $erro = "Carrinho vazio não pode ser finalizado!";
        }
    }
}

// Obter produtos do carrinho
$query = "SELECT p.id_produto, p.nome, p.descricao, p.preco, p.produto_promocional, 
          p.caminho_imagem, cp.quantidade, p.estoque
          FROM Carrinho_Produto cp
          JOIN Produto p ON cp.id_produto = p.id_produto
          WHERE cp.id_carrinho = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $carrinho_id);
$stmt->execute();
$produtos = $stmt->get_result();
$total = 0;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Carrinho | Caju Modas</title>
    <style>
        :root {
            --amarelo: #f4d06f;
            --marrom: #b39977;
            --bege1: #EDE6D9;
            --bege2: #ddcfb6;
            --bege3: #e3d6be;
            --preto: #342519;
            --marrom-escuro: #684F36;
        }

        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: linear-gradient(180deg, var(--bege1), var(--bege3));
            min-height: 100vh;
        }

        header {
            background-color: var(--marrom);
            padding: 8px;
            box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
            height: 138px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            position: relative;
        }

        .logo {
            flex: 1;
            text-align: center;
        }
        
        .logo img {
            height: 140px;
            vertical-align: middle;
        }

        .botao_hamburguer {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            z-index: 10;
        }

        .admin-info {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--preto);
            font-weight: bold;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }

        .menu-lateral {
            height: 100%;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: var(--bege2);
            overflow-x: hidden;
            transition: width 0.5s; 
            padding-top: 70px;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
            z-index: 20;
        }

        .menu-lateral .fechar {
            position: absolute;
            top: 1px;
            right: 20px;
            font-size: 25px;
            color: var(--bege);
            background: none;
            border: none;
            cursor: pointer;
            transition: color 0.3s;
        }

        .menu-lateral a {
            padding: 15px 20px;
            text-decoration: none;
            font-size: 20px;
            color: var(--preto);
            display: block;
            margin: 10px 0;
            transition: 0.3s;
        }

        .menu-lateral a:hover {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            transform: scale(1.05);
        }
        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        h2 {
            text-align: center;
            color: var(--marrom-escuro);
            font-size: 2.5rem;
            margin-bottom: 40px;
        }

        .produtos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
            padding: 20px;
        }

        .produto-card {
            background: var(--bege2);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            display: flex;
            flex-direction: column;
        }
        .preco-promocional {
            color: #d00;
            font-weight: bold;
            font-size: 1.3rem;
        }
        
        .preco-original {
            text-decoration: line-through;
            color: #777;
            font-size: 1rem;
        }

        .produto-card:hover {
            transform: translateY(-5px);
        }

        .produto-imagem {
            width: 100%;
            height: 300px;
            object-fit: cover;
            border-bottom: 3px solid var(--bege2);
        }

        .produto-info {
            padding: 20px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .produto-info h3 {
            color: var(--marrom-escuro);
            margin: 0 0 10px 0;
            font-size: 1.4rem;
        }

        .produto-info p {
            color: var(--preto);
            margin: 5px 0;
            flex-grow: 1;
        }

        .preco {
            font-size: 1.3rem;
            color: var(--marrom-escuro);
            font-weight: bold;
            margin: 15px 0;
        }

        .btn-remover {
            background-color: var(--marrom);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s;
            width: 100%;
            margin-top: 15px;
        }

        .btn-remover:hover {
            background-color: var(--marrom-escuro);
        }

        .lista-vazia {
            text-align: center;
            padding: 90px;
            font-size: 1.2rem;
            color: var(--marrom-escuro);
            border: 2px dashed var(--bege2);
            border-radius: 12px;
            margin: 40px 0;
        }

        .mensagem {
            text-align: center;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
            font-size: 1.1rem;
        }

        .sucesso {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .erro {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* FOOTER */
        footer {
            background-color: var(--marrom);
            color: var(--bege1);
            padding: 20px 0;
            margin-top: 50px;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            flex-wrap: wrap;
            padding: 20px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-info, .footer-img, .footer-social {
            flex: 1;
            padding: 10px;
            text-align: center;
            min-width: 250px;
        }

        .footer-img img {
            width: 100px;
            height: auto;
            border-radius: 8px;
        }

        .footer-social {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .footer-social a {
            color: var(--bege1);
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: color 0.3s;
        }

        .footer-social a:hover {
            color: var(--amarelo);
        }

        .footer-icon {
            width: 24px;
            height: 24px;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .produtos-grid {
                grid-template-columns: 1fr;
            }
            
            .produto-imagem {
                height: 250px;
            }
            
            h2 {
                font-size: 2rem;
            }
            
            header {
                flex-direction: column;
                height: auto;
                padding: 15px;
            }
            
            .admin-info {
                position: static;
                transform: none;
                margin-top: 10px;
                order: 3;
                width: 100%;
                text-align: center;
            }
            
            .botao_hamburguer {
                position: static;
                transform: none;
                margin-bottom: 10px;
                order: 1;
            }
            
            .logo {
                order: 2;
            }
        }
        .quantidade-input {
            width: 60px;
            padding: 5px;
            text-align: center;
            border: 1px solid var(--marrom);
            border-radius: 4px;
        }
        
        .total-section {
            background: var(--bege2);
            padding: 25px;
            border-radius: 12px;
            margin: 30px auto;
            max-width: 500px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .total-info {
            font-size: 1.4rem;
            color: var(--marrom-escuro);
            text-align: center;
            margin-bottom: 20px;
        }
        
        .pagamento-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .pagamento-form select {
            padding: 10px;
            border-radius: 6px;
            border: 1px solid var(--marrom);
            font-size: 1rem;
        }
        
        .btn-finalizar {
            background-color: var(--marrom-escuro);
            color: white;
            padding: 15px 30px;
            font-size: 1.1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn-finalizar:hover {
            background-color: var(--preto);
        }
    </style>
</head>
<body>

   <header>
        <h1 class="logo">
            <a href="principal.php">
                <img src="img/CM.png" alt="Logo CM">
            </a>
        </h1>

        <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
        
        <div class="admin-info">
            <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
        </div>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="lista_desejos.php">Lista de desejos</a>  
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
        <a href="logout.php">Sair</a>
    </div>

    <div class="container">
        <h2>Seu Carrinho</h2>
        
        <?php if (!empty($mensagem)): ?>
            <div class="mensagem sucesso"><?php echo htmlspecialchars($mensagem); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($erro)): ?>
            <div class="mensagem erro"><?php echo htmlspecialchars($erro); ?></div>
        <?php endif; ?>

        <?php if ($produtos->num_rows === 0): ?>
            <div class="lista-vazia">
                <p>Seu carrinho está vazio.</p>
                <p><a href="produtos.php" style="color: var(--marrom-escuro);">Adicione produtos</a> ao seu carrinho!</p>
            </div>
        <?php else: ?>
            <div class="produtos-grid">
                <?php while ($produto = $produtos->fetch_assoc()): 
                    $preco = ($produto['produto_promocional'] > 0 && $produto['produto_promocional'] < $produto['preco']) 
                            ? $produto['produto_promocional'] 
                            : $produto['preco'];
                    $subtotal = $preco * $produto['quantidade'];
                    $total += $subtotal;
                ?>
                    <div class="produto-card">
                        <img src="<?php echo htmlspecialchars($produto['caminho_imagem']); ?>" 
                             alt="<?php echo htmlspecialchars($produto['nome']); ?>" 
                             class="produto-imagem">
                        <div class="produto-info">
                            <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                            <p><?php echo htmlspecialchars($produto['descricao']); ?></p>
                            
                            <?php if ($produto['produto_promocional'] > 0 && $produto['produto_promocional'] < $produto['preco']): ?>
                                <p class="preco-original">De: R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                                <p class="preco-promocional">Por: R$ <?php echo number_format($produto['produto_promocional'], 2, ',', '.'); ?></p>
                            <?php else: ?>
                                <p class="preco">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                            <?php endif; ?>
                            
                            <form method="POST">
                                <input type="hidden" name="produto_id" value="<?php echo $produto['id_produto']; ?>">
                                <div style="display: flex; align-items: center; gap: 10px; margin: 15px 0;">
                                    <label>Quantidade:</label>
                                    <input type="number" name="quantidade" class="quantidade-input" 
                                           min="1" max="<?php echo $produto['estoque']; ?>" 
                                           value="<?php echo $produto['quantidade']; ?>">
                                    <button type="submit" name="atualizar" class="btn-remover">
                                        Atualizar
                                    </button>
                                </div>
                                <button type="submit" name="remover" class="btn-remover">
                                    Remover do Carrinho
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
            
            <div class="total-section">
                <div class="total-info">
                    Total: R$ <?php echo number_format($total, 2, ',', '.'); ?>
                </div>
                
                <form method="POST" class="pagamento-form">
                    <select name="forma_pagamento" required>
                        <option value="">Selecione a forma de pagamento</option>
                        <option value="Cartão de Crédito">Cartão de Crédito</option>
                        <option value="Cartão de Débito">Cartão de Débito</option>
                        <option value="PIX">PIX</option>
                        <option value="Boleto">Boleto</option>
                    </select>
                    <button type="submit" name="finalizar" class="btn-finalizar">
                        Finalizar Compra
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <div class="footer-container">
            <div class="footer-info">
                <h3>Contato</h3>
                <p>Telefone: (41) 9999-9999</p>
                <p>E-mail: <a href="mailto:CAJUMODAS@gmail.com">CAJUMODAS@gmail.com</a></p>
            </div>
            
            <div class="footer-img">
                <img src="img/CM.png" alt="Logo Caju Modas">
            </div>
            
            <div class="footer-social">
                <h3>Siga-nos:</h3>
                <a href="#" class="social-link">    
                    <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                    Tiktok
                </a>
                <a href="#" class="social-link">
                    <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                    Instagram 
                </a>
                <a href="#" class="social-link">
                    <img src="img/x.png" alt="Twitter" class="footer-icon">
                    Twitter 
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
        </div>
    </footer>
    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = menuLateral.style.width === "250px" ? "0" : "250px";
        }

        // Fechar o menu ao clicar fora
        document.addEventListener('click', function(event) {
            const menuLateral = document.getElementById("menuLateral");
            const botaoHamburguer = document.querySelector('.botao_hamburguer');
            
            if (menuLateral.style.width === "250px" && 
                !menuLateral.contains(event.target) && 
                !botaoHamburguer.contains(event.target)) {
                menuLateral.style.width = "0";
            }
        });
    </script>
</body>
</html>
<?php
$conn->close();
?>