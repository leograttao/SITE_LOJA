<?php
// Inicia a sessão
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Verifica se o usuário está logado
if (!isset($_SESSION['id_cliente'])) {
    $_SESSION['mensagem'] = "Você precisa estar logado para acessar o carrinho!";
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php");
    exit();
}

$id_cliente = $_SESSION['id_cliente'];

// Processar remoção de item do carrinho
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remover_item'])) {
    $id_produto = $_POST['id_produto'];
    
    // Obter o ID do carrinho do cliente
    $stmt_carrinho = $conn->prepare("SELECT id_carrinho FROM carrinho WHERE id_cliente = ?");
    $stmt_carrinho->bind_param("i", $id_cliente);
    $stmt_carrinho->execute();
    $result_carrinho = $stmt_carrinho->get_result();
    
    if ($result_carrinho->num_rows > 0) {
        $row_carrinho = $result_carrinho->fetch_assoc();
        $id_carrinho = $row_carrinho['id_carrinho'];
        
        // Remover o item do carrinho
        $stmt_remover = $conn->prepare("DELETE FROM carrinho_produto WHERE id_carrinho = ? AND id_produto = ?");
        $stmt_remover->bind_param("ii", $id_carrinho, $id_produto);
        
        if ($stmt_remover->execute()) {
            $_SESSION['mensagem'] = "Produto removido do carrinho com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao remover produto do carrinho: " . $stmt_remover->error;
        }
        $stmt_remover->close();
    } else {
        $_SESSION['mensagem'] = "Carrinho não encontrado!";
    }
    $stmt_carrinho->close();
    
    header("Location: carrinho.php");
    exit();
}

// Processar atualização de quantidade e tamanho
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['atualizar_item'])) {
    $id_produto = $_POST['id_produto'];
    $quantidade = intval($_POST['quantidade']);
    $tamanho = isset($_POST['tamanho']) ? $_POST['tamanho'] : null;
    
    if ($quantidade > 0) {
        // Obter o ID do carrinho do cliente
        $stmt_carrinho = $conn->prepare("SELECT id_carrinho FROM carrinho WHERE id_cliente = ?");
        $stmt_carrinho->bind_param("i", $id_cliente);
        $stmt_carrinho->execute();
        $result_carrinho = $stmt_carrinho->get_result();
        
        if ($result_carrinho->num_rows > 0) {
            $row_carrinho = $result_carrinho->fetch_assoc();
            $id_carrinho = $row_carrinho['id_carrinho'];
            
            // Verificar estoque do produto
            $stmt_estoque = $conn->prepare("SELECT estoque FROM produto WHERE id_produto = ?");
            $stmt_estoque->bind_param("i", $id_produto);
            $stmt_estoque->execute();
            $result_estoque = $stmt_estoque->get_result();
            
            if ($result_estoque->num_rows > 0) {
                $row_estoque = $result_estoque->fetch_assoc();
                $estoque_disponivel = $row_estoque['estoque'];
                
                if ($quantidade <= $estoque_disponivel) {
                    // Atualizar quantidade e tamanho no carrinho
                    $stmt_atualizar = $conn->prepare("UPDATE carrinho_produto SET quantidade = ?, tamanho = ? WHERE id_carrinho = ? AND id_produto = ?");
                    $stmt_atualizar->bind_param("isii", $quantidade, $tamanho, $id_carrinho, $id_produto);
                    
                    if ($stmt_atualizar->execute()) {
                        $_SESSION['mensagem'] = "Item atualizado com sucesso!";
                    } else {
                        $_SESSION['mensagem'] = "Erro ao atualizar item: " . $stmt_atualizar->error;
                    }
                    $stmt_atualizar->close();
                } else {
                    $_SESSION['mensagem'] = "Quantidade solicitada excede o estoque disponível!";
                }
            } else {
                $_SESSION['mensagem'] = "Produto não encontrado!";
            }
            $stmt_estoque->close();
        } else {
            $_SESSION['mensagem'] = "Carrinho não encontrado!";
        }
        $stmt_carrinho->close();
    } else {
        $_SESSION['mensagem'] = "Quantidade deve ser maior que zero!";
    }
    
    header("Location: carrinho.php");
    exit();
}

// Processar finalização da compra
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['finalizar_compra'])) {
    // Obter o ID do carrinho do cliente
    $stmt_carrinho = $conn->prepare("SELECT id_carrinho FROM carrinho WHERE id_cliente = ?");
    $stmt_carrinho->bind_param("i", $id_cliente);
    $stmt_carrinho->execute();
    $result_carrinho = $stmt_carrinho->get_result();
    
    if ($result_carrinho->num_rows > 0) {
        $row_carrinho = $result_carrinho->fetch_assoc();
        $id_carrinho = $row_carrinho['id_carrinho'];
        
        // Calcular valor total
        $sql_total = "SELECT SUM(IF(p.produto_promocional > 0 AND p.produto_promocional < p.preco, p.produto_promocional, p.preco) * cp.quantidade) as total 
                     FROM carrinho_produto cp
                     JOIN produto p ON cp.id_produto = p.id_produto
                     WHERE cp.id_carrinho = ?";
        $stmt_total = $conn->prepare($sql_total);
        $stmt_total->bind_param("i", $id_carrinho);
        $stmt_total->execute();
        $result_total = $stmt_total->get_result();
        
        if ($result_total->num_rows > 0) {
            $row_total = $result_total->fetch_assoc();
            $valor_final = $row_total['total'];
            
            // Criar registro de pagamento
            $stmt_pagamento = $conn->prepare("INSERT INTO pagamento (id_cliente, id_carrinho, valor_final, forma_pagamento, status) 
                                            VALUES (?, ?, ?, 'A definir', 'Pendente')");
            $stmt_pagamento->bind_param("iid", $id_cliente, $id_carrinho, $valor_final);
            
            if ($stmt_pagamento->execute()) {
                $_SESSION['mensagem'] = "Compra finalizada com sucesso! Redirecionando para pagamento...";
                $id_pagamento = $stmt_pagamento->insert_id;
                $_SESSION['id_pagamento'] = $id_pagamento;
                $stmt_pagamento->close();
        
                // Registrar itens vendidos - AQUI ESTÁ A CORREÇÃO PRINCIPAL
                $sql_itens = "SELECT 
                                 cp.id_produto, 
                                 SUM(cp.quantidade) as quantidade_total, 
                                 cp.tamanho, 
                                 IF(p.produto_promocional > 0 AND p.produto_promocional < p.preco, p.produto_promocional, p.preco) as preco_venda
                              FROM carrinho_produto cp
                              JOIN produto p ON cp.id_produto = p.id_produto
                              WHERE cp.id_carrinho = ?
                              GROUP BY cp.id_produto, cp.tamanho"; // Agrupa por produto e tamanho
                
                $stmt_itens = $conn->prepare($sql_itens);
                $stmt_itens->bind_param("i", $id_carrinho);
                $stmt_itens->execute();
                $result_itens = $stmt_itens->get_result();

                while ($item = $result_itens->fetch_assoc()) {
                    $stmt_item = $conn->prepare("INSERT INTO Itens_Vendidos 
                        (id_pagamento, id_produto, quantidade, tamanho, preco_unitario) 
                        VALUES (?, ?, ?, ?, ?)");
                    $stmt_item->bind_param("iiisd", $id_pagamento, $item['id_produto'], $item['quantidade_total'], $item['tamanho'], $item['preco_venda']);
                    $stmt_item->execute();
                    $stmt_item->close();
                }
                $stmt_itens->close();
                
                // Limpar o carrinho após a compra
                $stmt_limpar = $conn->prepare("DELETE FROM carrinho_produto WHERE id_carrinho = ?");
                $stmt_limpar->bind_param("i", $id_carrinho);
                $stmt_limpar->execute();
                $stmt_limpar->close();
                
                header("Location: pagamento.php");
                exit();
            } else {
                $_SESSION['mensagem'] = "Erro ao finalizar compra: " . $stmt_pagamento->error;
            }
        } else {
            $_SESSION['mensagem'] = "Carrinho vazio!";
        }
        $stmt_total->close();
    } else {
        $_SESSION['mensagem'] = "Carrinho não encontrado!";
    }
    $stmt_carrinho->close();
    
    header("Location: carrinho.php");
    exit();
}
// Obter itens do carrinho
$itens_carrinho = array();
$total_carrinho = 0;

// Verificar se o cliente já tem um carrinho
$stmt = $conn->prepare("SELECT id_carrinho FROM carrinho WHERE id_cliente = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $id_carrinho = $row['id_carrinho'];
    
    // Buscar produtos no carrinho com mais informações
    $sql_itens = "SELECT p.id_produto, p.nome, p.descricao, p.preco, p.produto_promocional, p.caminho_imagem, 
                 p.tamanho as tamanhos_disponiveis, cp.quantidade, cp.tamanho, p.estoque
                 FROM carrinho_produto cp
                 JOIN produto p ON cp.id_produto = p.id_produto
                 WHERE cp.id_carrinho = ?";
    $stmt_itens = $conn->prepare($sql_itens);
    $stmt_itens->bind_param("i", $id_carrinho);
    $stmt_itens->execute();
    $result_itens = $stmt_itens->get_result();
    
    if ($result_itens->num_rows > 0) {
        while ($row_item = $result_itens->fetch_assoc()) {
            // Usar preço promocional se disponível
            $preco = ($row_item['produto_promocional'] > 0 && $row_item['produto_promocional'] < $row_item['preco']) 
                   ? $row_item['produto_promocional'] 
                   : $row_item['preco'];
            
            $subtotal = $preco * $row_item['quantidade'];
            $total_carrinho += $subtotal;
            
            $itens_carrinho[] = array(
                'id_produto' => $row_item['id_produto'],
                'nome' => $row_item['nome'],
                'descricao' => $row_item['descricao'],
                'preco' => $preco,
                'preco_original' => $row_item['preco'],
                'quantidade' => $row_item['quantidade'],
                'tamanho' => $row_item['tamanho'],
                'tamanhos_disponiveis' => $row_item['tamanhos_disponiveis'],
                'estoque' => $row_item['estoque'],
                'caminho_imagem' => $row_item['caminho_imagem'],
                'subtotal' => $subtotal
            );
        }
    }
    $stmt_itens->close();
} else {
    // Criar um novo carrinho para o cliente se não existir
    $stmt_insert = $conn->prepare("INSERT INTO carrinho (id_cliente) VALUES (?)");
    $stmt_insert->bind_param("i", $id_cliente);
    $stmt_insert->execute();
    $stmt_insert->close();
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Caju Modas - Carrinho</title>
    <style>
            :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
    }

    header {
        background-color: var(--marrom);
        padding: 8px;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }

    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }

    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10;
        height: 100px;
        width: auto;
        max-width: none; 
    }
     
    .login {
        position: absolute;
        Right: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10;
        height: 100px;
        width: auto;
        max-width: none; 
    }
    .banner-container {
        width: 75%;
        height: 330px;
        position: relative;
        overflow: hidden;
        margin: auto;
        margin-top: 30px;
        border-radius: 20px;
        box-shadow: 0px 4px 10px var(--preto);
        margin-bottom: 20px;
    }

    .banner-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        position: absolute;
        opacity: 0;
        transition: opacity 1s ease-in-out;
    }

    .banner-container img.active {
        opacity: 1;
    }

    section {
        padding: 30px;
        text-align: center;
    }

        
        #produtos {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        #produtos h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
            color: #333;
        }
        
        .slider-container {
            position: relative;
            overflow: hidden;
            padding: 20px 0;
        }
        
        .grid-produtos {
            display: flex;
            gap: 20px;
            transition: transform 0.5s ease;
            padding: 10px 0;
        }
        
        .produto {
            min-width: 250px;
            background: var(--bege2);
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            text-align: center;
            transition: transform 0.3s ease;
            border: 2px solid var(--bege1); 
        }
        
        .produto:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        .produto img {
            width: 60%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        
        .produto p {
            margin: 10px 0;
            font-size: 1rem;
            color: var(--preto);
        }
        
        .texto-botao {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        
        .texto-botao:hover {
            background-color: var(--preto);
        }
        
        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.7);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 1rem;
            cursor: pointer;
            z-index: 10;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        
        .slider-btn:hover {
            background: var(--marrom-escuro)
        }
        
        #prevBtn {
            left: 5px;
        }
        
        #nextBtn {
            right: 5px;
        }
        
        .slider-dots {
            text-align: center;
            margin-top: 10px;
        }
        
        .dot {
            display: inline-block;
            width: 12px;
            height: 12px;
            background: var(--marrom);
            border-radius: 50%;
            margin: 0 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .dot.active {
            background: var(--marrom-escuro);
        }

    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }
         
        .login {
            position: absolute;
            Right: 20px; 
            top: 8%;
            transform: translateY(-50%);
            z-index: 10;
            height: 100px;
            width: auto;
            max-width: none; 
        }

        section {
            padding: 30px;
            text-align: center;
        }

        /* Estilos específicos do carrinho */
        .carrinho-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            margin-top: 160px;
            margin-bottom: 160px;
        }

        .itens-carrinho {
            flex: 2;
            background-color: var(--bege2);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .resumo-carrinho {
            flex: 1;
            background-color: var(--bege2);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            align-self: flex-start;
            position: sticky;
            top: 20px;
        }

        .item-carrinho {
            display: flex;
            gap: 20px;
            padding: 15px 0;
            border-bottom: 1px solid var(--marrom);
            align-items: center;
        }

        .item-carrinho:last-child {
            border-bottom: none;
        }

        .item-imagem {
            width: 100px;
            height: 120px;
            object-fit: cover;
            border-radius: 5px;
        }

        .item-info {
            flex: 1;
            text-align: left;
        }

        .item-nome {
            font-weight: bold;
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--preto);
        }

        .item-preco {
            color: var(--marrom-escuro);
            font-weight: bold;
        }

        .item-preco-original {
            text-decoration: line-through;
            color: #777;
            font-size: 0.9rem;
        }

        .item-acoes {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .quantidade-container {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .quantidade-input {
            width: 50px;
            text-align: center;
            padding: 5px;
            border: 1px solid var(--marrom);
            border-radius: 4px;
        }

        .btn-remover {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-remover:hover {
            background-color: #c9302c;
        }

        .btn-atualizar {
            background-color: var(--marrom);
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-atualizar:hover {
            background-color: var(--marrom-escuro);
        }

        .resumo-titulo {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: var(--preto);
            text-align: center;
        }

        .resumo-linha {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding: 8px 0;
            border-bottom: 1px solid var(--marrom);
        }

        .resumo-total {
            font-weight: bold;
            font-size: 1.2rem;
            margin-top: 20px;
            color: var(--preto);
        }

        .btn-finalizar {
            width: 100%;
            padding: 12px;
            background-color: var(--marrom-escuro);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s;
        }

        .btn-finalizar:hover {
            background-color: var(--preto);
        }

        .carrinho-vazio {
            text-align: center;
            padding: 90px;
            font-size: 1.2rem;
            color: var(--marrom-escuro);
            border: 2px dashed var(--bege2);
            border-radius: 12px;
            margin: 40px 0;
        }

        .btn-continuar {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: var(--marrom);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .btn-continuar:hover {
            background-color: var(--marrom-escuro);
        }

        /* Estilos compartilhados com a página de produtos */
        footer {
            background-color: var(--marrom);
            color: var(--bege1);
            padding: 1px 0; 
            margin-top: 10px; 
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            flex-wrap: wrap; 
            padding: 10px 0;
            border-bottom: 3px solid #333;
        }

        .footer-info, .footer-img, .footer-social {
            flex: 1;
            padding: 5px; 
            text-align: center; 
        }

        .footer-img img {
            width: 105;
            height: 100px;
            border-radius: 8px;
        }

        .footer-social {
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: flex-end; 
            gap: 8px; 
            padding-right: 20px; 
        }

        .footer-social a {
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--bege1);
            text-decoration: none;
            flex-direction: row-reverse; 
            font-size: 22px;
        }

        .footer-icon {
            width: 37px; 
            height: 37px;
            margin-left: 12px; 
            transition: transform 0.3s;
        }

        .footer-social a:hover .footer-icon {
            transform: scale(1.2);
        }

        .footer-bottom {
            margin-top: 10px;
            font-size: 14px;
            text-align: center;
        }

        .texto-botao {
            color: white;
        }

        .logo {
            margin: 0;
            padding: 0;
        }
        
        .logo img {
            height: 140px;
            vertical-align: middle;
        }

        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px;
            background-color: var(--marrom-escuro);
            color: white;
            border-radius: 5px;
            z-index: 1000;
            animation: fadeInOut 3s ease-in-out;
            opacity: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        @keyframes fadeInOut {
            0% { opacity: 0; transform: translateY(-20px); }
            20% { opacity: 1; transform: translateY(0); }
            80% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(-20px); }
        }

        .admin-info {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            color: var(--preto);
            gap: 5px;
        }

        .logo {
            flex: 1;
            text-align: center;
        }

        .logo img {
            height: 140px;
        }
        
        .item-descricao {
            margin: 10px 0;
            color: #555;
            font-size: 0.9rem;
            max-height: 60px;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }
        
        .item-descricao.expandida {
            max-height: 500px;
        }
        
        .btn-expandir {
            background: none;
            border: none;
            color: var(--marrom-escuro);
            cursor: pointer;
            padding: 0;
            font-size: 0.9rem;
            margin-top: 5px;
        }
        
        .btn-expandir:hover {
            text-decoration: underline;
        }
        
        .tamanho-container {
            margin-top: 10px;
        }
        
        .tamanho-select {
            padding: 5px;
            border: 1px solid var(--marrom);
            border-radius: 4px;
            background-color: white;
        }
        
        .tamanho-selecionado {
            font-weight: bold;
            color: var(--marrom-escuro);
        }
    </style>
</head>
<body>
    <header>
        <h1 class="logo">
            <a>
              <img src="img/CM.png" alt="Logo CM">
            </a>
          </h1>
          <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
        <div class="admin-info">
            <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
        </div>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="lista_desejos.php">Lista de desejos</a>  
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
        <a href="logout.php">Sair</a>
    </div>

    <?php if (isset($_SESSION['mensagem'])): ?>
        <div class="alert">
            <i class="fas fa-check-circle"></i>
            <?php echo $_SESSION['mensagem']; unset($_SESSION['mensagem']); ?>
        </div>
    <?php endif; ?>

    <section class="carrinho-container">
        <?php if (!empty($itens_carrinho)): ?>
            <div class="itens-carrinho">
                <h2>Seu Carrinho</h2>
                
                <?php foreach ($itens_carrinho as $item): ?>
                    <div class="item-carrinho">
                        <img src="<?php echo htmlspecialchars($item['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($item['nome']); ?>" class="item-imagem">
                        
                        <div class="item-info">
                            <div class="item-nome"><?php echo htmlspecialchars($item['nome']); ?></div>
                            <?php if ($item['preco'] < $item['preco_original']): ?>
                                <div class="item-preco-original">De: R$ <?php echo number_format($item['preco_original'], 2, ',', '.'); ?></div>
                                <div class="item-preco">Por: R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></div>
                            <?php else: ?>
                                <div class="item-preco">R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></div>
                            <?php endif; ?>
                            
                            <?php if (!empty($item['descricao'])): ?>
                                <div class="item-descricao" id="descricao-<?php echo $item['id_produto']; ?>">
                                    <?php echo nl2br(htmlspecialchars(substr($item['descricao'], 0, 100))); ?>
                                    <?php if (strlen($item['descricao']) > 100): ?>
                                        <span id="mais-<?php echo $item['id_produto']; ?>" style="display:none;">
                                            <?php echo nl2br(htmlspecialchars(substr($item['descricao'], 100))); ?>
                                        </span>
                                        <button class="btn-expandir" onclick="toggleDescricao(<?php echo $item['id_produto']; ?>)">
                                            Ver mais
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                            <div>Estoque disponível: <?php echo $item['estoque']; ?></div>
                            
                            <div class="tamanho-container">
                                <?php if (!empty($item['tamanhos_disponiveis'])): ?>
                                    <form method="post" class="tamanho-form">
                                        <input type="hidden" name="id_produto" value="<?php echo $item['id_produto']; ?>">
                                        <input type="hidden" name="quantidade" value="<?php echo $item['quantidade']; ?>">
                                        <label for="tamanho-<?php echo $item['id_produto']; ?>">Tamanho:</label>
                                        <select name="tamanho" id="tamanho-<?php echo $item['id_produto']; ?>" class="tamanho-select" onchange="this.form.submit()">
                                            <?php 
                                            $tamanhos = explode(',', $item['tamanhos_disponiveis']);
                                            foreach ($tamanhos as $t): 
                                                $t = trim($t);
                                            ?>
                                                <option value="<?php echo htmlspecialchars($t); ?>" <?php echo $item['tamanho'] == $t ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($t); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input type="hidden" name="atualizar_item">
                                    </form>
                                    <?php if (!empty($item['tamanho'])): ?>
                                        <div class="tamanho-selecionado">Tamanho selecionado: <?php echo htmlspecialchars($item['tamanho']); ?></div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="item-acoes">
                            <form method="post" class="quantidade-container">
                                <input type="hidden" name="id_produto" value="<?php echo $item['id_produto']; ?>">
                                <input type="hidden" name="tamanho" value="<?php echo htmlspecialchars($item['tamanho']); ?>">
                                <input type="number" name="quantidade" min="1" max="<?php echo $item['estoque']; ?>" 
                                       value="<?php echo $item['quantidade']; ?>" class="quantidade-input">
                                <button type="submit" name="atualizar_item" class="btn-atualizar">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                            </form>
                            
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $item['id_produto']; ?>">
                                <button type="submit" name="remover_item" class="btn-remover">
                                    <i class="fas fa-trash-alt"></i> Remover
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="resumo-carrinho">
                <h3 class="resumo-titulo">Resumo do Pedido</h3>
                
                <?php foreach ($itens_carrinho as $item): ?>
                    <div class="resumo-linha">
                        <span>
                            <?php echo htmlspecialchars($item['nome']); ?> 
                            (<?php echo $item['quantidade']; ?>x)
                            <?php if (!empty($item['tamanho'])): ?>
                                - Tamanho: <?php echo htmlspecialchars($item['tamanho']); ?>
                            <?php endif; ?>
                        </span>
                        <span>R$ <?php echo number_format($item['subtotal'], 2, ',', '.'); ?></span>
                    </div>
                <?php endforeach; ?>
                
                <div class="resumo-linha resumo-total">
                    <span>Total</span>
                    <span>R$ <?php echo number_format($total_carrinho, 2, ',', '.'); ?></span>
                </div>
                
                <form method="post">
                    <button type="submit" name="finalizar_compra" class="btn-finalizar">
                        <i class="fas fa-credit-card"></i> Finalizar Compra
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="carrinho-vazio">
                <i class="fas fa-shopping-cart fa-3x" style="margin-bottom: 20px;"></i>
                <p>Seu carrinho está vazio</p>
                <a href="produtos.php" class="btn-continuar">Continuar Comprando</a>
            </div>
        <?php endif; ?>
    </section>

    <footer>
        <div class="footer-container">
            <div class="footer-info">
                <h2>Contato</h2>
                <p>Telefone: (41) 9999-9999</p>
                <p>E-mail: <a href="">CAJUMODAS@gmail.com</a></p>
            </div>
            
            <div class="footer-img">
                <img src="img/CM.png" alt="Logo Caju Modas">
            </div>
            
            <div class="footer-social">
                <h2>Siga-nos:</h2>
                <a href="" class="social-link">    
                    <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                    Tiktok
                </a>
                <a href="" class="social-link">
                    <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                    Instagram 
                </a>
                <a href="" class="social-link">
                    <img src="img/x.png" alt="Twitter" class="footer-icon">
                    Twitter 
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
        </div>
    </footer>

    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }

        // Esconder mensagem após 3 segundos
        document.addEventListener('DOMContentLoaded', function() {
            const alert = document.querySelector('.alert');
            if (alert) {
                setTimeout(() => {
                    alert.style.display = 'none';
                }, 3000);
            }
        });
        
        function toggleDescricao(id) {
            const descricao = document.getElementById(`descricao-${id}`);
            const mais = document.getElementById(`mais-${id}`);
            const btn = descricao.querySelector('.btn-expandir');
            
            if (mais.style.display === "none") {
                mais.style.display = "inline";
                btn.textContent = "Ver menos";
                descricao.classList.add('expandida');
            } else {
                mais.style.display = "none";
                btn.textContent = "Ver mais";
                descricao.classList.remove('expandida');
            }
        }
    </script>
</body>
</html>