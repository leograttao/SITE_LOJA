
<?php
// Inicia a sessão
session_start();

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario'])) {
    $_SESSION['mensagem'] = "Você precisa estar logado para realizar esta ação!";
    header("Location: login.php"); // Redireciona para a página de login
    exit();
}

// Processar adição ao carrinho
if (isset($_POST['adicionar_carrinho'])) {
    $id_produto = (int)$_POST['id_produto'];
    $id_cliente = (int)$_SESSION['usuario']['id_cliente'];
    
    try {
        // Verificar/Criar carrinho
        $result = $conn->query("SELECT id_carrinho FROM carrinho WHERE id_cliente = $id_cliente");
        $id_carrinho = $result->num_rows > 0 
            ? $result->fetch_assoc()['id_carrinho'] 
            : $conn->query("INSERT INTO carrinho (id_cliente) VALUES ($id_cliente)")->insert_id;
        
        // Adicionar produto
        $conn->query("INSERT INTO carrinho_produto (id_carrinho, id_produto, quantidade) 
                     VALUES ($id_carrinho, $id_produto, 1)
                     ON DUPLICATE KEY UPDATE quantidade = quantidade + 1");
        
        $_SESSION['mensagem'] = "Produto adicionado ao carrinho!";
    } catch (Exception $e) {
        $_SESSION['mensagem'] = "Erro ao adicionar ao carrinho: " . $e->getMessage();
    }
    
    header("Location: ".$_SERVER['REQUEST_URI']);
    exit();
}

// Processar adição à lista de desejos
if (isset($_POST['adicionar_lista_desejos'])) {
    $id_produto = (int)$_POST['id_produto'];
    $id_cliente = (int)$_SESSION['usuario']['id_cliente'];
    
    try {
        // Passo 1: Verificar se o produto existe
        $sql_produto = "SELECT id_produto FROM produto WHERE id_produto = ?";
        $stmt = $conn->prepare($sql_produto);
        $stmt->bind_param("i", $id_produto);
        $stmt->execute();
        $result_produto = $stmt->get_result();
        
        if ($result_produto->num_rows === 0) {
            throw new Exception("Produto não encontrado!");
        }

        // Passo 2: Verificar se o cliente existe
        $sql_cliente = "SELECT id_cliente FROM cliente WHERE id_cliente = ?";
        $stmt = $conn->prepare($sql_cliente);
        $stmt->bind_param("i", $id_cliente);
        $stmt->execute();
        $result_cliente = $stmt->get_result();
        
        if ($result_cliente->num_rows === 0) {
            throw new Exception("Cliente não encontrado!");
        }

        // Passo 3: Obter ou criar a lista de desejos do cliente
        $sql_lista = "SELECT id_lista FROM lista_desejos WHERE id_cliente = ?";
        $stmt = $conn->prepare($sql_lista);
        $stmt->bind_param("i", $id_cliente);
        $stmt->execute();
        $result_lista = $stmt->get_result();
        
        if ($result_lista->num_rows > 0) {
            $row = $result_lista->fetch_assoc();
            $id_lista = $row['id_lista'];
        } else {
            $sql_insert_lista = "INSERT INTO lista_desejos (id_cliente) VALUES (?)";
            $stmt = $conn->prepare($sql_insert_lista);
            $stmt->bind_param("i", $id_cliente);
            
            if ($stmt->execute()) {
                $id_lista = $stmt->insert_id;
            } else {
                throw new Exception("Erro ao criar lista de desejos: " . $conn->error);
            }
        }

        // Passo 4: Verificar se o produto já está na lista
        $sql_verifica = "SELECT 1 FROM lista_desejos_produto WHERE id_lista = ? AND id_produto = ?";
        $stmt = $conn->prepare($sql_verifica);
        $stmt->bind_param("ii", $id_lista, $id_produto);
        $stmt->execute();
        $result_verifica = $stmt->get_result();
        
        if ($result_verifica->num_rows === 0) {
            // Passo 5: Adicionar o produto à lista
            $sql_insert = "INSERT INTO lista_desejos_produto (id_lista, id_produto) VALUES (?, ?)";
            $stmt = $conn->prepare($sql_insert);
            $stmt->bind_param("ii", $id_lista, $id_produto);
            
            if ($stmt->execute()) {
                $_SESSION['mensagem'] = "Produto adicionado à lista de desejos com sucesso!";
            } else {
                throw new Exception("Erro ao adicionar produto: " . $conn->error);
            }
        } else {
            $_SESSION['mensagem'] = "Este produto já está na sua lista de desejos!";
        }
    } catch (Exception $e) {
        $_SESSION['mensagem'] = $e->getMessage();
    }
    
    header("Location: ".$_SERVER['REQUEST_URI']);
    exit();
}

// Processar adição ao carrinho
if (isset($_POST['adicionar_carrinho'])) {
    $id_produto = (int)$_POST['id_produto'];
    $id_cliente = (int)$_SESSION['usuario']['id_cliente'];
    
    // Verificar/Criar carrinho
    $result = $conn->query("SELECT id_carrinho FROM carrinho WHERE id_cliente = $id_cliente");
    $id_carrinho = $result->num_rows > 0 
        ? $result->fetch_assoc()['id_carrinho'] 
        : $conn->query("INSERT INTO carrinho (id_cliente) VALUES ($id_cliente)")->insert_id;
    
    // Adicionar produto
    $conn->query("INSERT INTO carrinho_produto (id_carrinho, id_produto, quantidade) 
                 VALUES ($id_carrinho, $id_produto, 1)
                 ON DUPLICATE KEY UPDATE quantidade = quantidade + 1");
    
    $_SESSION['mensagem'] = "Produto adicionado ao carrinho!";
    header("Location: ".$_SERVER['REQUEST_URI']);
    exit();
}

// Processar adição à lista de desejos
if (isset($_POST['adicionar_lista_desejos'])) {
    $id_produto = (int)$_POST['id_produto'];
    $id_cliente = (int)$_SESSION['usuario']['id_cliente'];
    
    // Passo 1: Verificar se o produto existe
    $sql_produto = "SELECT id_produto FROM produto WHERE id_produto = ?";
    $stmt = $conn->prepare($sql_produto);
    $stmt->bind_param("i", $id_produto);
    $stmt->execute();
    $result_produto = $stmt->get_result();
    
    if ($result_produto->num_rows === 0) {
        $_SESSION['mensagem'] = "Erro: Produto não encontrado!";
        header("Location: ".$_SERVER['REQUEST_URI']);
        exit();
    }

    // Passo 2: Obter ou criar a lista de desejos do cliente
    $sql_lista = "SELECT id_lista FROM lista_desejos WHERE id_cliente = ?";
    $stmt = $conn->prepare($sql_lista);
    $stmt->bind_param("i", $id_cliente);
    $stmt->execute();
    $result_lista = $stmt->get_result();
    
    if ($result_lista->num_rows > 0) {
        $row = $result_lista->fetch_assoc();
        $id_lista = $row['id_lista'];
    } else {
        $sql_insert_lista = "INSERT INTO lista_desejos (id_cliente) VALUES (?)";
        $stmt = $conn->prepare($sql_insert_lista);
        $stmt->bind_param("i", $id_cliente);
        
        if ($stmt->execute()) {
            $id_lista = $stmt->insert_id;
        } else {
            $_SESSION['mensagem'] = "Erro ao criar lista de desejos: " . $conn->error;
            header("Location: ".$_SERVER['REQUEST_URI']);
            exit();
        }
    }

    // Passo 3: Verificar se o produto já está na lista
    $sql_verifica = "SELECT 1 FROM lista_desejos_produto WHERE id_lista = ? AND id_produto = ?";
    $stmt = $conn->prepare($sql_verifica);
    $stmt->bind_param("ii", $id_lista, $id_produto);
    $stmt->execute();
    $result_verifica = $stmt->get_result();
    
    if ($result_verifica->num_rows === 0) {
        // Passo 4: Adicionar o produto à lista
        $sql_insert = "INSERT INTO lista_desejos_produto (id_lista, id_produto) VALUES (?, ?)";
        $stmt = $conn->prepare($sql_insert);
        $stmt->bind_param("ii", $id_lista, $id_produto);
        
        if ($stmt->execute()) {
            $_SESSION['mensagem'] = "Produto adicionado à lista de desejos com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao adicionar produto: " . $conn->error;
        }
    } else {
        $_SESSION['mensagem'] = "Este produto já está na sua lista de desejos!";
    }
    
    header("Location: ".$_SERVER['REQUEST_URI']);
    exit();
}

// Busca produtos em destaque (com desconto)
$sql_produtos_desconto = "SELECT id_produto, nome, descricao, preco, produto_promocional, estoque, caminho_imagem, tamanho 
                         FROM Produto
                         WHERE produto_promocional > 0 AND produto_promocional < preco LIMIT 5";

// Busca produtos por categoria (tipo_roupa)
$sql_vestidos = "SELECT id_produto, nome, descricao, preco, caminho_imagem FROM Produto WHERE tipo_roupa = 'vestido' LIMIT 5";
$sql_saias = "SELECT id_produto, nome, descricao, preco, caminho_imagem FROM Produto WHERE tipo_roupa = 'saias' LIMIT 5";
$sql_blusas = "SELECT id_produto, nome, descricao, preco, caminho_imagem FROM Produto WHERE tipo_roupa = 'blusas' LIMIT 5";
$sql_casacos = "SELECT id_produto, nome, descricao, preco, caminho_imagem FROM Produto WHERE tipo_roupa = 'casaco' LIMIT 5";

// Executa as queries
$result_produtos_desconto = $conn->query($sql_produtos_desconto);
$result_vestidos = $conn->query($sql_vestidos);
$result_saias = $conn->query($sql_saias);
$result_blusas = $conn->query($sql_blusas);
$result_casacos = $conn->query($sql_casacos);

// Armazena os resultados
$produtos_desconto = $result_produtos_desconto ? $result_produtos_desconto->fetch_all(MYSQLI_ASSOC) : array();
$vestidos = $result_vestidos ? $result_vestidos->fetch_all(MYSQLI_ASSOC) : array();
$saias = $result_saias ? $result_saias->fetch_all(MYSQLI_ASSOC) : array();
$blusas = $result_blusas ? $result_blusas->fetch_all(MYSQLI_ASSOC) : array();
$casacos = $result_casacos ? $result_casacos->fetch_all(MYSQLI_ASSOC) : array();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Caju Modas - Produtos</title>
    </style>
</head>
<body>
    <header>
        <h1 class="logo">
            <a>
              <img src="img/CM.png" alt="Logo CM">
            </a>
          </h1>
          <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="lista_desejos.php">Lista de desejos</a>  
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
        <a href="logout.php">Sair</a>
    </div>

    <?php if (isset($_SESSION['mensagem'])): ?>
        <div class="alert">
            <i class="fas fa-check-circle"></i>
            <?php echo $_SESSION['mensagem']; unset($_SESSION['mensagem']); ?>
        </div>
    <?php endif; ?>

    <!-- Seção de Produtos com desconto -->
    <section id="produtos">
        <h2>Produtos com desconto</h2>
        <div class="slider-container">
            <button class="slider-btn" id="prevBtnDesconto">&#10094;</button>
            <div class="grid-produtos" id="gridDesconto">
                <?php foreach ($produtos_desconto as $produto): ?>
                    <div class="produto">
                        <img src="<?php echo htmlspecialchars($produto['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                        <p><?php echo htmlspecialchars($produto['nome']); ?></p>
                        <p style="text-decoration: line-through; color: #777;">De: R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                        <p style="font-weight: bold; color: #d00;">Por: R$ <?php echo number_format($produto['produto_promocional'], 2, ',', '.'); ?></p>
                        
                        <div class="produto-actions">
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_carrinho" class="texto-botao">
                                    <i class="fas fa-shopping-cart"></i> Carrinho
                                </button>
                            </form>
                            
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_lista_desejos" class="texto-botao wishlist-btn">
                                    <i class="fas fa-heart"></i> Lista
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if (empty($produtos_desconto)): ?>
                    <div class="produto">
                        <p>Nenhum produto em desconto encontrado.</p>
                    </div>
                <?php endif; ?>
            </div>
            <button class="slider-btn" id="nextBtnDesconto">&#10095;</button>
        </div>
        <div class="slider-dots" id="dotsContainerDesconto"></div>
    </section>

    <!-- Seção de Vestidos -->
    <section id="produtos">
        <h2>Vestidos</h2>
        <div class="slider-container">
            <button class="slider-btn" id="prevBtnVestidos">&#10094;</button>
            <div class="grid-produtos" id="gridVestidos">
                <?php foreach ($vestidos as $produto): ?>
                    <div class="produto">
                        <img src="<?php echo htmlspecialchars($produto['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                        <p><?php echo htmlspecialchars($produto['nome']); ?> - R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                        
                        <div class="produto-actions">
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_carrinho" class="texto-botao">
                                    <i class="fas fa-shopping-cart"></i> Carrinho
                                </button>
                            </form>
                            
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_lista_desejos" class="texto-botao wishlist-btn">
                                    <i class="fas fa-heart"></i> Lista
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if (empty($vestidos)): ?>
                    <div class="produto">
                        <p>Nenhum vestido encontrado.</p>
                    </div>
                <?php endif; ?>
            </div>
            <button class="slider-btn" id="nextBtnVestidos">&#10095;</button>
        </div>
        <div class="slider-dots" id="dotsContainerVestidos"></div>
    </section>

    <!-- Seção de Saias -->
    <section id="produtos">
        <h2>Saias</h2>
        <div class="slider-container">
            <button class="slider-btn" id="prevBtnSaias">&#10094;</button>
            <div class="grid-produtos" id="gridSaias">
                <?php foreach ($saias as $produto): ?>
                    <div class="produto">
                        <img src="<?php echo htmlspecialchars($produto['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                        <p><?php echo htmlspecialchars($produto['nome']); ?> - R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                        
                        <div class="produto-actions">
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_carrinho" class="texto-botao">
                                    <i class="fas fa-shopping-cart"></i> Carrinho
                                </button>
                            </form>
                            
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_lista_desejos" class="texto-botao wishlist-btn">
                                    <i class="fas fa-heart"></i> Lista
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if (empty($saias)): ?>
                    <div class="produto">
                        <p>Nenhuma saia encontrada.</p>
                    </div>
                <?php endif; ?>
            </div>
            <button class="slider-btn" id="nextBtnSaias">&#10095;</button>
        </div>
        <div class="slider-dots" id="dotsContainerSaias"></div>
    </section>

    <!-- Seção de Blusas -->
    <section id="produtos">
        <h2>Blusas</h2>
        <div class="slider-container">
            <button class="slider-btn" id="prevBtnBlusas">&#10094;</button>
            <div class="grid-produtos" id="gridBlusas">
                <?php foreach ($blusas as $produto): ?>
                    <div class="produto">
                        <img src="<?php echo htmlspecialchars($produto['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                        <p><?php echo htmlspecialchars($produto['nome']); ?> - R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                        
                        <div class="produto-actions">
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_carrinho" class="texto-botao">
                                    <i class="fas fa-shopping-cart"></i> Carrinho
                                </button>
                            </form>
                            
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_lista_desejos" class="texto-botao wishlist-btn">
                                    <i class="fas fa-heart"></i> Lista
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if (empty($blusas)): ?>
                    <div class="produto">
                        <p>Nenhuma blusa encontrada.</p>
                    </div>
                <?php endif; ?>
            </div>
            <button class="slider-btn" id="nextBtnBlusas">&#10095;</button>
        </div>
        <div class="slider-dots" id="dotsContainerBlusas"></div>
    </section>

    <!-- Seção de Casacos -->
    <section id="produtos">
        <h2>Casacos</h2>
        <div class="slider-container">
            <button class="slider-btn" id="prevBtnCasacos">&#10094;</button>
            <div class="grid-produtos" id="gridCasacos">
                <?php foreach ($casacos as $produto): ?>
                    <div class="produto">
                        <img src="<?php echo htmlspecialchars($produto['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                        <p><?php echo htmlspecialchars($produto['nome']); ?> - R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                        
                        <div class="produto-actions">
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_carrinho" class="texto-botao">
                                    <i class="fas fa-shopping-cart"></i> Carrinho
                                </button>
                            </form>
                            
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_lista_desejos" class="texto-botao wishlist-btn">
                                    <i class="fas fa-heart"></i> Lista
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if (empty($casacos)): ?>
                    <div class="produto">
                        <p>Nenhum casaco encontrado.</p>
                    </div>
                <?php endif; ?>
            </div>
            <button class="slider-btn" id="nextBtnCasacos">&#10095;</button>
        </div>
        <div class="slider-dots" id="dotsContainerCasacos"></div>
    </section>

    <footer>
        <div class="footer-container">
            <div class="footer-info">
                <h2>Contato</h2>
                <p>Telefone: (41) 9999-9999</p>
                <p>E-mail: <a href="">CAJUMODAS@gmail.com</a></p>
            </div>
            
            <div class="footer-img">
                <img src="img/CM.png" alt="Logo Caju Modas">
            </div>
            
            <div class="footer-social">
                <h2>Siga-nos:</h2>
                <a href="" class="social-link">    
                    <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                    Tiktok
                </a>
                <a href="" class="social-link">
                    <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                    Instagram 
                </a>
                <a href="" class="social-link">
                    <img src="img/x.png" alt="Twitter" class="footer-icon">
                    Twitter 
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
        </div>
    </footer>

    <script>
        // Função para inicializar um slider
        function initSlider(prefix) {
            const slider = document.getElementById(`grid${prefix}`);
            const prevBtn = document.getElementById(`prevBtn${prefix}`);
            const nextBtn = document.getElementById(`nextBtn${prefix}`);
            const dotsContainer = document.getElementById(`dotsContainer${prefix}`);
            
            const produtos = slider.querySelectorAll('.produto');
            if (produtos.length === 0) return;
            
            const produtoWidth = produtos[0].offsetWidth + 20;
            let currentIndex = 0;
            
            // Criar dots
            produtos.forEach((_, index) => {
                const dot = document.createElement('span');
                dot.classList.add('dot');
                if (index === 0) dot.classList.add('active');
                dot.addEventListener('click', () => {
                    goToSlide(index);
                });
                dotsContainer.appendChild(dot);
            });
            
            const dots = dotsContainer.querySelectorAll('.dot');
            
            function updateDots() {
                dots.forEach((dot, index) => {
                    dot.classList.toggle('active', index === currentIndex);
                });
            }
            
            function goToSlide(index) {
                currentIndex = index;
                slider.style.transform = `translateX(-${currentIndex * produtoWidth}px)`;
                updateDots();
            }
            
            // Next slide with loop
            nextBtn.addEventListener('click', () => {
                if (currentIndex < produtos.length - 1) {
                    currentIndex++;
                } else {
                    currentIndex = 0;
                }
                slider.style.transform = `translateX(-${currentIndex * produtoWidth}px)`;
                updateDots();
            });
            
            // Previous slide with loop
            prevBtn.addEventListener('click', () => {
                if (currentIndex > 0) {
                    currentIndex--;
                } else {
                    currentIndex = produtos.length - 1;
                }
                slider.style.transform = `translateX(-${currentIndex * produtoWidth}px)`;
                updateDots();
            });
            
            // Responsive adjustments
            window.addEventListener('resize', function() {
                const newProdutoWidth = produtos[0].offsetWidth + 20;
                slider.style.transform = `translateX(-${currentIndex * newProdutoWidth}px)`;
            });
        }

        // Inicializar todos os sliders
        document.addEventListener('DOMContentLoaded', function() {
            initSlider('Desconto');
            initSlider('Vestidos');
            initSlider('Saias');
            initSlider('Blusas');
            initSlider('Casacos');
            
            // Esconder mensagem após 3 segundos
            const alert = document.querySelector('.alert');
            if (alert) {
                setTimeout(() => {
                    alert.style.display = 'none';
                }, 3000);
            }
        });

        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }
    </script>
</body>
</html>

<style>
        /* Seus estilos CSS existentes */
        :root {
            --amarelo: #f4d06f;
            --marrom: #b39977;
            --bege1: #EDE6D9;
            --bege2: #ddcfb6;
            --bege3: #e3d6be;
            --preto: #342519;
            --marrom-escuro: #684F36;
        }

        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: linear-gradient(180deg, var(--bege1), var(--bege3));
        }

        header {
            background-color: var(--marrom);
            padding: 8px;
            text-align: center;
            box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
            height: 138px;
        }

        .menu-lateral {
            height: 100%;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: var(--bege2);
            overflow-x: hidden;
            transition: width 0.5s; 
            padding-top: 70px;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
            z-index: 20;             
        }

        .menu-lateral .fechar {
            position: absolute;
            top: 1px;
            right: 20px;
            font-size: 25px;
            color: var(--bege);
            background: none;
            border: none;
            cursor: pointer;
            transition: color 0.3s;
        }

        .menu-lateral a {
            padding: 15px 20px;
            text-decoration: none;
            font-size: 20px;
            color: var(--preto);
            display: block;
            margin: 10px 0;
            transition: 0.3s;
        }

        .menu-lateral a:hover {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            transform: scale(1.05);
        }

        .botao_hamburguer {
            position: absolute;
            left: 20px; 
            top: 8%;
            transform: translateY(-50%);
            z-index: 10;
            height: 100px;
            width: auto;
            max-width: none; 
        }
         
        .login {
            position: absolute;
            Right: 20px; 
            top: 8%;
            transform: translateY(-50%);
            z-index: 10;
            height: 100px;
            width: auto;
            max-width: none; 
        }

        section {
            padding: 30px;
            text-align: center;
        }

        #produtos {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        #produtos h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
            color: #333;
        }
        
        .slider-container {
            position: relative;
            overflow: hidden;
            padding: 20px 0;
        }
        
        .grid-produtos {
            display: flex;
            gap: 20px;
            transition: transform 0.5s ease;
            padding: 10px 0;
        }
        
        .produto {
            min-width: 250px;
            background: var(--bege2);
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            text-align: center;
            transition: transform 0.3s ease;
            border: 2px solid var(--bege1); 
        }
        
        .produto:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        .produto img {
            width: 60%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        
        .produto p {
            margin: 10px 0;
            font-size: 1rem;
            color: var(--preto);
        }
        
        .texto-botao {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        
        .texto-botao:hover {
            background-color: var(--preto);
        }
        
        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.7);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 1rem;
            cursor: pointer;
            z-index: 10;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        
        .slider-btn:hover {
            background: var(--marrom-escuro);
        }
        
        #prevBtnDesconto, #prevBtnVestidos, #prevBtnSaias, #prevBtnBlusas, #prevBtnCasacos {
            left: 5px;
        }
        
        #nextBtnDesconto, #nextBtnVestidos, #nextBtnSaias, #nextBtnBlusas, #nextBtnCasacos {
            right: 5px;
        }
        
        .slider-dots {
            text-align: center;
            margin-top: 10px;
        }
        
        .dot {
            display: inline-block;
            width: 12px;
            height: 12px;
            background: var(--marrom);
            border-radius: 50%;
            margin: 0 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .dot.active {
            background: var(--marrom-escuro);
        }

        button {
            background-color: var(--marrom); 
            color: var(--bege2);
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        button:hover {
            background-color: var(--marrom-escuro);
        }

        footer {
            background-color: var(--marrom);
            color: var(--bege1);
            padding: 1px 0; 
            margin-top: 10px; 
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            flex-wrap: wrap; 
            padding: 10px 0;
            border-bottom: 3px solid #333;
        }

        .footer-info, .footer-img, .footer-social {
            flex: 1;
            padding: 5px; 
            text-align: center; 
        }

        .footer-img img {
            width: 105;
            height: 100px;
            border-radius: 8px;
        }

        .footer-social {
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: flex-end; 
            gap: 8px; 
            padding-right: 20px; 
        }

        .footer-social a {
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--bege1);
            text-decoration: none;
            flex-direction: row-reverse; 
            font-size: 22px;
        }

        .footer-icon {
            width: 37px; 
            height: 37px;
            margin-left: 12px; 
            transition: transform 0.3s;
        }

        .footer-social a:hover .footer-icon {
            transform: scale(1.2);
        }

        .footer-bottom {
            margin-top: 10px;
            font-size: 14px;
            text-align: center;
        }

        .texto-botao {
            color: white;
        }

        .logo {
            margin: 0;
            padding: 0;
        }
        
        .logo img {
            height: 140px;
            vertical-align: middle;
        }
        
        /* Novos estilos adicionados */
        .produto-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }

        .produto-actions form {
            flex: 1;
            margin: 0 3px;
        }

        .produto-actions button {
            width: 100%;
            padding: 8px;
            font-size: 0.9rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .wishlist-btn {
            background-color: var(--marrom) !important;
        }

        .wishlist-btn:hover {
            background-color: var(--marrom-escuro) !important;
        }

        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px;
            background-color: var(--marrom-escuro);
            color: white;
            border-radius: 5px;
            z-index: 1000;
            animation: fadeInOut 3s ease-in-out;
            opacity: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        @keyframes fadeInOut {
            0% { opacity: 0; transform: translateY(-20px); }
            20% { opacity: 1; transform: translateY(0); }
            80% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(-20px); }
        }
        
        /* Estilos adicionais para os botões de ação */
        .produto-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }

        .produto-actions form {
            flex: 1;
            margin: 0 3px;
        }

        .produto-actions button {
            width: 100%;
            padding: 8px;
            font-size: 0.9rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .wishlist-btn {
            background-color: var(--marrom) !important;
        }

        .wishlist-btn:hover {
            background-color: var(--marrom-escuro) !important;
        }

        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px;
            background-color: var(--marrom-escuro);
            color: white;
            border-radius: 5px;
            z-index: 1000;
            animation: fadeInOut 3s ease-in-out;
            opacity: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        @keyframes fadeInOut {
            0% { opacity: 0; transform: translateY(-20px); }
            20% { opacity: 1; transform: translateY(0); }
            80% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(-20px); }
        }