<?php
// Inicia a sessão
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Configuração do tempo de inatividade (20 minutos)
    $inactive = 1200; // 20 minutos em segundos
    
    // Verifica se existe o timestamp da última atividade
    if (isset($_SESSION['last_activity'])) {
        // Calcula o tempo desde a última atividade
        $session_life = time() - $_SESSION['last_activity'];
        if ($session_life > $inactive) {
            // Tempo excedido - destrói a sessão e redireciona
            session_unset();
            session_destroy();
            header("Location: login.php");
            exit();
        }
    }
    
    // Atualiza o timestamp da última atividade
    $_SESSION['last_activity'] = time();
    
    // Verifica se é uma requisição AJAX para manter a sessão ativa
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' && isset($_GET['keepalive'])) {
        exit(); // Apenas atualiza a sessão e encerra
    }
    
    if(!isset($_SESSION['usuario']) || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }
    if(!isset($_SESSION['usuario'])  || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }
// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Verifica se o usuário está logado
if (!isset($_SESSION['id_cliente'])) {
    $_SESSION['mensagem'] = "Você precisa estar logado para acessar o pagamento!";
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php");
    exit();
}

$id_cliente = $_SESSION['id_cliente'];
$id_pagamento = isset($_SESSION['id_pagamento']) ? $_SESSION['id_pagamento'] : null;

if (!$conn) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Obter detalhes do pagamento
$query = "SELECT p.*, c.nome as cliente_nome, 
                 DATE_FORMAT(p.data_pagamento, '%d/%m/%Y') as data_formatada,
                 DATE_FORMAT(p.data_pagamento, '%H:%i') as hora_formatada
          FROM Pagamento p
          JOIN Cliente c ON p.id_cliente = c.id_cliente
          WHERE p.id_pagamento = ? AND p.id_cliente = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $id_pagamento, $id_cliente);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['mensagem'] = "Pagamento aprovado com sucesso! Seu pedido está sendo processado.";
    header("Location: carrinho.php");
    exit();
}

$pagamento = $result->fetch_assoc();

// Obter itens do pedido
$query_itens = "SELECT iv.*, pr.nome as produto_nome, pr.preco
                FROM Itens_Vendidos iv
                JOIN Produto pr ON iv.id_produto = pr.id_produto
                WHERE iv.id_pagamento = ?";
$stmt_itens = $conn->prepare($query_itens);
$stmt_itens->bind_param("i", $id_pagamento);
$stmt_itens->execute();
$result_itens = $stmt_itens->get_result();
$itens = $result_itens->fetch_all(MYSQLI_ASSOC);

fecharConexao($conn);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmação de Pagamento | Caju Modas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --amarelo: #f4d06f;
            --marrom: #b39977;
            --bege1: #EDE6D9;
            --bege2: #ddcfb6;
            --bege3: #e3d6be;
            --preto: #342519;
            --marrom-escuro: #684F36;
        }

        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            background-color: var(--bege1);
            color: var(--preto);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .confirmacao-container {
            background-color: var(--bege2);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            max-width: 800px;
            width: 100%;
            text-align: center;
        }

        .confirmacao-icon {
            font-size: 60px;
            color: var(--marrom);
            margin-bottom: 20px;
        }

        h1 {
            color: var(--marrom-escuro);
            margin-top: 0;
        }

        .info-pedido {
            text-align: left;
            margin: 30px 0;
            padding: 20px;
            background-color: var(--bege3);
            border-radius: 5px;
        }

        .info-row {
            display: flex;
            margin-bottom: 15px;
        }

        .info-label {
            font-weight: bold;
            width: 200px;
            color: var(--marrom-escuro);
        }

        .info-value {
            flex: 1;
        }

        .itens-lista {
            margin-top: 20px;
        }

        .item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px dashed var(--marrom);
        }

        .total {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 20px;
            text-align: right;
        }

        .btn-voltar {
            background-color: var(--marrom);
            color: white;
            border: none;
            padding: 12px 25px;
            font-size: 1em;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            transition: all 0.3s;
        }

        .btn-voltar:hover {
            background-color: var(--marrom-escuro);
        }

        .detalhes-pagamento {
            margin-top: 20px;
            padding: 15px;
            background-color: var(--bege1);
            border-radius: 5px;
        }

        .codigo-boleto, .chave-pix {
            font-family: monospace;
            font-size: 1.2rem;
            letter-spacing: 2px;
            text-align: center;
            padding: 15px;
            background-color: white;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .qrcode-pix {
            text-align: center;
            padding: 20px;
            background-color: white;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .qrcode-pix img {
            max-width: 200px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="confirmacao-container">
        <div class="confirmacao-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <h1>Compra Confirmada!</h1>
        <p>Obrigado por comprar na Caju Modas. Seu pedido foi processado com sucesso.</p>
        
        <div class="info-pedido">
            <div class="info-row">
                <div class="info-label">Número do Pedido:</div>
                <div class="info-value"><?php echo htmlspecialchars($pagamento['id_pagamento']); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Data:</div>
                <div class="info-value"><?php echo htmlspecialchars($pagamento['data_formatada']); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Hora:</div>
                <div class="info-value"><?php echo htmlspecialchars($pagamento['hora_formatada']); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Cliente:</div>
                <div class="info-value"><?php echo htmlspecialchars($pagamento['cliente_nome']); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Forma de Pagamento:</div>
                <div class="info-value"><?php echo htmlspecialchars($pagamento['forma_pagamento']); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Status:</div>
                <div class="info-value"><?php echo htmlspecialchars($pagamento['status']); ?></div>
            </div>
            
            <h3>Itens do Pedido:</h3>
            <div class="itens-lista">
                <?php foreach ($itens as $item): ?>
                    <div class="item">
                        <div><?php echo htmlspecialchars($item['produto_nome']); ?> (<?php echo htmlspecialchars($item['quantidade']); ?> un)</div>
                        <div>R$ <?php echo number_format($item['preco'] * $item['quantidade'], 2, ',', '.'); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="total">
                Total: R$ <?php echo number_format($pagamento['valor_final'], 2, ',', '.'); ?>
            </div>
        </div>

        <?php if ($pagamento['forma_pagamento'] === 'PIX'): ?>
            <div class="detalhes-pagamento">
                <h3>Instruções para Pagamento via PIX</h3>
                <div class="qrcode-pix">
                    <i class="fas fa-qrcode fa-5x"></i>
                    <p>Escaneie o QR Code com seu app de pagamento</p>
                </div>
                <div class="chave-pix">
                    Chave PIX: 123.456.789-09
                </div>
                <p>Valor: R$ <?php echo number_format($pagamento['valor_final'], 2, ',', '.'); ?></p>
            </div>
        <?php elseif ($pagamento['forma_pagamento'] === 'Boleto Bancário'): ?>
            <div class="detalhes-pagamento">
                <h3>Instruções para Pagamento via Boleto</h3>
                <div class="codigo-boleto">
                    34191.79001 01043.510047 91020.150008 7 87650000019999
                </div>
                <p>Vencimento: <?php echo date('d/m/Y', strtotime('+3 days')); ?></p>
                <p>Valor: R$ <?php echo number_format($pagamento['valor_final'], 2, ',', '.'); ?></p>
            </div>
        <?php endif; ?>
        
        <a href="principal.php" class="btn-voltar">
            <i class="fas fa-home"></i> Voltar à Página Inicial
        </a>
    </div>

    <script>
            // Monitora atividade do usuário para manter a sessão ativa
    const activityEvents = ['mousemove', 'keypress', 'scroll', 'click', 'touchstart'];
    activityEvents.forEach(event => {
        document.addEventListener(event, resetTimer, {passive: true});
    });

    let timeout;
    const inactiveTime = 1200000; // 20 minutos em milissegundos

    function resetTimer() {
        clearTimeout(timeout);
        timeout = setTimeout(logout, inactiveTime);
        
        // Atualiza a sessão no servidor sem recarregar a página
        updateSession();
    }

    function logout() {
        window.location.href = 'login.php?timeout=1';
    }

    function updateSession() {
        // Usa fetch para fazer uma requisição silenciosa ao mesmo arquivo
        fetch(window.location.href + '?keepalive=1', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            cache: 'no-store'
        }).catch(error => console.error('Erro ao manter sessão:', error));
    }

    // Inicia o timer quando a página carrega
    resetTimer();

    </script>
</body>
</html>