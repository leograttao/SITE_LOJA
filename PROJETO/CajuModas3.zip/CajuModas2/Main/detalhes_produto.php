<?php
header('Content-Type: application/json');

$conn = new mysqli('localhost', 'root', '', 'cajumodas');

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Falha na conexão']));
}

$id_produto = $_GET['id'] ?? 0;

$sql = "SELECT * FROM Produto WHERE id_produto = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_produto);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $product = $result->fetch_assoc();
    echo json_encode(['success' => true, 'product' => $product]);
} else {
    echo json_encode(['success' => false, 'message' => 'Produto não encontrado']);
}

$conn->close();
?>