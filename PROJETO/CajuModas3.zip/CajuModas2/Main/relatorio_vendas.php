<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Configuração do tempo de inatividade (20 minutos)
    $inactive = 1200; // 20 minutos em segundos
    
    // Verifica se existe o timestamp da última atividade
    if (isset($_SESSION['last_activity'])) {
        // Calcula o tempo desde a última atividade
        $session_life = time() - $_SESSION['last_activity'];
        if ($session_life > $inactive) {
            // Tempo excedido - destrói a sessão e redireciona
            session_unset();
            session_destroy();
            header("Location: login.php");
            exit();
        }
    }
    
    // Atualiza o timestamp da última atividade
    $_SESSION['last_activity'] = time();
    
    // Verifica se é uma requisição AJAX para manter a sessão ativa
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' && isset($_GET['keepalive'])) {
        exit(); // Apenas atualiza a sessão e encerra
    }
    
    if(!isset($_SESSION['usuario']) || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }
    if(!isset($_SESSION['usuario'])  || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }

// Verifica se o usuário é um funcionário logado
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'funcionario') {
    header("Location: login_funcionario.php");
    exit();
}

// Conexão com o banco de dados MySQLi
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Processar filtros
$filtro_mes = isset($_GET['mes']) ? $conn->real_escape_string($_GET['mes']) : null;
$filtro_dia = isset($_GET['dia']) ? $conn->real_escape_string($_GET['dia']) : null;

// Consulta base para vendas - CORREÇÃO AQUI (status deve ser 'Aprovado' com A maiúsculo)
$query = "SELECT p.id_pagamento, p.valor_final, p.forma_pagamento, p.status, 
                 DATE_FORMAT(p.data_pagamento, '%d/%m/%Y') as data_formatada, 
                 DATE_FORMAT(p.data_pagamento, '%H:%i') as hora_formatada,
                 c.nome as cliente_nome
          FROM Pagamento p
          JOIN Cliente c ON p.id_cliente = c.id_cliente
          WHERE p.status = 'Aprovado'
          ORDER BY p.data_pagamento DESC";

$result = $conn->query($query);
$vendas = array();

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $id_pagamento = $row['id_pagamento'];
        
        // Consulta para obter os produtos agrupados por nome e tamanho
        $query_produtos = "SELECT 
                              pr.nome, 
                              iv.tamanho,
                              SUM(iv.quantidade) as quantidade_total,
                              iv.preco_unitario as preco
                          FROM Itens_Vendidos iv
                          JOIN Produto pr ON iv.id_produto = pr.id_produto
                          WHERE iv.id_pagamento = $id_pagamento
                          GROUP BY pr.nome, iv.tamanho, iv.preco_unitario";
        
        $result_produtos = $conn->query($query_produtos);
        $produtos_formatados = array();
        
        if ($result_produtos) {
            while ($produto = $result_produtos->fetch_assoc()) {
                $tamanho = !empty($produto['tamanho']) ? $produto['tamanho'] : 'Único';
                $produtos_formatados[] = sprintf(
                    "%s (%d un - R$ %.2f%s)",
                    $produto['nome'],
                    $produto['quantidade_total'],
                    $produto['preco'],
                    $tamanho != 'Único' ? " - Tam: " . $tamanho : ""
                );
            }
            $result_produtos->free();
        }
        
        $row['produtos'] = implode(', ', $produtos_formatados);
        $vendas[] = $row;
    }
    $result->free();
}

// Calcular total mensal (se filtro por mês estiver ativo)
$total_mensal = 0;
if ($filtro_mes) {
    $query_total = "SELECT SUM(valor_final) as total 
                    FROM Pagamento 
                    WHERE MONTH(data_pagamento) = MONTH('$filtro_mes-01') 
                    AND YEAR(data_pagamento) = YEAR('$filtro_mes-01')
                    AND status = 'Aprovado'"; // CORREÇÃO AQUI (Aprovado com A maiúsculo)
    
    $result_total = $conn->query($query_total);
    if ($result_total && $result_total->num_rows > 0) {
        $row_total = $result_total->fetch_assoc();
        $total_mensal = $row_total['total'];
    }
    if ($result_total) $result_total->free();
}

// Fechar conexão
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Vendas | Caju Modas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    header {
        background-color: var(--marrom);
        padding: 8px;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }



    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }


    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    } 

    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }


    .logo-container {
        flex: 1;
        text-align: center;
        margin-left: 180px;
    }

    .logo-container img {
        height: 140px;
    }

    .admin-info {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        color: var(--preto);
        gap: 5px;
    }

    .logout-btn {
        background-color: var(--marrom-escuro);
        color: white;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
        border: none;
        font-size: 14px;
    }

    .logout-btn:hover {
        background-color: var(--preto);
    }

        /* Estilos específicos para a página de relatórios */
        .admin-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            flex: 1;
        }

        .admin-title {
            text-align: center;
            color: var(--preto);
            font-size: 2.2rem;
            margin-bottom: 30px;
            position: relative;
        }

        .admin-title::after {
            content: '';
            display: block;
            width: 100px;
            height: 4px;
            background: var(--marrom);
            margin: 10px auto;
            border-radius: 2px;
        }

        .filtros-container {
            background-color: var(--bege2);
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border: 1px solid var(--marrom-claro);
        }

        .filtros-form {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: flex-end;
        }

        .filtro-group {
            flex: 1;
            min-width: 220px;
        }

        .filtro-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--marrom-escuro);
            font-weight: bold;
        }

        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--marrom-claro);
            border-radius: 5px;
            background-color: var(--bege1);
            font-family: inherit;
            font-size: 16px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--marrom);
            box-shadow: 0 0 0 2px rgba(180, 150, 120, 0.2);
        }

        .action-btn {
            background-color: var(--marrom);
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .action-btn:hover {
            background-color: var(--marrom-escuro);
        }

        .cancel-btn {
            background-color: #e74c3c;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .cancel-btn:hover {
            background-color: #c0392b;
            color: white;
        }

        .resumo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .resumo-box {
            background-color: var(--bege2);
            padding: 25px;
            border-radius: 10px;
            min-width: 250px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border: 2px solid var(--marrom);
            transition: all 0.3s ease;
        }

        .resumo-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }

        .resumo-box h3 {
            margin-top: 0;
            color: var(--marrom-escuro);
            font-size: 1.2rem;
            margin-bottom: 15px;
        }

        .resumo-valor {
            font-size: 28px;
            font-weight: bold;
            color: var(--preto);
        }

        .produtos-table {
            background-color: var(--bege2);
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            overflow-x: auto;
        }

        .vendas-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .vendas-table th, .vendas-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--marrom-claro);
        }

        .vendas-table th {
            background-color: var(--marrom);
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 0.9rem;
            letter-spacing: 1px;
        }

        .vendas-table tr:nth-child(even) {
            background-color: rgba(180, 150, 120, 0.05);
        }

        .vendas-table tr:hover {
            background-color: rgba(180, 150, 120, 0.1);
        }

        .detalhes-btn {
            background-color: var(--amarelo);
            color: var(--preto);
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-weight: bold;
        }

        .detalhes-btn:hover {
            background-color: #e6c65e;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .modal-detalhes {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            overflow: auto;
        }

        .modal-detalhes-content {
            background-color: var(--bege1);
            margin: 5% auto;
            padding: 30px;
            border-radius: 10px;
            width: 80%;
            max-width: 700px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            border: 2px solid var(--marrom);
            animation: modalFadeIn 0.3s;
        }

        @keyframes modalFadeIn {
            from {opacity: 0; transform: translateY(-20px);}
            to {opacity: 1; transform: translateY(0);}
        }

        .modal-detalhes-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--marrom-claro);
        }

        .modal-detalhes-title {
            font-size: 1.8rem;
            color: var(--marrom-escuro);
            margin: 0;
        }

        .modal-detalhes-close {
            font-size: 28px;
            font-weight: bold;
            color: var(--preto);
            cursor: pointer;
            transition: all 0.3s;
        }

        .modal-detalhes-close:hover {
            color: var(--marrom-escuro);
            transform: rotate(90deg);
        }

        .detalhes-info {
            margin-bottom: 25px;
        }

        .detalhes-info-row {
            display: flex;
            margin-bottom: 12px;
            padding-bottom: 12px;
            border-bottom: 1px dashed var(--marrom-claro);
        }

        .detalhes-info-label {
            font-weight: bold;
            width: 180px;
            color: var(--marrom-escuro);
            font-size: 1.1rem;
        }

        .detalhes-info-value {
            flex: 1;
            font-size: 1.1rem;
        }

        .produtos-list {
            margin-top: 20px;
            padding-left: 20px;
        }

        .produtos-list li {
            padding: 10px 0;
            border-bottom: 1px dashed var(--marrom-claro);
            font-size: 1.1rem;
            list-style-type: none;
            position: relative;
            padding-left: 25px;
        }

        .produtos-list li::before {
            content: '•';
            color: var(--marrom);
            font-size: 1.5rem;
            position: absolute;
            left: 0;
            top: 5px;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--marrom-escuro);
        }

        .empty-state i {
            font-size: 50px;
            margin-bottom: 20px;
            color: var(--marrom);
        }

        .empty-state h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        footer {
            background-color: var(--marrom);
            color: var(--bege1);
            padding: 20px 0;
            text-align: center;
            margin-top: 70px;
        }

        .footer-simplificado {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        .footer-logo {
            height: 80px;
            margin-bottom: 10px;
        }

        .footer-simplificado p {
            margin: 0;
            font-size: 14px;
        }

        @media (max-width: 768px) {
            .filtros-form {
                flex-direction: column;
            }
            
            .filtro-group {
                width: 100%;
            }
            
            .modal-detalhes-content {
                width: 95%;
                margin: 10% auto;
                padding: 20px;
            }
            
            .detalhes-info-row {
                flex-direction: column;
                gap: 5px;
            }
            
            .detalhes-info-label {
                width: 100%;
                margin-bottom: 5px;
            }

            .vendas-table {
                font-size: 0.9rem;
            }

            .vendas-table th, 
            .vendas-table td {
                padding: 10px 8px;
            }
        }

        @media (max-width: 480px) {
            .admin-title {
                font-size: 1.8rem;
            }

            .resumo-box {
                min-width: 100%;
            }

            .action-btn, .cancel-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="page-wrapper">
        <header>
            <div class="logo-container">
                <img src="img/CM.png" alt="Logo CM">
            </div>
            <button class="botao_hamburguer" onclick="toggleMenu()">
                <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
            </button>
            <div class="admin-info">
                <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
                <span>Cargo: <?php echo htmlspecialchars($_SESSION['cargo']); ?></span>
            </div>
        </header>

        <div id="menuLateral" class="menu-lateral">
            <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
            <a href="principal_adm.php">Principal</a>
            <a href="gerenciar_clientes.php">Gerenciar clientes</a>
            <a href="gerenciar_funcionarios.php">Gerenciar funcionários</a>  
            <a href="gerenciar_produtos.php">Gerenciar produtos</a>  
            <a href="gerenciar_banners.php">Alterar banner</a>        
            <a href="visualizar_feedback.php">visualizar feedbacks</a>
            <a href="relatorio_vendas.php" class="active">Relatório de vendas</a>
            <a href="logout_adm.php">Sair</a>
        </div>

        <main class="main-content">
            <div class="admin-container">
                <h2 class="admin-title">Relatório de Vendas</h2>
                
                <div class="filtros-container">
                    <form class="filtros-form" method="GET">
                        <div class="filtro-group">
                            <label for="mes">Filtrar por mês:</label>
                            <input type="month" id="mes" name="mes" class="form-control" 
                                   value="<?php echo htmlspecialchars($filtro_mes ?? ''); ?>">
                        </div>
                        
                        <div class="filtro-group">
                            <label for="dia">Filtrar por dia:</label>
                            <input type="date" id="dia" name="dia" class="form-control" 
                                   value="<?php echo htmlspecialchars($filtro_dia ?? ''); ?>">
                        </div>
                        
                        <div class="filtro-group">
                            <button type="submit" class="action-btn">
                                <i class="fas fa-filter"></i> Aplicar Filtro
                            </button>
                            <?php if ($filtro_mes || $filtro_dia): ?>
                                <a href="relatorio_vendas.php" class="cancel-btn" style="margin-left: 10px;">
                                    <i class="fas fa-times"></i> Limpar
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                
                <?php if ($filtro_mes): ?>
                <div class="resumo-container">
                    <div class="resumo-box">
                        <h3>Total do Mês</h3>
                        <div class="resumo-valor">R$ <?php echo number_format($total_mensal, 2, ',', '.'); ?></div>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="produtos-table">
                    <?php if (empty($vendas)): ?>
                        <div class="empty-state">
                            <i class="fas fa-chart-pie"></i>
                            <h3>Nenhuma venda encontrada</h3>
                            <p>Não há registros de vendas para o período selecionado.</p>
                        </div>
                    <?php else: ?>
                        <table class="vendas-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Data</th>
                                    <th>Cliente</th>
                                    <th>Valor</th>
                                    <th>Pagamento</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($vendas as $venda): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($venda['id_pagamento']); ?></td>
                                    <td><?php echo htmlspecialchars($venda['data_formatada']); ?></td>
                                    <td><?php echo htmlspecialchars($venda['cliente_nome']); ?></td>
                                    <td>R$ <?php echo number_format($venda['valor_final'], 2, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars($venda['forma_pagamento']); ?></td>
                                    <td>
                                        <button class="detalhes-btn" onclick="mostrarDetalhes(<?php echo htmlspecialchars(json_encode($venda)); ?>);">
                                            <i class="fas fa-eye"></i> Detalhes
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </main>

        <footer>
            <div class="footer-simplificado">
                <img src="img/CM.png" alt="Logo Caju Modas" class="footer-logo">
                <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados.</p>
            </div>
        </footer>
    </div>

    <!-- Modal de Detalhes da Venda -->
    <div id="modalDetalhes" class="modal-detalhes">
        <div class="modal-detalhes-content">
            <div class="modal-detalhes-header">
                <h3 class="modal-detalhes-title">Detalhes da Venda</h3>
                <span class="modal-detalhes-close" onclick="fecharModalDetalhes()">&times;</span>
            </div>
            
            <div class="detalhes-info">
                <div class="detalhes-info-row">
                    <div class="detalhes-info-label">ID da Venda:</div>
                    <div class="detalhes-info-value" id="detalhe-id"></div>
                </div>
                
                <div class="detalhes-info-row">
                    <div class="detalhes-info-label">Data:</div>
                    <div class="detalhes-info-value" id="detalhe-data"></div>
                </div>
                
                <div class="detalhes-info-row">
                    <div class="detalhes-info-label">Hora:</div>
                    <div class="detalhes-info-value" id="detalhe-hora"></div>
                </div>
                
                <div class="detalhes-info-row">
                    <div class="detalhes-info-label">Cliente:</div>
                    <div class="detalhes-info-value" id="detalhe-cliente"></div>
                </div>
                
                <div class="detalhes-info-row">
                    <div class="detalhes-info-label">Valor Total:</div>
                    <div class="detalhes-info-value" id="detalhe-valor"></div>
                </div>
                
                <div class="detalhes-info-row">
                    <div class="detalhes-info-label">Forma de Pagamento:</div>
                    <div class="detalhes-info-value" id="detalhe-pagamento"></div>
                </div>
                
                <div class="detalhes-info-row">
                    <div class="detalhes-info-label">Status:</div>
                    <div class="detalhes-info-value" id="detalhe-status"></div>
                </div>
            </div>
            
            <h4>Produtos:</h4>
            <ul class="produtos-list" id="detalhe-produtos">
                <!-- Produtos serão inseridos aqui via JavaScript -->
            </ul>
        </div>
    </div>

    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }
        
        function mostrarDetalhes(venda) {
            // Preencher os detalhes no modal
            document.getElementById('detalhe-id').textContent = venda.id_pagamento;
            document.getElementById('detalhe-data').textContent = venda.data_formatada;
            document.getElementById('detalhe-hora').textContent = venda.hora_formatada;
            document.getElementById('detalhe-cliente').textContent = venda.cliente_nome;
            document.getElementById('detalhe-valor').textContent = 'R$ ' + parseFloat(venda.valor_final).toFixed(2).replace('.', ',');
            document.getElementById('detalhe-pagamento').textContent = venda.forma_pagamento;
            document.getElementById('detalhe-status').textContent = venda.status;
            
            // Limpar lista de produtos
            const produtosList = document.getElementById('detalhe-produtos');
            produtosList.innerHTML = '';
            
            // Adicionar produtos à lista formatados
            const produtos = venda.produtos.split(', ');
            produtos.forEach(produto => {
                const li = document.createElement('li');
                // Formatar melhor a exibição (ex: "Camiseta (2 un)")
                li.textContent = produto;
                produtosList.appendChild(li);
            });
            
            // Mostrar o modal
            document.getElementById('modalDetalhes').style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
        
        function fecharModalDetalhes() {
            document.getElementById('modalDetalhes').style.display = 'none';
            document.body.style.overflow = 'auto'; // Restaura rolagem da página principal
        }
        
        // Fechar o modal se clicar fora dele
        window.onclick = function(event) {
            if (event.target === document.getElementById('modalDetalhes')) {
                fecharModalDetalhes();
            }
        }
        
        // Garantir que apenas um filtro seja aplicado por vez
        document.getElementById('mes').addEventListener('change', function() {
            document.getElementById('dia').value = '';
        });
        
        document.getElementById('dia').addEventListener('change', function() {
            document.getElementById('mes').value = '';
        });

        // Monitora atividade do usuário para manter a sessão ativa
    const activityEvents = ['mousemove', 'keypress', 'scroll', 'click', 'touchstart'];
    activityEvents.forEach(event => {
        document.addEventListener(event, resetTimer, {passive: true});
    });

    let timeout;
    const inactiveTime = 1200000; // 20 minutos em milissegundos

    function resetTimer() {
        clearTimeout(timeout);
        timeout = setTimeout(logout, inactiveTime);
        
        // Atualiza a sessão no servidor sem recarregar a página
        updateSession();
    }

    function logout() {
        window.location.href = 'login.php?timeout=1';
    }

    function updateSession() {
        // Usa fetch para fazer uma requisição silenciosa ao mesmo arquivo
        fetch(window.location.href + '?keepalive=1', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            cache: 'no-store'
        }).catch(error => console.error('Erro ao manter sessão:', error));
    }

    // Inicia o timer quando a página carrega
    resetTimer();
    </script>
</body>
</html>