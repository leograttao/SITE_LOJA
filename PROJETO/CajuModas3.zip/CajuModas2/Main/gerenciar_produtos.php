<?php
session_start();

// Verifica se o usuário é um administrador logado
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'funcionario') {
    header("Location: login_funcionario.php");
    exit();
}

// Conexão com o banco de dados MySQLi
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Verificar e criar diretório de imagens se não existir
$diretorio_imagens = 'img/produtos/';

if (!file_exists($diretorio_imagens)) {
    if (!mkdir($diretorio_imagens, 0755, true)) {
        $_SESSION['mensagem'] = "Erro ao criar diretório de imagens.";
        header("Location: gerenciar_produtos.php");
        exit();
    }
}

// Buscar todos os produtos para exibição
$produtos = array();
$result = $conn->query("SELECT * FROM Produto");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $produtos[] = $row;
    }
    $result->free();
}

// Se estiver editando, buscar os dados do produto diretamente
$produto_edicao = null;
if (isset($_GET['editar'])) {
    $id = $conn->real_escape_string($_GET['editar']);
    $result = $conn->query("SELECT * FROM Produto WHERE id_produto = $id");
    if ($result && $result->num_rows > 0) {
        $produto_edicao = $result->fetch_assoc();
    }
    if ($result) $result->free();
}

// Ações para adicionar, editar ou excluir produtos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['adicionar'])) {
        // Adicionar novo produto
        $nome = $conn->real_escape_string($_POST['nome']);
        $descricao = $conn->real_escape_string($_POST['descricao']);
        $preco = floatval($_POST['preco']);
        $estoque = intval($_POST['estoque']);
        $tamanho = $conn->real_escape_string($_POST['tamanho']);
        $promocao = floatval($_POST['promocao']);
        $tipo_roupa = $conn->real_escape_string($_POST['tipo_roupa']);
        $destaque = isset($_POST['destaque']) ? 1 : 0;
        $id_funcionario = isset($_SESSION['id_funcionario']) ? intval($_SESSION['id_funcionario']) : 1;
        
        // Upload da imagem
        $caminho_imagem = '';
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            $nome_arquivo = uniqid() . '_' . basename($_FILES['imagem']['name']);
            $caminho_completo = $diretorio_imagens . $nome_arquivo;
            
            if (move_uploaded_file($_FILES['imagem']['tmp_name'], $caminho_completo)) {
                $caminho_imagem = $conn->real_escape_string($caminho_completo);
            } else {
                $_SESSION['mensagem'] = "Erro ao fazer upload da imagem.";
                header("Location: gerenciar_produtos.php");
                exit();
            }
        } else {
            $_SESSION['mensagem'] = "Por favor, selecione uma imagem para o produto.";
            header("Location: gerenciar_produtos.php");
            exit();
        }
        
        $query = "INSERT INTO Produto (nome, descricao, preco, estoque, caminho_imagem, tamanho, produto_promocional, tipo_roupa, id_funcionario, destaque) 
                 VALUES ('$nome', '$descricao', $preco, $estoque, '$caminho_imagem', '$tamanho', $promocao, '$tipo_roupa', $id_funcionario, $destaque)";
        
        if ($conn->query($query)) {
            $_SESSION['mensagem'] = "Produto adicionado com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao adicionar produto: " . $conn->error;
            if (file_exists($caminho_completo)) {
                unlink($caminho_completo);
            }
        }
        
        header("Location: gerenciar_produtos.php");
        exit();
    } elseif (isset($_POST['editar'])) {
        // Editar produto existente
        $id = intval($_POST['id']);
        $nome = $conn->real_escape_string($_POST['nome']);
        $descricao = $conn->real_escape_string($_POST['descricao']);
        $preco = floatval($_POST['preco']);
        $estoque = intval($_POST['estoque']);
        $tamanho = $conn->real_escape_string($_POST['tamanho']);
        $promocao = floatval($_POST['promocao']);
        $tipo_roupa = $conn->real_escape_string($_POST['tipo_roupa']);
        $destaque = isset($_POST['destaque']) ? 1 : 0;
        
        // Buscar caminho da imagem atual
        $imagem_atual = '';
        $result = $conn->query("SELECT caminho_imagem FROM Produto WHERE id_produto = $id");
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $imagem_atual = $row['caminho_imagem'];
        }
        if ($result) $result->free();
        
        // Se uma nova imagem foi enviada
        $caminho_imagem = $imagem_atual;
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            $nome_arquivo = uniqid() . '_' . basename($_FILES['imagem']['name']);
            $caminho_completo = $diretorio_imagens . $nome_arquivo;
            
            if (move_uploaded_file($_FILES['imagem']['tmp_name'], $caminho_completo)) {
                $caminho_imagem = $conn->real_escape_string($caminho_completo);
                // Remove a imagem antiga se existir
                if (!empty($imagem_atual) && file_exists($imagem_atual)) {
                    unlink($imagem_atual);
                }
            } else {
                $_SESSION['mensagem'] = "Erro ao fazer upload da nova imagem.";
                header("Location: gerenciar_produtos.php");
                exit();
            }
        }
        
        $query = "UPDATE Produto SET nome='$nome', descricao='$descricao', preco=$preco, estoque=$estoque, 
                 caminho_imagem='$caminho_imagem', tamanho='$tamanho', produto_promocional=$promocao, 
                 tipo_roupa='$tipo_roupa', destaque=$destaque WHERE id_produto=$id";
        
        if ($conn->query($query)) {
            $_SESSION['mensagem'] = "Produto atualizado com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao atualizar produto: " . $conn->error;
            if ($caminho_imagem != $imagem_atual && file_exists($caminho_imagem)) {
                unlink($caminho_imagem);
            }
        }
        
        header("Location: gerenciar_produtos.php");
        exit();
    } elseif (isset($_POST['excluir'])) {
        // Excluir produto
        $id = intval($_POST['id']);
        
        // Buscar caminho da imagem para remover
        $result = $conn->query("SELECT caminho_imagem FROM Produto WHERE id_produto = $id");
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $caminho_imagem = $row['caminho_imagem'];
            if (file_exists($caminho_imagem)) {
                unlink($caminho_imagem);
            }
        }
        if ($result) $result->free();
        
        $query = "DELETE FROM Produto WHERE id_produto = $id";
        
        if ($conn->query($query)) {
            $_SESSION['mensagem'] = "Produto excluído com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao excluir produto: " . $conn->error;
        }
        
        header("Location: gerenciar_produtos.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Produtos | Caju Modas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Estilos anteriores permanecem iguais */
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }
        
        .destaque-badge {
            background-color: var(--amarelo);
            color: var(--preto);
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .nao-destaque-badge {
            background-color: #e0e0e0;
            color: #666;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="page-wrapper">
        <header>
            <div class="logo-container">
                <img src="img/CM.png" alt="Logo CM">
            </div>
            <button class="botao_hamburguer" onclick="toggleMenu()">
                <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
            </button>
            <div class="admin-info">
                <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
                <span>Cargo: <?php echo htmlspecialchars($_SESSION['cargo']); ?></span>
            </div>
        </header>

        <div id="menuLateral" class="menu-lateral">
            <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
            <a href="principal_adm.php">Principal</a>
            <a href="gerenciar_clientes.php">Gerenciar clientes</a>
            <a href="gerenciar_funcionarios.php">Gerenciar funcionários</a>  
            <a href="gerenciar_produtos.php">Gerenciar produtos</a>  
            <a href="gerenciar_banners.php">Alterar banner</a>        
            <a href="grafico_visitas.php">Gráfico de visitas</a>
            <a href="relatorio_vendas.php">Relatório de vendas</a>
        </div>

        <main class="main-content">
            <div class="admin-container">
                <h2 class="admin-title">Gerenciamento de Produtos</h2>
                
                <?php if (isset($_SESSION['mensagem'])): ?>
                    <div class="mensagem">
                        <?php echo $_SESSION['mensagem']; unset($_SESSION['mensagem']); ?>
                    </div>
                <?php endif; ?>
                
                <div class="produto-actions">
                    <button class="action-btn" onclick="abrirModalAdicionar()">
                        <i class="fas fa-plus"></i> Adicionar Produto
                    </button>
                </div>
                
                <div class="produtos-table">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Imagem</th>
                                <th>Nome</th>
                                <th>Preço</th>
                                <th>Estoque</th>
                                <th>Tipo</th>
                                <th>Destaque</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($produtos as $produto): ?>
                            <tr>
                                <td><?php echo $produto['id_produto']; ?></td>
                                <td>
                                    <?php if (!empty($produto['caminho_imagem'])): ?>
                                        <img src="<?php echo $produto['caminho_imagem']; ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>" class="produto-img">
                                    <?php else: ?>
                                        <div class="sem-imagem-icon"><i class="fas fa-image"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                                <td>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></td>
                                <td><?php echo $produto['estoque']; ?></td>
                                <td><?php echo htmlspecialchars($produto['tipo_roupa']); ?></td>
                                <td>
                                    <?php if ($produto['destaque']): ?>
                                        <span class="destaque-badge">Sim</span>
                                    <?php else: ?>
                                        <span class="nao-destaque-badge">Não</span>
                                    <?php endif; ?>
                                </td>
                                <td class="actions-cell">
                                    <div class="actions-buttons">
                                        <button class="edit-btn" onclick="abrirModalEditar(<?php echo $produto['id_produto']; ?>)">
                                            <i class="fas fa-edit"></i> Editar
                                        </button>
                                        <button class="delete-btn" onclick="confirmarExclusao(<?php echo $produto['id_produto']; ?>)">
                                            <i class="fas fa-trash"></i> Excluir
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <footer>
            <div class="footer-simplificado">
                <img src="img/CM.png" alt="Logo Caju Modas" class="footer-logo">
                <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados.</p>
            </div>
        </footer>
    </div>

    <!-- Modal para adicionar produtos -->
    <div id="modalAdicionar" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close" onclick="fecharModalAdicionar()">&times;</span>
            <h3>Adicionar Novo Produto</h3>
            
            <form id="formAdicionar" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="adicionar" value="1">
                
                <div class="form-group">
                    <label for="nome">Nome do Produto:</label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <textarea id="descricao" name="descricao" rows="3"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="preco">Preço (R$):</label>
                        <input type="number" id="preco" name="preco" step="0.01" min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="estoque">Estoque:</label>
                        <input type="number" id="estoque" name="estoque" min="0" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="tamanho">Tamanho:</label>
                        <input type="text" id="tamanho" name="tamanho">
                    </div>
                    
                    <div class="form-group">
                        <label for="promocao">Preço Promocional (R$):</label>
                        <input type="number" id="promocao" name="promocao" step="0.01" min="0">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="tipo_roupa">Tipo de Roupa:</label>
                    <select id="tipo_roupa" name="tipo_roupa" required>
                        <option value="">Selecione...</option>
                        <option value="Vestido">Vestido</option>
                        <option value="Saia">Saia</option>
                        <option value="Blusa">Blusa</option>
                        <option value="Casaco">Casaco</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="destaque" class="checkbox-label">
                        <input type="checkbox" id="destaque" name="destaque" value="1">
                        Produto em Destaque
                    </label>
                </div>
                
                <div class="form-group">
                    <label for="imagem">Imagem do Produto:</label>
                    <input type="file" id="imagem" name="imagem" accept="image/*" required>
                    <div id="imagemPreview" class="imagem-preview"></div>
                </div>
                
                <div class="form-buttons">
                    <button type="button" class="cancel-btn" onclick="fecharModalAdicionar()">Cancelar</button>
                    <button type="submit" class="action-btn">Adicionar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal para editar produtos -->
    <div id="modalEditar" class="modal" style="<?php echo $produto_edicao ? 'display: block;' : 'display: none;'; ?>">
        <div class="modal-content">
            <span class="close" onclick="fecharModalEditar()">&times;</span>
            <h3>Editar Produto</h3>
            
            <form id="formEditar" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="editar" value="1">
                <input type="hidden" id="editarId" name="id" value="<?php echo $produto_edicao ? $produto_edicao['id_produto'] : ''; ?>">
                
                <div class="form-group">
                    <label for="editarNome">Nome do Produto:</label>
                    <input type="text" id="editarNome" name="nome" value="<?php echo $produto_edicao ? htmlspecialchars($produto_edicao['nome']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="editarDescricao">Descrição:</label>
                    <textarea id="editarDescricao" name="descricao" rows="3"><?php echo $produto_edicao ? htmlspecialchars($produto_edicao['descricao']) : ''; ?></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="editarPreco">Preço (R$):</label>
                        <input type="number" id="editarPreco" name="preco" step="0.01" min="0" value="<?php echo $produto_edicao ? $produto_edicao['preco'] : ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="editarEstoque">Estoque:</label>
                        <input type="number" id="editarEstoque" name="estoque" min="0" value="<?php echo $produto_edicao ? $produto_edicao['estoque'] : ''; ?>" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="editarTamanho">Tamanho:</label>
                        <input type="text" id="editarTamanho" name="tamanho" value="<?php echo $produto_edicao ? htmlspecialchars($produto_edicao['tamanho']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="editarPromocao">Preço Promocional (R$):</label>
                        <input type="number" id="editarPromocao" name="promocao" step="0.01" min="0" value="<?php echo $produto_edicao ? $produto_edicao['produto_promocional'] : ''; ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="editarTipoRoupa">Tipo de Roupa:</label>
                    <select id="editarTipoRoupa" name="tipo_roupa" required>
                        <option value="">Selecione...</option>
                        <option value="Vestido" <?php echo ($produto_edicao && $produto_edicao['tipo_roupa'] == 'Vestido') ? 'selected' : ''; ?>>Vestido</option>
                        <option value="Saia" <?php echo ($produto_edicao && $produto_edicao['tipo_roupa'] == 'Saia') ? 'selected' : ''; ?>>Saia</option>
                        <option value="Blusa" <?php echo ($produto_edicao && $produto_edicao['tipo_roupa'] == 'Blusa') ? 'selected' : ''; ?>>Blusa</option>
                        <option value="Casaco" <?php echo ($produto_edicao && $produto_edicao['tipo_roupa'] == 'Casaco') ? 'selected' : ''; ?>>Casaco</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="editarDestaque" class="checkbox-label">
                        <input type="checkbox" id="editarDestaque" name="destaque" value="1" <?php echo ($produto_edicao && $produto_edicao['destaque']) ? 'checked' : ''; ?>>
                        Produto em Destaque
                    </label>
                </div>
                
                <div class="form-group">
                    <label for="editarImagem">Imagem do Produto:</label>
                    <input type="file" id="editarImagem" name="imagem" accept="image/*">
                    <div id="editarImagemPreview" class="imagem-preview">
                        <?php if ($produto_edicao && $produto_edicao['caminho_imagem']): ?>
                            <p>Imagem atual:</p>
                            <img src="<?php echo $produto_edicao['caminho_imagem']; ?>" alt="<?php echo htmlspecialchars($produto_edicao['nome']); ?>" style="max-width: 100px;">
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="form-buttons">
                    <button type="button" class="cancel-btn" onclick="fecharModalEditar()">Cancelar</button>
                    <button type="submit" class="action-btn">Atualizar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal de confirmação para exclusão -->
    <div id="confirmModal" class="modal">
        <div class="modal-content confirm-modal">
            <h3>Confirmar Exclusão</h3>
            <p>Tem certeza que deseja excluir este produto?</p>
            <form id="deleteForm" method="POST">
                <input type="hidden" id="deleteId" name="id">
                <input type="hidden" name="excluir" value="1">
                <div class="confirm-buttons">
                    <button type="button" class="cancel-btn" onclick="fecharConfirmModal()">Cancelar</button>
                    <button type="submit" class="delete-btn">Excluir</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }
        
        function abrirModalAdicionar() {
            document.getElementById('modalAdicionar').style.display = 'block';
        }

        function fecharModalAdicionar() {
            document.getElementById('modalAdicionar').style.display = 'none';
        }

        function abrirModalEditar(id) {
            window.location.href = 'gerenciar_produtos.php?editar=' + id;
        }

        function fecharModalEditar() {
            window.location.href = 'gerenciar_produtos.php';
        }

        function confirmarExclusao(id) {
            document.getElementById('deleteId').value = id;
            document.getElementById('confirmModal').style.display = 'block';
        }
        
        function fecharConfirmModal() {
            document.getElementById('confirmModal').style.display = 'none';
        }
        
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
        
        document.getElementById('imagem').addEventListener('change', function(e) {
            const preview = document.getElementById('imagemPreview');
            preview.innerHTML = '';
            
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.maxWidth = '100px';
                    preview.appendChild(img);
                }
                
                reader.readAsDataURL(this.files[0]);
            }
        });
        
        document.getElementById('editarImagem').addEventListener('change', function(e) {
            const preview = document.getElementById('editarImagemPreview');
            
            const currentImg = preview.querySelector('img[style="max-width: 100px;"]');
            if (currentImg) {
                preview.innerHTML = '<p>Imagem atual:</p>';
                preview.appendChild(currentImg);
            } else {
                preview.innerHTML = '';
            }
            
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.maxWidth = '100px';
                    preview.appendChild(img);
                }
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    </script>
</body>
</html>
<style>
        :root {
            --amarelo: #f4d06f;
            --marrom: #b39977;
            --bege1: #EDE6D9;
            --bege2: #ddcfb6;
            --bege3: #e3d6be;
            --preto: #342519;
            --marrom-escuro: #684F36;
            --marrom-claro: #d1b38c;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(180deg, var(--bege1), var(--bege3));
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .page-wrapper {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            width: 100%;
        }

        header {
            background-color: var(--marrom);
            padding: 8px;
            box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
            height: 138px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

                .menu-lateral {
            height: 100%;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: var(--bege2);
            overflow-x: hidden;
            transition: width 0.5s; 
            padding-top: 70px;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
            z-index: 20;             
        }

        .menu-lateral .fechar {
            position: absolute;
            top: 1px;
            right: 20px;
            font-size: 25px;
            color: var(--bege);
            background: none;
            border: none;
            cursor: pointer;
            transition: color 0.3s;
        }

        .menu-lateral a {
            padding: 15px 20px;
            text-decoration: none;
            font-size: 20px;
            color: var(--preto);
            display: block;
            margin: 10px 0;
            transition: 0.3s;
        }

        .menu-lateral a:hover {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            transform: scale(1.05);
        }

        .botao_hamburguer {
            position: absolute;
            left: 20px; 
            top: 10%; /* Alterado para centralizar verticalmente */
            transform: translateY(-50%);
            z-index: 10;
            background: transparent; /* Garante que o fundo seja transparente */
            border: none;
            cursor: pointer;
            padding: 0;
        }

        .botao_hamburguer img {
            height: 50px; /* Tamanho consistente */
            width: 55px;
            filter: drop-shadow(2px 2px 2px rgba(0,0,0,0.3)); /* Adiciona sombra para melhor visibilidade */
        }

        .logo-container {
            flex: 1;
            text-align: center;
            margin-left: 180px;
        }

        .logo-container img {
            height: 140px;
        }

        .admin-info {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            color: var(--preto);
            gap: 5px;
        }

        .logout-btn {
            background-color: var(--marrom-escuro);
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            border: none;
            font-size: 14px;
        }

        .logout-btn:hover {
            background-color: var(--preto);
        }

        .main-content {
            flex: 1;
            padding-bottom: 40px;
        }

        .admin-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            width: 100%;
        }

        .admin-title {
            text-align: center;
            color: var(--preto);
            font-size: 2.2rem;
            margin-bottom: 30px;
        }

        .mensagem {
            background-color: var(--amarelo);
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
            color: var(--preto);
        }

        .produto-actions {
            margin-bottom: 20px;
            text-align: right;
        }

        .action-btn {
            background-color: var(--marrom-escuro);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .action-btn:hover {
            background-color: var(--preto);
        }

        .action-btn i {
            margin-right: 8px;
        }

        .produtos-table {
            background-color: var(--bege2);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
            margin-bottom: 30px;
        }

        table {
            width: 96%;
            border-collapse: collapse;
            table-layout: fixed;
        }

        th, td {
            padding: 12px 8px;
            text-align: center;
            vertical-align: middle;
            border-bottom: 1px solid var(--marrom-claro);
        }

        th {
            background-color: var(--marrom);
            color: white;
            position: sticky;
            top: 0;
        }

        /* Larguras específicas para cada coluna */
        th:nth-child(1), td:nth-child(1) { width: 5%; min-width: 50px; }  /* ID */
        th:nth-child(2), td:nth-child(2) { width: 10%; min-width: 80px; } /* Imagem */
        th:nth-child(3), td:nth-child(3) { width: 25%; } /* Nome */
        th:nth-child(4), td:nth-child(4) { width: 10%; } /* Preço */
        th:nth-child(5), td:nth-child(5) { width: 8%; }  /* Estoque */
        th:nth-child(6), td:nth-child(6) { width: 15%; } /* Tipo */
        th:nth-child(7), td:nth-child(7) { width: 20%; min-width: 150px; } /* Ações */

        tr:hover {
            background-color: rgba(180, 150, 120, 0.1);
        }

        .produto-img {
            max-width: 60px;
            max-height: 60px;
            border-radius: 4px;
            display: block;
            margin: 0 auto;
        }

        .sem-imagem-icon {
            color: var(--marrom-claro);
            font-size: 24px;
        }

        .actions-cell {
            padding: 8px !important;
        }

        .actions-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
            flex-wrap: nowrap;
        }

        .edit-btn, .delete-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }

        .edit-btn {
            background-color: var(--amarelo);
            color: var(--preto);
        }

        .delete-btn {
            background-color: #e74c3c;
            color: white;
        }

        .edit-btn:hover {
            background-color: #e6c65e;
            transform: translateY(-1px);
        }

        .delete-btn:hover {
            background-color: #c0392b;
            transform: translateY(-1px);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            overflow: auto;
        }

        .modal-content {
            background-color: var(--bege1);
            margin: 5% auto;
            padding: 25px;
            border-radius: 10px;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            position: relative;
        }

        .confirm-modal {
            text-align: center;
        }

        .close {
            position: absolute;
            top: 15px;
            right: 25px;
            font-size: 28px;
            font-weight: bold;
            color: var(--preto);
            cursor: pointer;
        }

        .close:hover {
            color: var(--marrom-escuro);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-row {
            display: flex;
            gap: 15px;
        }

        .form-row .form-group {
            flex: 1;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: var(--preto);
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--marrom);
            border-radius: 5px;
            background-color: var(--bege2);
            font-family: inherit;
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        .imagem-preview {
            margin-top: 10px;
        }

        .imagem-preview img {
            max-width: 100px;
            max-height: 100px;
            border-radius: 5px;
        }

        .form-buttons, .confirm-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }

        .cancel-btn, #submitBtn, .delete-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .cancel-btn {
            background-color: #95a5a6;
            color: white;
        }

        .cancel-btn:hover {
            background-color: #7f8c8d;
        }

        #submitBtn {
            background-color: var(--marrom-escuro);
            color: white;
        }

        #submitBtn:hover {
            background-color: var(--preto);
        }

        footer {
            background-color: var(--marrom);
            color: var(--bege1);
            padding: 30px 0;
            text-align: center;
            margin-top: auto;
            width: 100%;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
        }

        .footer-simplificado {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .footer-logo {
            height: 100px;
            margin-bottom: 15px;
        }

        .footer-simplificado p {
            margin: 0;
            font-size: 16px;
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
                gap: 0;
            }
            
            .produtos-table {
                padding: 10px;
            }
            
            th, td {
                padding: 8px 10px;
                font-size: 14px;
            }
            
            .modal-content {
                width: 90%;
                margin: 10% auto;
            }

            .logo-container {
                margin-left: 0;
            }

            .admin-info {
                align-items: center;
            }

            .actions-buttons {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>