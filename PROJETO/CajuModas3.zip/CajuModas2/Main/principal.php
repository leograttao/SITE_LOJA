<?php
    session_start();
    header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
    if(!isset($_SESSION['usuario'])  || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Verifica se usuário está logado (sessão)
$usuario_logado = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;

$sql_produtos = "SELECT id_produto, nome, descricao, preco, tipo_roupa, caminho_imagem, produto_promocional 
                 FROM Produto 
                 WHERE destaque = 1
                 LIMIT 6";

$result_produtos = $conn->query($sql_produtos);

// Se houver erro na query ou nenhum produto
if (!$result_produtos) {
    $produtos = array();
    error_log("Erro ao buscar produtos: " . $conn->error);
} else {
    $produtos = $result_produtos->fetch_all(MYSQLI_ASSOC);
}

// Buscar banners do banco de dados
$sql_banners = "SELECT caminho_imagem FROM Banner ORDER BY id_banner";
$result_banners = $conn->query($sql_banners);

$banners = array();
if ($result_banners && $result_banners->num_rows > 0) {
    $banners = $result_banners->fetch_all(MYSQLI_ASSOC);
}

// Processar adição à lista de desejos
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['adicionar_lista_desejos'])) {
    $id_produto = $_POST['id_produto'];
    $id_cliente = $_SESSION['id_cliente'];
    
    // Verificar se a lista de desejos existe ou criar uma nova
    $stmt = $conn->prepare("SELECT id_lista FROM lista_desejos WHERE id_cliente = ?");
    $stmt->bind_param("i", $id_cliente);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        // Criar nova lista se não existir
        $insert = $conn->prepare("INSERT INTO lista_desejos (id_cliente) VALUES (?)");
        $insert->bind_param("i", $id_cliente);
        
        if ($insert->execute()) {
            $lista_id = $insert->insert_id;
        } else {
            die("Erro ao criar lista de desejos: " . $insert->error);
        }
        $insert->close();
    } else {
        $row = $result->fetch_assoc();
        $lista_id = $row['id_lista'];
    }
    $stmt->close();
    
    // Verificar se o produto já está na lista
    $stmt_check = $conn->prepare("SELECT * FROM lista_desejos_produto WHERE id_lista = ? AND id_produto = ?");
    $stmt_check->bind_param("ii", $lista_id, $id_produto);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    
    if ($result_check->num_rows === 0) {
        // Adicionar o produto à lista
        $stmt_insert = $conn->prepare("INSERT INTO lista_desejos_produto (id_lista, id_produto) VALUES (?, ?)");
        $stmt_insert->bind_param("ii", $lista_id, $id_produto);
        
        if ($stmt_insert->execute()) {
            $_SESSION['mensagem'] = "Produto adicionado à lista de desejos com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao adicionar produto à lista de desejos: " . $stmt_insert->error;
        }
        $stmt_insert->close();
    } else {
        $_SESSION['mensagem'] = "Este produto já está na sua lista de desejos!";
    }
    $stmt_check->close();
    
    // Recarregar a página para mostrar a mensagem
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

// Fecha a conexão (opcional, dependendo do uso posterior)
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Caju Modas - Onde o estilo encontra você.</title>
</head>
<body>

    <header>
        <h1 class="logo">
            <a>
              <img src="img/CM.png" alt="Logo CM">
            </a>
          </h1>

        <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
        <div class="admin-info">
            <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
        </div>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="lista_desejos.php">Lista de desejos</a>  
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
        <a href="logout.php">Sair</a>
    </div>

    <?php if (isset($_SESSION['mensagem'])): ?>
        <div class="alert">
            <i class="fas fa-check-circle"></i>
            <?php echo $_SESSION['mensagem']; unset($_SESSION['mensagem']); ?>
        </div>
    <?php endif; ?>

    <div class="banner-container">
        <a href="produtos.php" id="banner-link">
                <?php foreach ($banners as $index => $banner): ?>
                    <img src="<?php echo htmlspecialchars($banner['caminho_imagem']); ?>" <?php echo $index === 0 ? 'class="active"' : ''; ?>>
                <?php endforeach; ?>
        </a>
    </div>

    <!-- Seção de Produtos em Destaque -->
    <section id="produtos">
        <h2>Produtos em Destaque</h2>
        <div class="slider-container">
            <button class="slider-btn" id="prevBtn">&#10094;</button>
            <div class="grid-produtos">
                <?php foreach ($produtos as $produto): ?>
                    <div class="produto">
                        <img src="<?php echo htmlspecialchars($produto['caminho_imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                        <p><?php echo htmlspecialchars($produto['nome']); ?></p>
                        <?php if ($produto['produto_promocional'] > 0 && $produto['produto_promocional'] < $produto['preco']): ?>
                            <p style="text-decoration: line-through; color: #777;">De: R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                            <p style="font-weight: bold; color: #d00;">Por: R$ <?php echo number_format($produto['produto_promocional'], 2, ',', '.'); ?></p>
                        <?php else: ?>
                            <p>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                        <?php endif; ?>
                        
                        <div class="produto-actions">
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_carrinho" class="texto-botao">
                                    <i class="fas fa-shopping-cart"></i> Carrinho
                                </button>
                            </form>
                            
                            <form method="post">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" name="adicionar_lista_desejos" class="texto-botao wishlist-btn">
                                    <i class="fas fa-heart"></i> Lista
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if (empty($produtos)): ?>
                    <div class="produto">
                        <p>Nenhum produto encontrado.</p>
                    </div>
                <?php endif; ?>
            </div>
            <button class="slider-btn" id="nextBtn">&#10095;</button>
        </div>
        <div class="slider-dots" id="dotsContainer"></div>
    </section>


    <button class="veja" onclick="window.location.href='produtos.php'">Veja Mais</button>


    <div class="faq-container">
        <h1>
            Perguntas Frequentes
        </h1>
        <div class="faq-item">
            <summary class="faq-title" onclick="toggleFaq(this)">Posso trocar ou devolver uma peça?</summary>
            <div class="faq-content">Sim! Você tem até 7 dias corridos após o recebimento para solicitar a devolução ou troca de qualquer produto, desde que ele esteja sem uso, com etiqueta e em perfeitas condições. Para iniciar o processo, entre em contato com nosso atendimento via e-mail ou WhatsApp.</div>
        </div>
        <div class="faq-item">
            <summary class="faq-title" onclick="toggleFaq(this)">Os produtos são originais?</summary>
            <div class="faq-content">Sim, todos os nossos produtos são 100% originais e acompanham nota fiscal.</div>
        </div>
        <div class="faq-item">
            <summary class="faq-title" onclick="toggleFaq(this)">Vocês possuem loja física?</summary>
            <div class="faq-content">Sim! Nosso endereço está no mapa no fim da página!</div>
        </div>
        <div class="faq-item">
            <summary class="faq-title" onclick="toggleFaq(this)">A loja é segura?</summary>
            <div class="faq-content">Sim! Nosso site possui certificado SSL e utiliza plataformas de pagamento seguras. Seus dados estão protegidos, e sua privacidade é prioridade para nós.</div>
        </div>
        <div class="faq-item">
            <summary class="faq-title" onclick="toggleFaq(this)">As peças encolhem ou desbotam após a lavagem?</summary>
            <div class="faq-content">Nossos produtos passam por controle de qualidade e seguem os padrões de lavagem recomendados. Para manter a durabilidade, siga sempre as instruções da etiqueta da peça.</div>
        </div>
    </div>

    <div class="contact-info">
        <h2>
            Endereço
        </h2>
        <p>Curitiba, PR</p>
        <p>Pontificia universidade do estilo - Rua Modas - Numero: 123</p>
        <p><strong>Horário de Atendimento:</strong><br>Segunda a Sexta: 8h - 18h</p>
        
        <iframe class=mapa src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3602.6020583832774!2d-49.25532212281319!3d-25.451564433748548!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94dce4fa6efc3181%3A0x8b0f452491a6f477!2sPUCPR%20-%20Pontif%C3%ADcia%20Universidade%20Cat%C3%B3lica%20do%20Paran%C3%A1!5e0!3m2!1spt-BR!2sbr!4v1730244720860!5m2!1spt-BR!2sbr" width="600" height="450" allowfullscreen loading="lazy"></iframe>
    </div>


    <footer>
        <footer>
            <div class="footer-container">
                <div class="footer-info">
                    <h2>Contato</h2>
                    <p>Telefone: (41) 9999-9999</p>
                    <p>E-mail: <a href="">CAJUMODAS@gmail.com</a></p>
                </div>
                
                <div class="footer-img">
                    <img src="img/CM.png" alt="Logo Caju Modas">
                </div>
                
                <div class="footer-social">
                    <h2>Siga-nos:</h2>
                    <a href="" class="social-link">    
                        <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                        Tiktok
                    </a>
                    <a href="" class="social-link">
                        <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                        Instagram 
                    </a>
                    <a href="" class="social-link">
                        <img src="img/x.png" alt="Twitter" class="footer-icon">
                        Twitter 
                    </a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
            </div>
        </footer>
    </footer>
    <script>
    let currentIndex = 0;
    const images = document.querySelectorAll('.banner-container img');
    const link = document.getElementById('produtos.php');

    function changeImage() {
        images[currentIndex].classList.remove('active');
        currentIndex = (currentIndex + 1) % images.length;
        images[currentIndex].classList.add('active');
        link.href = images[currentIndex].getAttribute('data-link');
    }

    setInterval(changeImage, 8000);

    function toggleFaq(element) {
            const content = element.nextElementSibling;
            if (content.style.maxHeight) {
                content.style.maxHeight = null;
                content.style.paddingTop = "0";
                content.style.paddingBottom = "0";
            } else {
                content.style.maxHeight = content.scrollHeight + "px";
                content.style.paddingTop = "10px";
                content.style.paddingBottom = "10px";
            }
    }

    document.addEventListener('DOMContentLoaded', function() {
    const slider = document.querySelector('.grid-produtos');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const dotsContainer = document.getElementById('dotsContainer');
    
    const produtos = document.querySelectorAll('.produto');
    const produtoWidth = produtos[0].offsetWidth + 20; // width + gap
    let currentPosition = 0;
    let currentIndex = 0;
    
    // Create dots
    produtos.forEach((_, index) => {
        const dot = document.createElement('span');
        dot.classList.add('dot');
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => {
            goToSlide(index);
        });
        dotsContainer.appendChild(dot);
    });
    
    const dots = document.querySelectorAll('.dot');
    
    // Update dots
    function updateDots() {
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentIndex);
        });
    }
    
    // Go to specific slide
    function goToSlide(index) {
        currentIndex = index;
        currentPosition = -index * produtoWidth;
        slider.style.transform = `translateX(${currentPosition}px)`;
        updateDots();
    }
    
    // Next slide with loop
    nextBtn.addEventListener('click', () => {
        if (currentIndex < produtos.length - 1) {
            currentIndex++;
        } else {
            currentIndex = 0; // Volta para o primeiro produto
        }
        currentPosition = -currentIndex * produtoWidth;
        slider.style.transform = `translateX(${currentPosition}px)`;
        updateDots();
    });
    
    // Previous slide with loop
    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
        } else {
            currentIndex = produtos.length - 1; // Vai para o último produto
        }
        currentPosition = -currentIndex * produtoWidth;
        slider.style.transform = `translateX(${currentPosition}px)`;
        updateDots();
    });
    
    // Responsive adjustments
    function handleResize() {
        const newProdutoWidth = produtos[0].offsetWidth + 20;
        if (Math.abs(newProdutoWidth - produtoWidth) > 5) {
            currentPosition = -currentIndex * newProdutoWidth;
            slider.style.transform = `translateX(${currentPosition}px)`;
        }
    }
    
    window.addEventListener('resize', handleResize);
    
    // Esconder mensagem após 3 segundos
    const alert = document.querySelector('.alert');
    if (alert) {
        setTimeout(() => {
            alert.style.display = 'none';
        }, 3000);
    }
});

        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }

    </script>
    
</body>
</html>
<style>
    :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
    }

    header {
        background-color: var(--marrom);
        padding: 8px;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }

    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }

    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10;
        height: 100px;
        width: auto;
        max-width: none; 
    }
     
    .login {
        position: absolute;
        Right: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10;
        height: 100px;
        width: auto;
        max-width: none; 
    }
    .banner-container {
        width: 75%;
        height: 330px;
        position: relative;
        overflow: hidden;
        margin: auto;
        margin-top: 30px;
        border-radius: 20px;
        box-shadow: 0px 4px 10px var(--preto);
        margin-bottom: 20px;
    }

    .banner-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        position: absolute;
        opacity: 0;
        transition: opacity 1s ease-in-out;
    }

    .banner-container img.active {
        opacity: 1;
    }

    section {
        padding: 30px;
        text-align: center;
    }

        
        #produtos {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        #produtos h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
            color: #333;
        }
        
        .slider-container {
            position: relative;
            overflow: hidden;
            padding: 20px 0;
        }
        
        .grid-produtos {
            display: flex;
            gap: 20px;
            transition: transform 0.5s ease;
            padding: 10px 0;
        }
        
        .produto {
            min-width: 250px;
            background: var(--bege2);
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            text-align: center;
            transition: transform 0.3s ease;
            border: 2px solid var(--bege1); 
        }
        
        .produto:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        .produto img {
            width: 60%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        
        .produto p {
            margin: 10px 0;
            font-size: 1rem;
            color: var(--preto);
        }
        
        .texto-botao {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        
        .texto-botao:hover {
            background-color: var(--preto);
        }
        
        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.7);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 1rem;
            cursor: pointer;
            z-index: 10;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        
        .slider-btn:hover {
            background: var(--marrom-escuro)
        }
        
        #prevBtn {
            left: 5px;
        }
        
        #nextBtn {
            right: 5px;
        }
        
        .slider-dots {
            text-align: center;
            margin-top: 10px;
        }
        
        .dot {
            display: inline-block;
            width: 12px;
            height: 12px;
            background: var(--marrom);
            border-radius: 50%;
            margin: 0 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .dot.active {
            background: var(--marrom-escuro);
        }

    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }

    .veja {
        margin-left: 47.7%;
        background-color: var(--marrom-escuro);
        margin-bottom: 40px;
    }

    .faq-container {
        max-width: 800px;
        width: 800px;
        margin: 20px auto;
        padding: 20px;
        border: 2px solid var(--bege1); 
        border-radius: 5px;
        background-color: var(--bege2);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 50px;
    }

    .faq-container h1 {
        display: flex;
        align-items: center;
    }

    .faq-image {
        width: 200px; 
        height: 200px; 
        margin-right: 10px; 
    }

    details {
        margin: 10px 0;
        border-bottom: 1px solid #ddd;
        font-family: 'Encode Sans Expanded', sans-serif;
    }

    summary {
        cursor: pointer;
        font-size: 1.2em;
        color: var(--preto);
        padding: 10px;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: background-color 0.3s;
    }

    summary:hover {
        background-color: var(--marrom-escuro);
        color: var(--marrom-escuro);
    }

    .faq-content {
        padding: 0 10px;
        color: #555;
        font-weight: normal;
        overflow: hidden; 
        max-height: 0; 
        transition: max-height 0.3s ease, padding 0.3s ease; 
    }

    .faq-title {
        cursor: pointer; 
        background-color: var(--marrom-escuro); 
        color: var(--bege2);
        border: 1px solid #ccc; 
        padding: 15px; 
        margin: 5px 0; 
        border-radius: 5px; 
        font-size: 16px;
    }

    .faq-title:hover {
        background-color: var(--preto); 
        color: var(--bege2);
    }

    details[open] .faq-content {
        max-height: 500px; 
        padding-top: 10px; 
        padding-bottom: 10px;
    }

    .faq-container h1 {
        display: flex;
        align-items: center; 
    }

    .faq-image {
        width: 50px; 
        height: auto; 
        margin-right: 10px; 
    }

    @keyframes zoom {
        0% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.05);
        }
        100% {
            transform: scale(1); 
        }
    }
    .info {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        color: var(--preto);
        gap: 5px;
    }

    .contact-info {
        max-width: 800px;
        width: 800px;
        margin: 20px auto;
        padding: 20px;
        border: 2px solid var(--bege1); 
        border-radius: 5px;
        background-color: var(--bege2);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 50px;
    }

    .contact-info p {
        color: var(--preto); 
    }

    .mapa {
        width: 100%; 
        height: 300px; 
        border: 0;
        border-radius: 5px; 
        box-shadow: 1 2px 10px rgba(0, 0, 0, 0.1); 
        margin-top: 15px; 
    }

    footer {
        background-color: var(--marrom);
        color: var(--bege1);
        padding: 1px 0; 
        margin-top: 10px; 
    }

    .footer-container {
        display: flex;
        justify-content: space-around;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
        flex-wrap: wrap; 
        padding: 10px 0;
        border-bottom: 3px solid #333;
    }

    .footer-info, .footer-img, .footer-social {
        flex: 1;
        padding: 5px; 
        text-align: center; 
    }

    .footer-img img {
        width: 105;
        height: 100px;
        border-radius: 8px;
    }

    .footer-social {
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: flex-end; 
        gap: 8px; 
        padding-right: 20px; 
    }

    .footer-social a {
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--bege1);
        text-decoration: none;
        flex-direction: row-reverse; 
        font-size: 22px;
    }

    .footer-icon {
        width: 37px; 
        height: 37px;
        margin-left: 12px; 
        transition: transform 0.3s;
    }

    .footer-social a:hover .footer-icon {
        transform: scale(1.2);
    }

    .footer-bottom {
        margin-top: 10px;
        font-size: 14px;
        text-align: center;
    }

    .texto-botao {
        color: white;
    }

    .logo {
        flex: 1;
        text-align: center;
    }

    .logo img {
        height: 140px;
    }
    
    /* Novos estilos adicionados */
    .produto-actions {
        display: flex;
        justify-content: space-between;
        margin-top: 15px;
    }

    .produto-actions form {
        flex: 1;
        margin: 0 3px;
    }

    .produto-actions button {
        width: 100%;
        padding: 8px;
        font-size: 0.9rem;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
    }

    .wishlist-btn {
        background-color: var(--marrom) !important;
    }

    .wishlist-btn:hover {
        background-color: var(--marrom-escuro) !important;
    }

    .alert {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px;
        background-color: var(--marrom-escuro);
        color: white;
        border-radius: 5px;
        z-index: 1000;
        animation: fadeInOut 3s ease-in-out;
        opacity: 0;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    @keyframes fadeInOut {
        0% { opacity: 0; transform: translateY(-20px); }
        20% { opacity: 1; transform: translateY(0); }
        80% { opacity: 1; transform: translateY(0); }
        100% { opacity: 0; transform: translateY(-20px); }
    }
    
    .admin-info {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        color: var(--preto);
        gap: 5px;
    }
</style>