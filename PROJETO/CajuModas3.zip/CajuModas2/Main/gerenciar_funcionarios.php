<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Verifica se o usuário está logado como funcionário
if (!isset($_SESSION['id_funcionario'])) {
    header("Location: login_funcionario.php");
    exit();
}

// Conexão com o banco de dados MySQLi
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Buscar todos os funcionários ativos para exibição
$funcionarios = array();
$result = $conn->query("SELECT * FROM funcionario WHERE ativo = 1"); // Mostrar apenas ativos
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $funcionarios[] = $row;
    }
    $result->free();
}

// Se estiver editando, buscar os dados do funcionário diretamente
$funcionario_edicao = null;
if (isset($_GET['editar'])) {
    $id = $conn->real_escape_string($_GET['editar']);
    $result = $conn->query("SELECT * FROM funcionario WHERE id_funcionario = $id");
    if ($result && $result->num_rows > 0) {
        $funcionario_edicao = $result->fetch_assoc();
    }
    if ($result) $result->free();
}

// Ações para adicionar, editar ou desativar funcionários
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['adicionar'])) {
        // Adicionar novo funcionário
        $matricula = $conn->real_escape_string($_POST['matricula']);
        $nome = $conn->real_escape_string($_POST['nome']);
        $email = $conn->real_escape_string($_POST['email']);
        $senha = $_POST['senha']; // Não usar real_escape_string aqui
        $cargo = $conn->real_escape_string($_POST['cargo']);
        
        // Criptografar a senha
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        
        $query = "INSERT INTO funcionario (matricula, nome, email, senha, cargo, ativo) 
                 VALUES ('$matricula', '$nome', '$email', '$senha_hash', '$cargo', 1)";
        
        if ($conn->query($query)) {
            $_SESSION['mensagem'] = "Funcionário adicionado com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao adicionar funcionário: " . $conn->error;
        }
        
        header("Location: gerenciar_funcionarios.php");
        exit();
    } elseif (isset($_POST['editar'])) {
        // Editar funcionário existente
        $id = intval($_POST['id']);
        $matricula = $conn->real_escape_string($_POST['matricula']);
        $nome = $conn->real_escape_string($_POST['nome']);
        $email = $conn->real_escape_string($_POST['email']);
        $cargo = $conn->real_escape_string($_POST['cargo']);
        
        // Verificar se a senha foi alterada
        $query_senha = "";
        if (!empty($_POST['senha'])) {
            $senha = $_POST['senha']; // Não usar real_escape_string aqui
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $query_senha = ", senha='$senha_hash'";
        }
        
        $query = "UPDATE funcionario SET matricula='$matricula', nome='$nome', email='$email', 
                 cargo='$cargo' $query_senha WHERE id_funcionario=$id";
        
        if ($conn->query($query)) {
            $_SESSION['mensagem'] = "Funcionário atualizado com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao atualizar funcionário: " . $conn->error;
        }
        
        header("Location: gerenciar_funcionarios.php");
        exit();
    } elseif (isset($_POST['desativar'])) {
        // Desativar funcionário (não permitir desativar a si mesmo)
        $id = intval($_POST['id']);
        
        if ($id == $_SESSION['id_funcionario']) {
            $_SESSION['mensagem'] = "Você não pode desativar a si mesmo!";
            header("Location: gerenciar_funcionarios.php");
            exit();
        }
        
        $query = "UPDATE funcionario SET ativo = 0 WHERE id_funcionario = $id";
        
        if ($conn->query($query)) {
            $_SESSION['mensagem'] = "Funcionário desativado com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao desativar funcionário: " . $conn->error;
        }
        
        header("Location: gerenciar_funcionarios.php");
        exit();
    }
}

// Verificar se o funcionário logado é administrador (cargo = 'Administrador')
$is_admin = ($_SESSION['cargo'] === 'Administrador');
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Funcionários | Caju Modas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Estilos mantidos iguais ao código anterior */
        :root {
            --amarelo: #f4d06f;
            --marrom: #b39977;
            --bege1: #EDE6D9;
            --bege2: #ddcfb6;
            --bege3: #e3d6be;
            --preto: #342519;
            --marrom-escuro: #684F36;
            --marrom-claro: #d1b38c;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(180deg, var(--bege1), var(--bege3));
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .menu-lateral {
            height: 100%;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: var(--bege2);
            overflow-x: hidden;
            transition: width 0.5s; 
            padding-top: 70px;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
            z-index: 20;             
        }

        .menu-lateral .fechar {
            position: absolute;
            top: 1px;
            right: 20px;
            font-size: 25px;
            color: var(--bege);
            background: none;
            border: none;
            cursor: pointer;
            transition: color 0.3s;
        }

        .menu-lateral a {
            padding: 15px 20px;
            text-decoration: none;
            font-size: 20px;
            color: var(--preto);
            display: block;
            margin: 10px 0;
            transition: 0.3s;
        }

        .menu-lateral a:hover {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            transform: scale(1.05);
        }

        .botao_hamburguer {
            position: absolute;
            left: 20px; 
            top: 8%; /* Alterado para centralizar verticalmente */
            transform: translateY(-50%);
            z-index: 10;
            background: transparent; /* Garante que o fundo seja transparente */
            border: none;
            cursor: pointer;
            padding: 0;
        }

        .page-wrapper {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            width: 100%;
        }

        header {
            background-color: var(--marrom);
            padding: 8px;
            box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
            height: 138px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .logo-container {
            flex: 1;
            text-align: center;
            margin-left: 180px;
        }

        .logo-container img {
            height: 140px;
        }

        .admin-info {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            color: var(--preto);
            gap: 5px;
        }

        .logout-btn {
            background-color: var(--marrom-escuro);
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            border: none;
            font-size: 14px;
        }

        .logout-btn:hover {
            background-color: var(--preto);
        }

        .main-content {
            flex: 1;
            padding-bottom: 40px;
        }

        .admin-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            width: 100%;
        }

        .admin-title {
            text-align: center;
            color: var(--preto);
            font-size: 2.2rem;
            margin-bottom: 30px;
        }

        .mensagem {
            background-color: var(--amarelo);
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
            color: var(--preto);
        }

        .funcionario-actions {
            margin-bottom: 20px;
            text-align: right;
        }

        .action-btn {
            background-color: var(--marrom-escuro);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .action-btn:hover {
            background-color: var(--preto);
        }

        .action-btn i {
            margin-right: 8px;
        }

        .funcionarios-table {
            background-color: var(--bege2);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }

        th, td {
            padding: 12px 8px;
            text-align: center;
            vertical-align: middle;
            border-bottom: 1px solid var(--marrom-claro);
        }

        th {
            background-color: var(--marrom);
            color: white;
            position: sticky;
            top: 0;
        }

        /* Larguras específicas para cada coluna */
        th:nth-child(1), td:nth-child(1) { width: 5%; min-width: 50px; }  /* ID */
        th:nth-child(2), td:nth-child(2) { width: 15%; } /* Matrícula */
        th:nth-child(3), td:nth-child(3) { width: 20%; } /* Nome */
        th:nth-child(4), td:nth-child(4) { width: 20%; } /* Email */
        th:nth-child(5), td:nth-child(5) { width: 15%; } /* Cargo */
        th:nth-child(6), td:nth-child(6) { width: 15%; min-width: 150px; } /* Ações */

        tr:hover {
            background-color: rgba(180, 150, 120, 0.1);
        }

        .actions-cell {
            padding: 8px !important;
        }

        .actions-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
            flex-wrap: nowrap;
        }

        .edit-btn, .delete-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }

        .edit-btn {
            background-color: var(--amarelo);
            color: var(--preto);
        }

        .delete-btn {
            background-color: #e74c3c;
            color: white;
        }

        .edit-btn:hover {
            background-color: #e6c65e;
            transform: translateY(-1px);
        }

        .delete-btn:hover {
            background-color: #c0392b;
            transform: translateY(-1px);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            overflow: auto;
        }

        .modal-content {
            background-color: var(--bege1);
            margin: 5% auto;
            padding: 25px;
            border-radius: 10px;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            position: relative;
        }

        .confirm-modal {
            text-align: center;
        }

        .close {
            position: absolute;
            top: 15px;
            right: 25px;
            font-size: 28px;
            font-weight: bold;
            color: var(--preto);
            cursor: pointer;
        }

        .close:hover {
            color: var(--marrom-escuro);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-row {
            display: flex;
            gap: 15px;
        }

        .form-row .form-group {
            flex: 1;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: var(--preto);
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--marrom);
            border-radius: 5px;
            background-color: var(--bege2);
            font-family: inherit;
        }

        .form-buttons, .confirm-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }

        .cancel-btn, #submitBtn, .delete-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .cancel-btn {
            background-color: #95a5a6;
            color: white;
        }

        .cancel-btn:hover {
            background-color: #7f8c8d;
        }

        #submitBtn {
            background-color: var(--marrom-escuro);
            color: white;
        }

        #submitBtn:hover {
            background-color: var(--preto);
        }

        footer {
            background-color: var(--marrom);
            color: var(--bege1);
            padding: 30px 0;
            text-align: center;
            margin-top: auto;
            width: 100%;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
        }

        .footer-simplificado {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .footer-logo {
            height: 100px;
            margin-bottom: 15px;
        }

        .footer-simplificado p {
            margin: 0;
            font-size: 16px;
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
                gap: 0;
            }
            
            .funcionarios-table {
                padding: 10px;
            }
            
            th, td {
                padding: 8px 10px;
                font-size: 14px;
            }
            
            .modal-content {
                width: 90%;
                margin: 10% auto;
            }

            .logo-container {
                margin-left: 0;
            }

            .admin-info {
                align-items: center;
            }

            .actions-buttons {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="page-wrapper">
        <header>
            <div class="logo-container">
                <img src="img/CM.png" alt="Logo CM">
            </div>
            <button class="botao_hamburguer" onclick="toggleMenu()">
                <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
            </button>
            <div class="admin-info">
                <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
                <span>Cargo: <?php echo htmlspecialchars($_SESSION['cargo']); ?></span>
            </div>
        </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal_adm.php">Principal</a>
        <a href="gerenciar_clientes.php">Gerenciar clientes</a>
        <a href="gerenciar_funcionarios.php">Gerenciar funcionários</a>  
        <a href="gerenciar_produtos.php">Gerenciar produtos</a>  
        <a href="gerenciar_banners.php">Alterar banner</a>        
        <a href="grafico_visitas.php">Gráfico de visitas</a>
        <a href="relatorio_vendas.php">Relatório de vendas</a>
        <a href="logout_adm.php">Sair</a>
    </div>

        <main class="main-content">
            <div class="admin-container">
                <h2 class="admin-title">Gerenciamento de Funcionários</h2>
                
                <?php if (isset($_SESSION['mensagem'])): ?>
                    <div class="mensagem">
                        <?php echo $_SESSION['mensagem']; unset($_SESSION['mensagem']); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($is_admin): ?>
                <div class="funcionario-actions">
                    <button class="action-btn" onclick="abrirModal('adicionar')">
                        <i class="fas fa-plus"></i> Adicionar Funcionário
                    </button>
                </div>
                <?php endif; ?>
                
                <div class="funcionarios-table">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Matrícula</th>
                                <th>Nome</th>
                                <th>Email</th>
                                <th>Cargo</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($funcionarios as $funcionario): ?>
                            <tr>
                                <td><?php echo $funcionario['id_funcionario']; ?></td>
                                <td><?php echo htmlspecialchars($funcionario['matricula']); ?></td>
                                <td><?php echo htmlspecialchars($funcionario['nome']); ?></td>
                                <td><?php echo htmlspecialchars($funcionario['email']); ?></td>
                                <td><?php echo htmlspecialchars($funcionario['cargo']); ?></td>
                                <td><?php echo ($funcionario['ativo'] ? 'Ativo' : 'Inativo'); ?></td>
                                <td class="actions-cell">
                                    <div class="actions-buttons">
                                        <?php if ($is_admin || $funcionario['id_funcionario'] == $_SESSION['id_funcionario']): ?>
                                        <button class="edit-btn" onclick="abrirModal('editar', <?php echo $funcionario['id_funcionario']; ?>)">
                                            <i class="fas fa-edit"></i> Editar
                                        </button>
                                        <?php endif; ?>
                                        
                                        <?php if ($is_admin && $funcionario['id_funcionario'] != $_SESSION['id_funcionario']): ?>
                                        <button class="delete-btn" onclick="confirmarDesativacao(<?php echo $funcionario['id_funcionario']; ?>)">
                                            <i></i> Desativar
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <footer>
            <div class="footer-simplificado">
                <img src="img/CM.png" alt="Logo Caju Modas" class="footer-logo">
                <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
            </div>
        </footer>
    </div>

    <!-- Modal para adicionar/editar funcionários -->
    <div id="funcionarioModal" class="modal" style="<?php echo $funcionario_edicao ? 'display: block;' : 'display: none;'; ?>">
        <div class="modal-content">
            <span class="close" onclick="fecharModal()">&times;</span>
            <h3 id="modalTitle"><?php echo $funcionario_edicao ? 'Editar Funcionário' : 'Adicionar Novo Funcionário'; ?></h3>
            
            <form id="funcionarioForm" method="POST">
                <input type="hidden" id="funcionarioId" name="id" value="<?php echo $funcionario_edicao ? $funcionario_edicao['id_funcionario'] : ''; ?>">
                
                <div class="form-group">
                    <label for="matricula">Matrícula:</label>
                    <input type="text" id="matricula" name="matricula" value="<?php echo $funcionario_edicao ? htmlspecialchars($funcionario_edicao['matricula']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="nome">Nome Completo:</label>
                    <input type="text" id="nome" name="nome" value="<?php echo $funcionario_edicao ? htmlspecialchars($funcionario_edicao['nome']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo $funcionario_edicao ? htmlspecialchars($funcionario_edicao['email']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="senha"><?php echo $funcionario_edicao ? 'Nova Senha (deixe em branco para manter a atual)' : 'Senha'; ?>:</label>
                    <input type="password" id="senha" name="senha" <?php echo $funcionario_edicao ? '' : 'required'; ?>>
                </div>
                
                <div class="form-group">
                    <label for="cargo">Cargo:</label>
                    <input type="text" id="cargo" name="cargo" value="<?php echo $funcionario_edicao ? htmlspecialchars($funcionario_edicao['cargo']) : ''; ?>" required>
                </div>
                
                <div class="form-buttons">
                    <button type="button" class="cancel-btn" onclick="fecharModal()">Cancelar</button>
                    <button type="submit" id="submitBtn" name="<?php echo $funcionario_edicao ? 'editar' : 'adicionar'; ?>">
                        <?php echo $funcionario_edicao ? 'Atualizar' : 'Adicionar'; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal de confirmação para desativação -->
    <div id="confirmModal" class="modal">
        <div class="modal-content confirm-modal">
            <h3>Confirmar Desativação</h3>
            <p>Tem certeza que deseja desativar este funcionário?</p>
            <form id="deleteForm" method="POST">
                <input type="hidden" id="deleteId" name="id">
                <div class="confirm-buttons">
                    <button type="button" class="cancel-btn" onclick="fecharConfirmModal()">Cancelar</button>
                    <button type="submit" name="desativar" class="delete-btn">Desativar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }
        function confirmarDesativacao(id) {
            document.getElementById('deleteId').value = id;
            document.getElementById('confirmModal').style.display = 'block';
        }
        // Funções para manipulação dos modais
        function abrirModal(acao, id = null) {
            const modal = document.getElementById('funcionarioModal');
            
            if (acao === 'adicionar') {
                // Limpar o formulário se for adicionar
                document.getElementById('funcionarioForm').reset();
                document.getElementById('modalTitle').textContent = 'Adicionar Novo Funcionário';
                document.getElementById('submitBtn').name = 'adicionar';
                document.getElementById('submitBtn').textContent = 'Adicionar';
                document.getElementById('funcionarioId').value = '';
                modal.style.display = 'block';
            } else if (acao === 'editar' && id) {
                // Redirecionar para a página com parâmetro de edição
                window.location.href = 'gerenciar_funcionarios.php?editar=' + id;
            }
        }
        
        function fecharModal() {
            document.getElementById('funcionarioModal').style.display = 'none';
            // Remover parâmetro de edição da URL
            if (window.location.href.includes('editar')) {
                window.location.href = 'gerenciar_funcionarios.php';
            }
        }
        
        function confirmarExclusao(id) {
            document.getElementById('deleteId').value = id;
            document.getElementById('confirmModal').style.display = 'block';
        }
        
        function fecharConfirmModal() {
            document.getElementById('confirmModal').style.display = 'none';
        }
        
        // Fechar modal ao clicar fora dele
        window.onclick = function(event) {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                if (event.target === modal) {
                    modal.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>