<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Configuração do tempo de inatividade (20 minutos)
    $inactive = 1200; // 20 minutos em segundos
    
    // Verifica se existe o timestamp da última atividade
    if (isset($_SESSION['last_activity'])) {
        // Calcula o tempo desde a última atividade
        $session_life = time() - $_SESSION['last_activity'];
        if ($session_life > $inactive) {
            // Tempo excedido - destrói a sessão e redireciona
            session_unset();
            session_destroy();
            header("Location: login.php");
            exit();
        }
    }
    
    // Atualiza o timestamp da última atividade
    $_SESSION['last_activity'] = time();
    
    // Verifica se é uma requisição AJAX para manter a sessão ativa
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' && isset($_GET['keepalive'])) {
        exit(); // Apenas atualiza a sessão e encerra
    }
    
    if(!isset($_SESSION['usuario']) || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }
    if(!isset($_SESSION['usuario'])  || $_SESSION['usuario'] == null) {
        header("Location: login.php");
        exit();
    }

// Verifica se o usuário está logado
if (!isset($_SESSION['id_cliente'])) {
    $_SESSION['mensagem'] = "Você precisa estar logado para acessar sua lista de desejos!";
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "cajumodas");

if ($conn->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

$cliente_id = $_SESSION['id_cliente'];
$mensagem = '';

// Processar remoção de item da lista de desejos
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remover'])) {
    $produto_id = $_POST['produto_id'];
    $delete_stmt = $conn->prepare("DELETE FROM lista_desejos_produto WHERE id_lista = (SELECT id_lista FROM lista_desejos WHERE id_cliente = ?) AND id_produto = ?");
    $delete_stmt->bind_param("ii", $cliente_id, $produto_id);
    
    if ($delete_stmt->execute()) {
        $_SESSION['mensagem'] = "Produto removido com sucesso!";
    } else {
        $_SESSION['mensagem'] = "Erro ao remover produto: " . $delete_stmt->error;
    }
    $delete_stmt->close();
    
    header("Location: lista_desejos.php");
    exit();
}

// Processar adição ao carrinho
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['adicionar_carrinho'])) {
    $id_produto = $_POST['id_produto'];
    $id_cliente = $_SESSION['id_cliente'];
    
    // Verificar se o produto existe e está ativo
    $stmt_produto = $conn->prepare("SELECT id_produto, estoque FROM produto WHERE id_produto = ? AND ativo = 1");
    $stmt_produto->bind_param("i", $id_produto);
    $stmt_produto->execute();
    $result_produto = $stmt_produto->get_result();
    
    if ($result_produto->num_rows === 0) {
        $_SESSION['mensagem'] = "Produto não encontrado ou indisponível!";
        header("Location: lista_desejos.php");
        exit();
    }
    
    // Verificar se o cliente já tem um carrinho
    $stmt_carrinho = $conn->prepare("SELECT id_carrinho FROM carrinho WHERE id_cliente = ?");
    $stmt_carrinho->bind_param("i", $id_cliente);
    $stmt_carrinho->execute();
    $result_carrinho = $stmt_carrinho->get_result();
    
    if ($result_carrinho->num_rows === 0) {
        // Criar novo carrinho se não existir
        $stmt_insert = $conn->prepare("INSERT INTO carrinho (id_cliente) VALUES (?)");
        $stmt_insert->bind_param("i", $id_cliente);
        
        if ($stmt_insert->execute()) {
            $id_carrinho = $stmt_insert->insert_id;
        } else {
            die("Erro ao criar carrinho: " . $stmt_insert->error);
        }
        $stmt_insert->close();
    } else {
        $row = $result_carrinho->fetch_assoc();
        $id_carrinho = $row['id_carrinho'];
    }
    $stmt_carrinho->close();
    
    // Verificar se o produto já está no carrinho
    $stmt_check = $conn->prepare("SELECT quantidade FROM carrinho_produto WHERE id_carrinho = ? AND id_produto = ?");
    $stmt_check->bind_param("ii", $id_carrinho, $id_produto);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    
    if ($result_check->num_rows > 0) {
        // Produto já está no carrinho - aumentar quantidade
        $row = $result_check->fetch_assoc();
        $nova_quantidade = $row['quantidade'] + 1;
        
        // Verificar estoque antes de atualizar
        $row_produto = $result_produto->fetch_assoc();
        if ($nova_quantidade > $row_produto['estoque']) {
            $_SESSION['mensagem'] = "Quantidade solicitada excede o estoque disponível!";
        } else {
            $stmt_update = $conn->prepare("UPDATE carrinho_produto SET quantidade = ? WHERE id_carrinho = ? AND id_produto = ?");
            $stmt_update->bind_param("iii", $nova_quantidade, $id_carrinho, $id_produto);
            
            if ($stmt_update->execute()) {
                $_SESSION['mensagem'] = "Produto adicionado ao carrinho!";
            } else {
                $_SESSION['mensagem'] = "Erro ao atualizar carrinho: " . $stmt_update->error;
            }
            $stmt_update->close();
        }
    } else {
        // Adicionar novo produto ao carrinho
        $stmt_insert = $conn->prepare("INSERT INTO carrinho_produto (id_carrinho, id_produto, quantidade) VALUES (?, ?, 1)");
        $stmt_insert->bind_param("ii", $id_carrinho, $id_produto);
        
        if ($stmt_insert->execute()) {
            $_SESSION['mensagem'] = "Produto adicionado ao carrinho com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao adicionar produto ao carrinho: " . $stmt_insert->error;
        }
        $stmt_insert->close();
    }
    $stmt_check->close();
    $stmt_produto->close();
    
    header("Location: lista_desejos.php");
    exit();
}

// Buscar produtos na lista de desejos do cliente
$query = "SELECT p.id_produto, p.nome, p.descricao, p.preco, p.produto_promocional, p.caminho_imagem, p.estoque
          FROM lista_desejos_produto lp
          JOIN lista_desejos ld ON lp.id_lista = ld.id_lista
          JOIN Produto p ON lp.id_produto = p.id_produto
          WHERE ld.id_cliente = ? AND p.ativo = 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $cliente_id);
$stmt->execute();
$produtos = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Lista de Desejos | Caju Modas</title>
    <style>
        :root {
            --amarelo: #f4d06f;
            --marrom: #b39977;
            --bege1: #EDE6D9;
            --bege2: #ddcfb6;
            --bege3: #e3d6be;
            --preto: #342519;
            --marrom-escuro: #684F36;
        }

        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: linear-gradient(180deg, var(--bege1), var(--bege3));
            min-height: 100vh;
        }

        header {
            background-color: var(--marrom);
            padding: 8px;
            box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
            height: 138px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            position: relative;
        }

        .logo {
            flex: 1;
            text-align: center;
        }
        
        .logo img {
            height: 140px;
            vertical-align: middle;
        }

        .botao_hamburguer {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            z-index: 10;
        }

        .menu-lateral {
            height: 100%;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: var(--bege2);
            overflow-x: hidden;
            transition: width 0.5s; 
            padding-top: 70px;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
            z-index: 20;
        }

        .menu-lateral .fechar {
            position: absolute;
            top: 1px;
            right: 20px;
            font-size: 25px;
            color: var(--bege);
            background: none;
            border: none;
            cursor: pointer;
            transition: color 0.3s;
        }

        .menu-lateral a {
            padding: 15px 20px;
            text-decoration: none;
            font-size: 20px;
            color: var(--preto);
            display: block;
            margin: 10px 0;
            transition: 0.3s;
        }

        .menu-lateral a:hover {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            transform: scale(1.05);
        }

        /* ESTILOS DA LISTA DE DESEJOS */
        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        h2 {
            text-align: center;
            color: var(--marrom-escuro);
            font-size: 2.5rem;
            margin-bottom: 40px;
        }

        .produtos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 10px;
            padding: 20px;
        }

        .produto-card {
            background: var(--bege2);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            display: flex;
            flex-direction: column;
            border: 2px solid var(--bege3);
        }

        .produto-imagem-container {
            min-width: 250px;
            background: var(--bege2);
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .produto-imagem {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .preco-promocional {
            color: #d00;
            font-weight: bold;
            font-size: 1.3rem;
        }
        
        .preco-original {
            text-decoration: line-through;
            color: #777;
            font-size: 1rem;
        }

        .produto-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .produto-info {
            padding: 20px;
            display: flex;
            flex-direction: column;
            margin-top: auto;
        }

        .produto-info h3 {
            color: var(--marrom-escuro);
            margin: 0 0 10px 0;
            font-size: 1.4rem;
        }

        .produto-info p {
            color: var(--preto);
            margin: 5px 0;
            flex-grow: 1;
        }

        .preco {
            font-size: 1.3rem;
            color: var(--marrom-escuro);
            font-weight: bold;
            margin: 15px 0;
        }

        .produto-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .btn-carrinho {
            background-color: var(--marrom-escuro);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-remover {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-carrinho:hover {
            background-color: var(--preto);
        }

        .btn-remover:hover {
            background-color: #c9302c;
        }

        .lista-vazia {
            text-align: center;
            padding: 90px;
            font-size: 1.2rem;
            color: var(--marrom-escuro);
            border: 2px dashed var(--bege2);
            border-radius: 12px;
            margin: 40px 0;
        }

        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px;
            background-color: var(--marrom-escuro);
            color: white;
            border-radius: 5px;
            z-index: 1000;
            animation: fadeInOut 3s ease-in-out;
            opacity: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .mensagem {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px;
            background-color: var(--marrom-escuro);
            color: white;
            border-radius: 5px;
            z-index: 1000;
            animation: fadeInOut 3s ease-in-out;
            opacity: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        @keyframes fadeInOut {
            0% { opacity: 0; transform: translateY(-20px); }
            20% { opacity: 1; transform: translateY(0); }
            80% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(-20px); }
        }

        /* FOOTER */
        footer {
            background-color: var(--marrom);
            color: var(--bege1);
            padding: 20px 0;
            margin-top: 50px;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            flex-wrap: wrap;
            padding: 20px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-info, .footer-img, .footer-social {
            flex: 1;
            padding: 10px;
            text-align: center;
            min-width: 250px;
        }

        .footer-img img {
            width: 100px;
            height: auto;
            border-radius: 8px;
        }

        .footer-social {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .footer-social a {
            color: var(--bege1);
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: color 0.3s;
        }

        .footer-social a:hover {
            color: var(--amarelo);
        }

        .footer-icon {
            width: 24px;
            height: 24px;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .produtos-grid {
                grid-template-columns: 1fr;
            }
            
            .produto-imagem-container {
                height: 250px;
            }
            
            h2 {
                font-size: 2rem;
            }
            
            header {
                flex-direction: column;
                height: auto;
                padding: 15px;
            }
            
            .admin-info {
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                color: var(--preto);
                gap: 5px;
            }
            
            .botao_hamburguer {
                position: static;
                transform: none;
                margin-bottom: 10px;
                order: 1;
            }
            
            .logo {
                order: 2;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1 class="logo">
            <a href="principal.php">
                <img src="img/CM.png" alt="Logo CM">
            </a>
        </h1>

        <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
        
        <div class="admin-info">
            <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
        </div>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="lista_desejos.php">Lista de desejos</a>  
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
        <a href="logout.php">Sair</a>
    </div>

    <div class="container">
        <h2>Sua Lista de Desejos</h2>
        
        <?php if (isset($_SESSION['mensagem'])): ?>
            <div class="alert">
                <i class="fas fa-check-circle"></i>
                <?php echo $_SESSION['mensagem']; unset($_SESSION['mensagem']); ?>
            </div>
        <?php endif; ?>

        <?php if ($produtos->num_rows === 0): ?>
            <div class="lista-vazia">
                <p>Sua lista de desejos está vazia.</p>
                <p><a href="produtos.php" style="color: var(--marrom-escuro);">Explore nossos produtos</a> e adicione itens à sua lista!</p>
            </div>
        <?php else: ?>
            <div class="produtos-grid">
                <?php while ($produto = $produtos->fetch_assoc()): ?>
                    <div class="produto-card">
                        <div class="produto-imagem-container">
                            <img src="<?php echo htmlspecialchars($produto['caminho_imagem']); ?>" 
                                 alt="<?php echo htmlspecialchars($produto['nome']); ?>" 
                                 class="produto-imagem">
                        </div>
                        <div class="produto-info">
                            <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                            <p><?php echo htmlspecialchars($produto['descricao']); ?></p>
                            
                            <?php if ($produto['produto_promocional'] > 0 && $produto['produto_promocional'] < $produto['preco']): ?>
                                <p class="preco-original">De: R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                                <p class="preco-promocional">Por: R$ <?php echo number_format($produto['produto_promocional'], 2, ',', '.'); ?></p>
                            <?php else: ?>
                                <p class="preco">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                            <?php endif; ?>
                            
                            <div class="produto-actions">
                                <form method="POST">
                                    <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                    <button type="submit" name="adicionar_carrinho" class="btn-carrinho">
                                        <i class="fas fa-shopping-cart"></i> Carrinho
                                    </button>
                                </form>
                                
                                <form method="POST">
                                    <input type="hidden" name="produto_id" value="<?php echo $produto['id_produto']; ?>">
                                    <button type="submit" name="remover" class="btn-remover">
                                        <i class="fas fa-trash-alt"></i> Remover
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <div class="footer-container">
            <div class="footer-info">
                <h3>Contato</h3>
                <p>Telefone: (41) 9999-9999</p>
                <p>E-mail: <a href="mailto:CAJUMODAS@gmail.com">CAJUMODAS@gmail.com</a></p>
            </div>
            
            <div class="footer-img">
                <img src="img/CM.png" alt="Logo Caju Modas">
            </div>
            
            <div class="footer-social">
                <h3>Siga-nos:</h3>
                <a href="#" class="social-link">    
                    <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                    Tiktok
                </a>
                <a href="#" class="social-link">
                    <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                    Instagram 
                </a>
                <a href="#" class="social-link">
                    <img src="img/x.png" alt="Twitter" class="footer-icon">
                    Twitter 
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
        </div>
    </footer>

    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = menuLateral.style.width === "250px" ? "0" : "250px";
        }

        // Fechar o menu ao clicar fora
        document.addEventListener('click', function(event) {
            const menuLateral = document.getElementById("menuLateral");
            const botaoHamburguer = document.querySelector('.botao_hamburguer');
            
            if (menuLateral.style.width === "250px" && 
                !menuLateral.contains(event.target) && 
                !botaoHamburguer.contains(event.target)) {
                menuLateral.style.width = "0";
            }
        });

        // Monitora atividade do usuário para manter a sessão ativa
    const activityEvents = ['mousemove', 'keypress', 'scroll', 'click', 'touchstart'];
    activityEvents.forEach(event => {
        document.addEventListener(event, resetTimer, {passive: true});
    });

    let timeout;
    const inactiveTime = 1200000; // 20 minutos em milissegundos

    function resetTimer() {
        clearTimeout(timeout);
        timeout = setTimeout(logout, inactiveTime);
        
        // Atualiza a sessão no servidor sem recarregar a página
        updateSession();
    }

    function logout() {
        window.location.href = 'login.php?timeout=1';
    }

    function updateSession() {
        // Usa fetch para fazer uma requisição silenciosa ao mesmo arquivo
        fetch(window.location.href + '?keepalive=1', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            cache: 'no-store'
        }).catch(error => console.error('Erro ao manter sessão:', error));
    }

    // Inicia o timer quando a página carrega
    resetTimer();
    </script>
</body>
</html>
<?php
$conn->close();
?>