<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['id_cliente'])) {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
$conn = new mysqli('localhost', 'root', '', 'cajumodas');

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// ID do cliente logado
$id_cliente = $_SESSION['id_cliente'];

// Processar remoção de item da lista de desejos
if (isset($_POST['remover_item'])) {
    $id_produto = $_POST['id_produto'];
    
    $sql = "DELETE FROM Lista_Desejos_Produto 
            WHERE id_lista = (SELECT id_lista FROM Lista_Desejos WHERE id_cliente = ?) 
            AND id_produto = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_cliente, $id_produto);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        $_SESSION['mensagem'] = "Item removido da lista de desejos!";
    } else {
        $_SESSION['erro'] = "Erro ao remover item da lista de desejos.";
    }
    
    header("Location: lista_desejos.php");
    exit();
}

// Processar mover para carrinho
if (isset($_POST['mover_carrinho'])) {
    $id_produto = $_POST['id_produto'];
    
    // 1. Verificar se o carrinho existe, se não, criar
    $sql_check_carrinho = "SELECT id_carrinho FROM Carrinho WHERE id_cliente = ?";
    $stmt = $conn->prepare($sql_check_carrinho);
    $stmt->bind_param("i", $id_cliente);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        $sql_create_carrinho = "INSERT INTO Carrinho (id_cliente) VALUES (?)";
        $stmt = $conn->prepare($sql_create_carrinho);
        $stmt->bind_param("i", $id_cliente);
        $stmt->execute();
        $id_carrinho = $conn->insert_id;
    } else {
        $row = $result->fetch_assoc();
        $id_carrinho = $row['id_carrinho'];
    }
    
    // 2. Remover da lista de desejos
    $sql_remover = "DELETE FROM Lista_Desejos_Produto 
                   WHERE id_lista = (SELECT id_lista FROM Lista_Desejos WHERE id_cliente = ?) 
                   AND id_produto = ?";
    
    $stmt = $conn->prepare($sql_remover);
    $stmt->bind_param("ii", $id_cliente, $id_produto);
    $stmt->execute();
    
    // 3. Adicionar ao carrinho
    $sql_carrinho = "INSERT INTO Carrinho_Produto (id_carrinho, id_produto, quantidade)
                    VALUES (?, ?, 1)
                    ON DUPLICATE KEY UPDATE quantidade = quantidade + 1";
    
    $stmt = $conn->prepare($sql_carrinho);
    $stmt->bind_param("ii", $id_carrinho, $id_produto);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        $_SESSION['mensagem'] = "Item movido para o carrinho com sucesso!";
    } else {
        $_SESSION['erro'] = "Erro ao mover item para o carrinho.";
    }
    
    header("Location: carrinho.php");
    exit();
}

// Buscar lista de desejos do cliente
$sql = "SELECT p.* FROM Lista_Desejos_Produto ldp
        JOIN Produto p ON ldp.id_produto = p.id_produto
        JOIN Lista_Desejos ld ON ldp.id_lista = ld.id_lista
        WHERE ld.id_cliente = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Caju Modas - Lista de Desejos</title>
    <style>
        /* Seus estilos CSS permanecem os mesmos */
    </style>
</head>
<body>

    <header>
        <h1 class="logo">
            <a>
              <img src="img/CM.png" alt="Logo CM">
            </a>
          </h1>
          
        <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="lista_desejos.php">Lista de desejos</a>  
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
    </div>

    <div class="wishlist-container">
        <h1><i class="fas fa-heart"></i> Minha Lista de Desejos</h1>
        
        <?php if (isset($_SESSION['mensagem'])): ?>
            <div class="alert success"><?= $_SESSION['mensagem'] ?></div>
            <?php unset($_SESSION['mensagem']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['erro'])): ?>
            <div class="alert error"><?= $_SESSION['erro'] ?></div>
            <?php unset($_SESSION['erro']); ?>
        <?php endif; ?>
        
        <div class="wishlist-grid">
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="wishlist-item">
                        <div class="item-image">
                            <img src="<?= htmlspecialchars($row['caminho_imagem']) ?>" alt="<?= htmlspecialchars($row['nome']) ?>">
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="id_produto" value="<?= $row['id_produto'] ?>">
                                <button type="submit" name="remover_item" class="remove-btn" title="Remover item">
                                    <i class="fas fa-times"></i>
                                </button>
                            </form>
                        </div>
                        <div class="item-info">
                            <h3><?= htmlspecialchars($row['nome']) ?></h3>
                            <p class="price">R$ <?= number_format($row['preco'], 2, ',', '.') ?></p>
                            <div class="item-actions">
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="id_produto" value="<?= $row['id_produto'] ?>">
                                    <button type="submit" name="mover_carrinho" class="move-to-cart">Mover para Carrinho</button>
                                </form>
                                <button class="view-details" data-id="<?= $row['id_produto'] ?>">Ver Detalhes</button>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="wishlist-empty">
                    <i class="far fa-heart"></i>
                    <h2>Sua lista de desejos está vazia</h2>
                    <p>Adicione itens que você ama clicando no ícone de coração nos produtos.</p>
                    <a href="produtos.php" class="browse-btn">Navegar Produtos</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal de Detalhes do Produto -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-body">
                <img id="modalImage" class="modal-img" src="" alt="Produto">
                <h2 id="modalTitle" class="modal-title"></h2>
                <p id="modalDescription" class="modal-description"></p>
                <p id="modalPrice" class="modal-price"></p>
                <p id="modalStock" class="modal-stock"></p>
                
                <div class="size-options">
                    <label>Tamanho:</label>
                    <select id="sizeSelect" class="size-select">
                        <!-- Opções serão preenchidas via JavaScript -->
                    </select>
                </div>
                
                <div class="modal-actions">
                    <button id="addToCart" class="add-to-cart">
                        <i class="fas fa-shopping-cart"></i> Adicionar ao Carrinho
                    </button>
                    <button id="addToWishlist" class="add-to-wishlist">
                        <i class="fas fa-heart"></i> Lista de Desejos
                    </button>
                </div>
            </div>
        </div>
    </div>

    <footer>
    <div class="footer-container">
            <div class="footer-info">
                <h2>Contato</h2>
                <p>Telefone: (41) 9999-9999</p>
                <p>E-mail: <a href="">CAJUMODAS@gmail.com</a></p>
            </div>
            
            <div class="footer-img">
                <img src="img/CM.png" alt="Logo Caju Modas">
            </div>
            
            <div class="footer-social">
                <h2>Siga-nos:</h2>
                <a href="" class="social-link">    
                    <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                    Tiktok
                </a>
                <a href="" class="social-link">
                    <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                    Instagram 
                </a>
                <a href="" class="social-link">
                    <img src="img/x.png" alt="Twitter" class="footer-icon">
                    Twitter 
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
        </div>
    </footer>

    <script>
        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }
        
        // Adicionar evento de clique para os botões de detalhes
        document.querySelectorAll('.view-details').forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                fetchProductDetails(productId);
            });
        });
        
        // Fechar modal quando clicar no X
        document.querySelector('.close-modal').addEventListener('click', function() {
            document.getElementById('productModal').style.display = 'none';
        });
        
        // Buscar detalhes do produto via AJAX
        function fetchProductDetails(productId) {
            fetch(`detalhes_produto.php?id=${productId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const product = data.product;
                        document.getElementById('modalImage').src = product.caminho_imagem;
                        document.getElementById('modalTitle').textContent = product.nome;
                        document.getElementById('modalDescription').textContent = product.descricao;
                        document.getElementById('modalPrice').textContent = `R$ ${parseFloat(product.preco).toFixed(2).replace('.', ',')}`;
                        document.getElementById('modalStock').textContent = `Estoque: ${product.estoque} unidades`;
                        
                        // Preencher opções de tamanho
                        const sizeSelect = document.getElementById('sizeSelect');
                        sizeSelect.innerHTML = '';
                        if (product.tamanho) {
                            const sizes = product.tamanho.split(',');
                            sizes.forEach(size => {
                                const option = document.createElement('option');
                                option.value = size.trim();
                                option.textContent = size.trim();
                                sizeSelect.appendChild(option);
                            });
                        }
                        
                        // Mostrar modal
                        document.getElementById('productModal').style.display = 'block';
                    } else {
                        alert('Erro ao carregar detalhes do produto');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Erro ao carregar detalhes do produto');
                });
        }
        
        // Adicionar evento para o botão de adicionar ao carrinho no modal
        document.getElementById('addToCart').addEventListener('click', function() {
            const productId = document.querySelector('.view-details[data-id]').getAttribute('data-id');
            const size = document.getElementById('sizeSelect').value;
            
            fetch('adicionar_carrinho.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id_produto=${productId}&tamanho=${size}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Produto adicionado ao carrinho!');
                    document.getElementById('productModal').style.display = 'none';
                } else {
                    alert('Erro: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Erro ao adicionar ao carrinho');
            });
        });
    </script>
</body>
</html>
<style>
    :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
    }

    header {
        background-color: var(--marrom);
        padding: 8px;
        text-align: center;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }



    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }


    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }
     
    .login {
        position: absolute;
        Right: 20px; 
        top: 8%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }

    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }
    
    footer {
        background-color: var(--marrom);
        color: var(--bege1);
        padding: 1px 0; 
        margin-top: 10px; 
    }

     
    .login {
        position: absolute;
        Right: 20px; 
        top: 10%;
        transform: translateY(-50%);
        z-index: 10;
        height: 100px;
        width: auto;
        max-width: none; 
    }

    /* Estilos para a Lista de Desejos */
    .wishlist-container {
        max-width: 1200px;
        margin: 30px auto;
        padding: 20px;
    }

    .wishlist-container h1 {
        text-align: center;
        color: var(--marrom-escuro);
        font-size: 2.5rem;
        margin-bottom: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 15px;
    }

    .wishlist-container h1 i {
        color: #e63946;
    }

    .wishlist-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 25px;
        margin-top: 20px;
    }

    .wishlist-item {
        background-color: var(--bege2);
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        position: relative;
    }

    .wishlist-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    }

    .item-image {
        position: relative;
        height: 300px;
        overflow: hidden;
    }

    .item-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .wishlist-item:hover .item-image img {
        transform: scale(1.05);
    }

    .remove-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        background-color: rgba(255, 255, 255, 0.8);
        border: none;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .remove-btn:hover {
        background-color: #e63946;
        color: white;
    }

    .item-info {
        padding: 15px;
    }

    .item-info h3 {
        margin: 0 0 10px;
        color: var(--preto);
        font-size: 1.2rem;
    }

    .price {
        font-weight: bold;
        color: var(--marrom-escuro);
        font-size: 1.1rem;
        margin: 10px 0;
    }

    .item-actions {
        display: flex;
        gap: 10px;
        margin-top: 15px;
    }

    .move-to-cart, .view-details {
        flex: 1;
        padding: 8px 0;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .move-to-cart {
        background-color: var(--marrom-escuro);
        color: white;
    }

    .move-to-cart:hover {
        background-color: var(--preto);
    }

    .view-details {
        background-color: var(--bege1);
        color: var(--preto);
        border: 1px solid var(--marrom);
    }

    .view-details:hover {
        background-color: var(--marrom);
        color: white;
    }

    .wishlist-empty {
        text-align: center;
        padding: 50px 20px;
        background-color: var(--bege2);
        border-radius: 10px;
        margin-top: 30px;
        grid-column: 1 / -1;
    }

    .wishlist-empty i {
        font-size: 3rem;
        color: #e63946;
        margin-bottom: 20px;
    }

    .wishlist-empty h2 {
        color: var(--marrom-escuro);
        margin-bottom: 15px;
    }

    .wishlist-empty p {
        color: var(--preto);
        margin-bottom: 25px;
        font-size: 1.1rem;
    }

    .browse-btn {
        display: inline-block;
        padding: 10px 25px;
        background-color: var(--marrom-escuro);
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
    }

    .browse-btn:hover {
        background-color: var(--preto);
    }

    /* Estilos do Modal */
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.5);
    }

    .modal-content {
        background-color: var(--bege1);
        margin: 10% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 600px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }

    .close-modal {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close-modal:hover {
        color: black;
    }

    .modal-body {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .modal-img {
        width: 100%;
        max-height: 300px;
        object-fit: contain;
        border-radius: 5px;
    }

    .modal-title {
        font-size: 1.5rem;
        font-weight: bold;
        margin: 0;
        color: var(--preto);
    }

    .modal-description {
        color: var(--preto);
        font-size: 1rem;
        margin: 10px 0;
    }

    .modal-price {
        font-size: 1.3rem;
        color: var(--marrom-escuro);
        font-weight: bold;
    }

    .modal-stock {
        font-size: 0.9rem;
        color: var(--preto);
    }

    .size-options {
        display: flex;
        align-items: center;
        gap: 10px;
        margin: 10px 0;
    }

    .size-select {
        padding: 8px;
        border-radius: 5px;
        border: 1px solid var(--marrom);
        background-color: var(--bege2);
    }

    .modal-actions {
        display: flex;
        gap: 10px;
        margin-top: 15px;
    }

    .add-to-cart, .add-to-wishlist {
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        flex: 1;
    }

    .add-to-cart {
        background-color: var(--marrom-escuro);
        color: white;
    }

    .add-to-cart:hover {
        background-color: var(--preto);
    }

    .add-to-wishlist {
        background-color: var(--bege2);
        color: var(--preto);
        border: 1px solid var(--marrom);
    }

    .add-to-wishlist:hover {
        background-color: var(--marrom);
        color: white;
    }

    footer {
        background-color: var(--marrom);
        color: var(--bege1);
        padding: 1px 0; 
        margin-top: 10px; 
    }

    .footer-container {
        display: flex;
        justify-content: space-around;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
        flex-wrap: wrap; 
        padding: 10px 0;
        border-bottom: 3px solid #333;
    }

    .footer-info, .footer-img, .footer-social {
        flex: 1;
        padding: 5px; 
        text-align: center; 
    }

    .footer-img img {
        width: 120;
        height: 100px;
        border-radius: 8px;
    }

    .footer-social {
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: flex-end; 
        gap: 8px; 
        padding-right: 20px; 
    }

    .footer-social a {
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--bege1);
        text-decoration: none;
        flex-direction: row-reverse; 
        font-size: 22px;
    }

    .footer-icon {
        width: 37px; 
        height: 37px;
        margin-left: 12px; 
        transition: transform 0.3s;
    }

    .footer-social a:hover .footer-icon {
        transform: scale(1.2);
    }

    .footer-bottom {
        margin-top: 10px;
        font-size: 14px;
        text-align: center;
    }

    .logo {
        margin: 0;
        padding: 0;
    }
    
    .logo img {
        height: 140px; 
        vertical-align: middle;
    }

    @media (max-width: 768px) {
        .wishlist-grid {
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        }
        
        .item-actions {
            flex-direction: column;
        }
        
        .wishlist-container h1 {
            font-size: 2rem;
        }
        
        .modal-content {
            width: 90%;
        }
    }

    @media (max-width: 480px) {
        .wishlist-grid {
            grid-template-columns: 1fr;
        }
        
        .wishlist-container {
            padding: 15px;
        }
        
        .modal-actions {
            flex-direction: column;
        }
    }
</style>