<?php
session_start();
$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cpf = preg_replace('/[^0-9]/', '', $_POST["usuario"]); // Remove caracteres não numéricos
    $senha = $_POST["senha"];

    // Conexão com o banco
    $conn = new mysqli("localhost", "root", "", "cajumodas");

    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    // Verificar se o CPF existe
    $stmt = $conn->prepare("SELECT id_cliente, nome, email, cpf, senha FROM cliente WHERE cpf = ?");
    if ($stmt) {
        $stmt->bind_param("s", $cpf);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $usuario = $resultado->fetch_assoc();

            // Verificar senha (com hash)
            if (password_verify($senha, $usuario["senha"])) {
                // Armazenar dados do usuário na sessão
                $_SESSION['usuario'] = $usuario['cpf']; // Identificador único
                $_SESSION['nome'] = $usuario['nome'];   // Nome para exibição
                $_SESSION['id_cliente'] = $usuario['id_cliente']; // ID para operações
                $_SESSION['email'] = $usuario['email']; // Email do usuário

                // Redirecionar para a página principal ou URL anterior
                $redirect_url = $_SESSION['redirect_url'] ?? 'principal.php';
                unset($_SESSION['redirect_url']);
                header("Location: " . $redirect_url);
                exit();
            } else {
                $mensagem = "Senha incorreta.";
            }
        } else {
            $mensagem = "CPF não cadastrado.";
        }

        $stmt->close();
    } else {
        $mensagem = "Erro ao preparar a consulta: " . $conn->error;
    }

    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login | Caju Modas</title>
    
</head>
<body>

<header>
        <h1 class="logo">
            <a>
              <img src="img/CM.png" alt="Logo CM">
            </a>
          </h1>
          
    </header>

    <div class="quadrado_login">
        <form method="POST">
            <label class="login_texto">Login</label>
            <label class="texto_usuario" for="usuario">CPF:</label>
            <input type="text" name="usuario" class="usuario" required placeholder="Digite seu CPF (apenas números)">

            <label class="texto_usuario" for="senha">Senha:</label>
            <input type="password" name="senha" class="senha_login" required placeholder="Digite sua senha">

            <button type="submit" class="login_botao">Entrar</button>

            <label class="texto_cadastro">Ainda não tem uma conta? <a href="cadastro.php">Cadastre-se</a></label>
            <?php if (!empty($mensagem)) echo "<p class='erro'>$mensagem</p>"; ?>
        </form>
    </div>

</body>
</html>
<style>
        :root {
            --amarelo: #f4d06f;
            --marrom: #b39977;
            --bege1: #EDE6D9;
            --bege2: #ddcfb6;
            --bege3: #e3d6be;
            --preto: #342519;
            --marrom-escuro: #684F36;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(180deg, var(--bege1), var(--bege3));
            color: var(--preto);
            background-color: var(--bege2);
        }


        nav {
            text-align: center;
        }
        .home {
            text-decoration: none;
            color: var(--preto);
            font-size: 18px;
            font-weight: bold;
        }

        header {
        background-color: var(--marrom);
        padding: 8px;
        text-align: center;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
    }

    
    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }

        .quadrado_login {
        background: var(--bege2);
        width: 300px;
        padding: 20px;
        margin: 10px auto;
        margin-top: 100px;
        margin-bottom: 400px;
        border-radius: 12px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        gap: 10px;
        }

        .login_texto {
            font-size: 24px;
            margin-bottom: 25px;
            display: block;
        }

        .usuario, .senha_login {
            width: 94%;
            padding: 8px;
            border: 2px solid maroon;
            border-radius: 20px;
            font-size: 14px;
            margin-bottom: 10px;
            margin-top: 10px;
        }

        .login_botao {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            border: none;
            padding: 10px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            margin-top: 5px;
            margin-bottom: 20px;
        }

        .login_botao:hover {
            background-color: var(--preto);
        }

        .texto_cadastro {
            font-size: 14px;
            text-align: center;
            margin-top: 10px;
        }

        .erro {
            color: red;
            font-size: 14px;
            text-align: center;
            margin-top: 10px;
        }
        .logo {
        margin: 0;
        padding: 0;
        }
    
        .logo img {
        height: 140px; /* ou o tamanho ideal pra sua logo */
        vertical-align: middle;
        }
    </style>
