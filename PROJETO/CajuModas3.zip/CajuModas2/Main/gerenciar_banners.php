<?php
session_start();
    header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
// Verifica se o usuário é um administrador logado
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'funcionario') {
    header("Location: login_funcionario.php");
    exit();
}

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "cajumodas");
if ($conn->connect_error) {
    die("Serviço temporariamente indisponível. Estamos trabalhando para resolver o problema.");
}

// Processar upload de novo banner
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['novo_banner'])) {
    $target_dir = "img/";
    $target_file = $target_dir . basename($_FILES["novo_banner"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Verificar se é uma imagem real
    $check = getimagesize($_FILES["novo_banner"]["tmp_name"]);
    if ($check === false) {
        $uploadOk = 0;
        $mensagem = "O arquivo não é uma imagem.";
    }

    // Verificar se o arquivo já existe
    if (file_exists($target_file)) {
        $uploadOk = 0;
        $mensagem = "Desculpe, um arquivo com esse nome já existe.";
    }

    // Verificar tamanho do arquivo (max 5MB)
    if ($_FILES["novo_banner"]["size"] > 5000000) {
        $uploadOk = 0;
        $mensagem = "Desculpe, seu arquivo é muito grande (máx. 5MB).";
    }

    // Permitir apenas certos formatos
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
        $uploadOk = 0;
        $mensagem = "Desculpe, apenas arquivos JPG, JPEG, PNG e GIF são permitidos.";
    }

    // Tentar fazer o upload se tudo estiver OK
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["novo_banner"]["tmp_name"], $target_file)) {
            // Inserir no banco de dados
            $sql = "INSERT INTO Banner (caminho_imagem) VALUES (?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $target_file);
            
            if ($stmt->execute()) {
                $mensagem = "O banner foi adicionado com sucesso!";
            } else {
                $mensagem = "Erro ao salvar no banco de dados: " . $conn->error;
                unlink($target_file);
            }
            $stmt->close();
        } else {
            $mensagem = "Desculpe, houve um erro ao enviar seu arquivo.";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remover_banner'])) {
    $id_banner = $_POST['id_banner'];
    
    $sql = "SELECT caminho_imagem FROM Banner WHERE id_banner = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_banner);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $caminho_imagem = $row['caminho_imagem'];
        
        if (file_exists($caminho_imagem)) {
            unlink($caminho_imagem);
        }
        
        $sql = "DELETE FROM Banner WHERE id_banner = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_banner);
        
        if ($stmt->execute()) {
            $mensagem = "Banner removido com sucesso!";
        } else {
            $mensagem = "Erro ao remover o banner do banco de dados: " . $conn->error;
        }
    } else {
        $mensagem = "Banner não encontrado.";
    }
    $stmt->close();
}

$sql = "SELECT * FROM Banner ORDER BY id_banner DESC";
$result = $conn->query($sql);
$banners = $result->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Banners | Caju Modas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="logo-container">
            <img src="img/CM.png" alt="Logo CM">
        </div>
        <button class="botao_hamburguer" onclick="toggleMenu()">
                <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
        <div class="admin-info">
            <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></span>
            <span>Cargo: <?php echo htmlspecialchars($_SESSION['cargo']); ?></span>
        </div>
    </header>
    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal_adm.php">Principal</a>
        <a href="gerenciar_clientes.php">Gerenciar clientes</a>
        <a href="gerenciar_funcionarios.php">Gerenciar funcionários</a>  
        <a href="gerenciar_produtos.php">Gerenciar produtos</a>  
        <a href="gerenciar_banners.php">Alterar banner</a>        
        <a href="grafico_visitas.php">Gráfico de visitas</a>
        <a href="relatorio_vendas.php">Relatório de vendas</a>
        <a href="logout_adm.php">Sair</a>
    </div>

    <div class="admin-container">
        <h2 class="admin-title">Gerenciar Banners</h2>
        
        <?php if (isset($mensagem)): ?>
            <div class="mensagem <?php echo strpos($mensagem, 'sucesso') !== false ? 'sucesso' : 'erro'; ?>">
                <?php echo htmlspecialchars($mensagem); ?>
            </div>
        <?php endif; ?>
        
        <div class="banner-management">
            <div class="add-banner">
                <h3>Adicionar Novo Banner</h3>
                <form action="gerenciar_banners.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="novo_banner">Selecione uma imagem:</label>
                        <input type="file" id="novo_banner" name="novo_banner" accept="image/*" required>
                    </div>
                    <button type="submit" class="btn-submit">Enviar Banner</button>
                </form>
            </div>
            
            <div class="current-banners">
                <h3>Banners Atuais</h3>
                <?php if (empty($banners)): ?>
                    <p>Nenhum banner cadastrado.</p>
                <?php else: ?>
                    <div class="banners-grid">
                        <?php foreach ($banners as $banner): ?>
                            <div class="banner-item">
                                <img src="<?php echo htmlspecialchars($banner['caminho_imagem']); ?>" alt="Banner <?php echo $banner['id_banner']; ?>">
                                <form action="gerenciar_banners.php" method="post" onsubmit="return confirm('Tem certeza que deseja remover este banner?');">
                                    <input type="hidden" name="id_banner" value="<?php echo $banner['id_banner']; ?>">
                                    <button type="submit" name="remover_banner" class="btn-remove">Remover</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-simplificado">
            <img src="img/CM.png" alt="Logo Caju Modas" class="footer-logo">
            <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
        </div>
    </footer>
</body>
</html>

<style>
    :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    header {
        background-color: var(--marrom);
        padding: 8px;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
    }

    .logo-container {
        flex: 1;
        text-align: center;
        margin-left: 180px;
    }

    .logo-container img {
        height: 140px;
    }

    .admin-info {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        color: var(--preto);
        gap: 5px;
    }

    .logout-btn {
        background-color: var(--marrom-escuro);
        color: white;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
        border: none;
        font-size: 14px;
    }

    .logout-btn:hover {
        background-color: var(--preto);
    }

    .admin-container {
        max-width: 1200px;
        margin: 30px auto;
        padding: 20px;
        flex: 1;
    }

    .admin-title {
        text-align: center;
        color: var(--preto);
        font-size: 2.2rem;
        margin-bottom: 30px;
    }

    .banner-management {
        background-color: var(--bege2);
        border-radius: 10px;
        padding: 25px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border: 2px solid var(--marrom);
    }

    .add-banner, .current-banners {
        margin-bottom: 30px;
    }

    .add-banner h3, .current-banners h3 {
        color: var(--preto);
        font-size: 1.5rem;
        margin-bottom: 15px;
        padding-bottom: 5px;
        border-bottom: 2px solid var(--marrom);
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        color: var(--preto);
        font-weight: bold;
    }

    .form-group input[type="file"] {
        width: 100%;
        padding: 8px;
        border: 1px solid var(--marrom);
        border-radius: 5px;
        background-color: var(--bege1);
    }

    .btn-submit, .btn-remove {
        background-color: var(--marrom-escuro);
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1rem;
        transition: background-color 0.3s;
    }

    .btn-submit:hover, .btn-remove:hover {
        background-color: var(--preto);
    }

    .btn-remove {
        background-color: #d9534f;
        margin-top: 10px;
        width: 100%;
    }

    .btn-remove:hover {
        background-color: #c9302c;
    }

    .banners-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
    }

    .banner-item {
        background-color: var(--bege1);
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border: 1px solid var(--marrom);
    }

    .banner-item img {
        width: 100%;
        height: auto;
        border-radius: 5px;
        display: block;
    }

    .mensagem {
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 5px;
        text-align: center;
        font-weight: bold;
    }

    .mensagem.sucesso {
        background-color: #dff0d8;
        color: #3c763d;
        border: 1px solid #d6e9c6;
    }

    .mensagem.erro {
        background-color: #f2dede;
        color: #a94442;
        border: 1px solid #ebccd1;
    }

    .back-link {
        margin-top: 30px;
        text-align: center;
    }

    .back-link a {
        color: var(--marrom-escuro);
        text-decoration: none;
        font-weight: bold;
        transition: color 0.3s;
    }

    .back-link a:hover {
        color: var(--preto);
        text-decoration: underline;
    }

    footer {
        background-color: var(--marrom);
        color: var(--bege1);
        padding: 20px 0;
        text-align: center;
        margin-top: auto;
    }

    .footer-simplificado {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
    }

    .footer-logo {
        height: 80px;
        margin-bottom: 10px;
    }

    .footer-simplificado p {
        margin: 0;
        font-size: 14px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }

    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }

    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 8%; /* Alterado para centralizar verticalmente */
        transform: translateY(-50%);
        z-index: 10;
        background: transparent; /* Garante que o fundo seja transparente */
        border: none;
        cursor: pointer;
        padding: 0;
    }
</style>
<script>
    function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }
</script>