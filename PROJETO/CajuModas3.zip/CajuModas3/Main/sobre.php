<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Caju Modas - Onde o estilo encontra você.</title>
</head>
<body>


    <header>
        <h1 class="logo">
            <a>
              <img src="img/CM.png" alt="Logo CM">
            </a>
          </h1>
          <button class="login" href="login.php">Login/Cadastro</button>
          
          <button class="botao_hamburguer" onclick="toggleMenu()">
            <img src="img/hamburguer.png" width="55" height="50" alt="Menu">
        </button>
    </header>

    <div id="menuLateral" class="menu-lateral">
        <a href="javascript:void(0)" class="fechar" onclick="toggleMenu()">&times;</a>
        <a href="principal.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="carrinho.php">Carrinho</a>  
        <a href="sobre.php">Sobre Nós</a>
    </div>

    <script>        function toggleMenu() {
            const menuLateral = document.getElementById("menuLateral");
            menuLateral.style.width = (menuLateral.style.width === "250px") ? "0" : "250px";
        }

    </script>

<div class="sobre-container">
    <div class="sobre-box">
        <h2>Sobre a Caju Modas</h2>
        <p>A Caju Modas nasceu do desejo de trazer estilo, conforto e autenticidade para o dia a dia das pessoas. Mais do que uma loja de roupas, somos apaixonados por moda acessível, de qualidade e com personalidade.</p>
        <p>Desde o início, nosso compromisso é oferecer peças que valorizem todos os corpos, com coleções pensadas para acompanhar as tendências sem perder a essência de quem veste. Aqui, cada detalhe importa desde a escolha dos tecidos até o atendimento que você recebe.</p>
        <p>Trabalhamos com carinho para proporcionar uma experiência única a cada cliente, seja nas lojas físicas ou online. Acreditamos que moda é expressão, e queremos que você se sinta livre para ser quem é.</p>
        <p class="destaque">Caju Modas - Aqui, o estilo que encontra você.</p>
    </div>
</div>

    <footer>
        <footer>
            <div class="footer-container">
                <div class="footer-info">
                    <h2>Contato</h2>
                    <p>Telefone: (41) 9999-9999</p>
                    <p>E-mail: <a href="">CAJUMODAS@gmail.com</a></p>
                </div>
                
                <div class="footer-img">
                    <img src="img/CM.png" alt="Logo Caju Modas">
                </div>
                
                <div class="footer-social">
                    <h2>Siga-nos:</h2>
                    <a href="" class="social-link">    
                        <img src="img/tiktok.png" alt="Tiktok" class="footer-icon">
                        Tiktok
                    </a>
                    <a href="" class="social-link">
                        <img src="img/instagram.png" alt="Instagram" class="footer-icon">
                        Instagram 
                    </a>
                    <a href="" class="social-link">
                        <img src="img/x.png" alt="Twitter" class="footer-icon">
                        Twitter 
                    </a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 CAJU MODAS. Todos os direitos reservados para a equipe: Eduardo Monteiro, Leonardo Grattao.</p>
            </div>
        </footer>
    </footer>
<style>
    :root {
        --amarelo: #f4d06f;
        --marrom: #b39977;
        --bege1: #EDE6D9;
        --bege2: #ddcfb6;
        --bege3: #e3d6be;
        --preto: #342519;
        --marrom-escuro: #684F36;
    }

    body {
        font-family: Georgia, 'Times New Roman', Times, serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background: linear-gradient(180deg, var(--bege1), var(--bege3));
    }

    header {
        background-color: var(--marrom);
        padding: 8px;
        text-align: center;
        box-shadow: 0px 4px 10px rgba(55, 30, 0, 0.5);
        height: 138px;
    }

    .menu-lateral {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--bege2);
        overflow-x: hidden;
        transition: width 0.5s; 
        padding-top: 70px;
        box-shadow: 3px 0 15px rgba(0, 0, 0, 0.3);
        z-index: 20;             
    }



    .menu-lateral .fechar {
        position: absolute;
        top: 1px;
        right: 20px;
        font-size: 25px;
        color: var(--bege);
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.3s;
    }


    .menu-lateral a {
        padding: 15px 20px;
        text-decoration: none;
        font-size: 20px;
        color: var(--preto);
        display: block;
        margin: 10px 0;
        transition: 0.3s;
    }

    .menu-lateral a:hover {
        background-color: var(--marrom-escuro);
        color: var(--bege2);
        transform: scale(1.05);
    }

    .botao_hamburguer {
        position: absolute;
        left: 20px; 
        top: 10%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }
     
    .login {
        position: absolute;
        Right: 20px; 
        top: 10%;
        transform: translateY(-50%);
        z-index: 10; /
        height: 100px;
        width: auto;
        max-width: none; 
    }
    .banner-container {
        width: 75%;
        height: 330px;
        position: relative;
        overflow: hidden;
        margin: auto;
        margin-top: 30px;
        border-radius: 20px;
        box-shadow: 0px 4px 10px var(--preto);
        margin-bottom: 20px;
    }

    .banner-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        position: absolute;
        opacity: 0;
        transition: opacity 1s ease-in-out;
    }

    .banner-container img.active {
        opacity: 1;
    }

    section {
        padding: 30px;
        text-align: center;
    }

        
        #produtos {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        #produtos h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
            color: #333;
        }
        
        .slider-container {
            position: relative;
            overflow: hidden;
            padding: 20px 0;
        }
        
        .grid-produtos {
            display: flex;
            gap: 20px;
            transition: transform 0.5s ease;
            padding: 10px 0;
        }
        
        .produto {
            min-width: 250px;
            background: var(--bege2);
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            text-align: center;
            transition: transform 0.3s ease;
            border: 2px solid var(--bege1); 
        }
        
        .produto:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        .produto img {
            width: 60%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        
        .produto p {
            margin: 10px 0;
            font-size: 1rem;
            color: var(--preto);
        }
        
        .texto-botao {
            background-color: var(--marrom-escuro);
            color: var(--bege2);
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        
        .texto-botao:hover {
            background-color: var(--preto);
        }
        
        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.7);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 1rem;
            cursor: pointer;
            z-index: 10;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        
        .slider-btn:hover {
            background: var(--marrom-escuro)
        }
        
        #prevBtn {
            left: 5px;
        }
        
        #nextBtn {
            right: 5px;
        }
        
        .slider-dots {
            text-align: center;
            margin-top: 10px;
        }
        
        .dot {
            display: inline-block;
            width: 12px;
            height: 12px;
            background: var(--marrom);
            border-radius: 50%;
            margin: 0 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .dot.active {
            background: var(--marrom-escuro);
        }


    button {
        background-color: var(--marrom); 
        color: var(--bege2);
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
    }

    button:hover {
        background-color: var(--marrom-escuro);
    }

    .veja {
        margin-left: 47.2%;
        background-color: var(--marrom-escuro);
        margin-bottom: 40px;
    }

    .faq-container {
        max-width: 800px;
        width: 800px;
        margin: 20px auto;
        padding: 20px;
        border: 2px solid var(--bege1); 
        border-radius: 5px;
        background-color: var(--bege2);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 50px;
    }



    .faq-container h1 {
        display: flex;
        align-items: center;
    }

    .faq-image {
        width: 200px; 
        height: 200px; 
        margin-right: 10px; 
    }



    details {
        margin: 10px 0;
        border-bottom: 1px solid #ddd;
        font-family: 'Encode Sans Expanded', sans-serif;
    }

    summary {
        cursor: pointer;
        font-size: 1.2em;
        color: var(--preto);
        padding: 10px;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: background-color 0.3s;
    }

    summary:hover {
        background-color: var(--marrom-escuro);
        color: var(--marrom-escuro);
    }



    .faq-content {
        padding: 0 10px;
        color: #555;
        font-weight: normal;
        overflow: hidden; 
        max-height: 0; 
        transition: max-height 0.3s ease, padding 0.3s ease; 
    }


    .faq-title {
        cursor: pointer; 
        background-color: var(--marrom-escuro); 
        color: var(--bege2);
        border: 1px solid #ccc; 
        padding: 15px; 
        margin: 5px 0; 
        border-radius: 5px; 
        font-size: 16px;
    }


    .faq-title:hover {
        background-color: var(--preto); 
        color: var(--bege2);
    }


    details[open] .faq-content {
        max-height: 500px; 
        padding-top: 10px; 
        padding-bottom: 10px;
    }

    .faq-container h1 {
        display: flex;
        align-items: center; 
    }

    .faq-image {
        width: 50px; 
        height: auto; 
        margin-right: 10px; 
    }


    @keyframes zoom {
        0% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.05);
        }
        100% {
            transform: scale(1); 
        }
    }


    .contact-info {
        max-width: 800px;
        width: 800px;
        margin: 20px auto;
        padding: 20px;
        border: 2px solid var(--bege1); 
        border-radius: 5px;
        background-color: var(--bege2);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 50px;
    }

    .contact-info p {
        color: var(--preto); 
    }



    .mapa {
        width: 100%; 
        height: 300px; 
        border: 0;
        border-radius: 5px; 
        box-shadow: 1 2px 10px rgba(0, 0, 0, 0.1); 
        margin-top: 15px; 
    }


    footer {
        background-color: var(--marrom);
        color: var(--bege1);
        padding: 1px 0; 
        margin-top: 10px; 
    }

    .footer-container {
        display: flex;
        justify-content: space-around;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
        flex-wrap: wrap; 
        padding: 10px 0;
        border-bottom: 3px solid #333;
    }

    .footer-info, .footer-img, .footer-social {
        flex: 1;
        padding: 5px; 
        text-align: center; 
    }

    .footer-img img {
        width: 120;
        height: 100px;
        border-radius: 8px;
    }

    .footer-social {
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: flex-end; 
        gap: 8px; 
        padding-right: 20px; 
    }

    .footer-social a {
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--bege1);
        text-decoration: none;
        flex-direction: row-reverse; 
        font-size: 22px;
    }

    .footer-icon {
        width: 37px; 
        height: 37px;
        margin-left: 12px; 
        transition: transform 0.3s;
    }

    .footer-social a:hover .footer-icon {
        transform: scale(1.2);
    }

    .footer-bottom {
        margin-top: 10px;
        font-size: 14px;
        text-align: center;
    }


    .texto-botao {
        color: white;
    }

    .logo {
        margin: 0;
        padding: 0;
    }
    
    .logo img {
        height: 140px; 
        vertical-align: middle;
    }

    .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        .close-modal {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close-modal:hover {
            color: black;
        }
        
        .modal-body {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .modal-img {
            width: 100%;
            max-height: 300px;
            object-fit: contain;
            border-radius: 5px;
        }
        
        .modal-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin: 0;
        }
        
        .modal-price {
            font-size: 1.2rem;
            color: #e63946;
            font-weight: bold;
        }
        
        .size-options {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin: 10px 0;
        }
        
        .size-btn {
            padding: 8px 15px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .size-btn.selected {
            background: #333;
            color: white;
            border-color: #333;
        }
        
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        
        .add-to-cart, .add-to-wishlist {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex: 1;
        }
        
        .add-to-cart {
            background-color: #e63946;
            color: white;
        }
        
        .add-to-wishlist {
            background-color: #f1faee;
            color: #333;
            border: 1px solid #ddd;
        }
        
        @media (max-width: 600px) {
            .modal-content {
                width: 90%;
                margin: 20% auto;
            }
            
            .modal-actions {
                flex-direction: column;
            }
        }

</style>