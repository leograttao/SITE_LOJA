<?php
	if(isset($_POST['marca']) && isset($_POST['valor'])){
		$obj = conecta_db();
		$query = "
		INSERT INTO roupa (marca, valor) 
		VALUES ('".$_POST['marca']."', '".$_POST['valor']."')";
		$resultado = $obj->query($query);
		if($resultado){
			header("location:index.php");
		} else {
			echo "<span class='alert alert-danger'><h5>Não funcionou!</h5></span>";
		}
	}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Meu primeiro CRUD</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
  <div class="mt-2 container-fluid">
	<div class="row">
		<div class="col-1">
			<i class="fa fa-check" style="font-size:30px;"></i>
		</div>
		<div class="col-2">
			<h5>CRUD - Insert </h5>
		</div>
	</div>
	<div class="row">
		<div class="col-6">
			<form method="POST" action="index.php?page=1">
			<input type="text" name="marca" class="form-control" placeholder="Digite aqui a marca da roupa">
			<input type="text" name="valor" class="form-control" placeholder="Digite aqui o valor">	
			<button type="submit" class="mt-2 btn btn-primary">Enviar</button>
			
			</form>
		</div>
	</div>
  </div>
</body>
</html>
