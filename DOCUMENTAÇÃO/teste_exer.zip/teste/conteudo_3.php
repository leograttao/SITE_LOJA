<?php
	if(isset($_GET['id'])){
		$obj = conecta_db();
		$query = "DELETE FROM roupa WHERE id = ".$_GET['id'];
		$resultado = $obj->query($query);
		header('location:index.php');
	}else{
		header('location:index.php');
	}
?>